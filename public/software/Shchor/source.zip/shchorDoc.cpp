// shchorDoc.cpp : implementation of the CShchorDoc class
//

#include "stdafx.h"
#include "shchor.h"

#include "shchorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShchorDoc

IMPLEMENT_DYNCREATE(CShchorDoc, CDocument)

BEGIN_MESSAGE_MAP(CShchorDoc, CDocument)
	//{{AFX_MSG_MAP(CShchorDoc)
	ON_UPDATE_COMMAND_UI(ID_ACTION_SOLVE, OnUpdateActionSolve)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShchorDoc construction/destruction

CShchorDoc::CShchorDoc()
{
	m_xdata=m_ydata=0;
	m_solution=0;
	m_nX=m_nY=0;
	m_bThreadRunning=false;
}

CShchorDoc::~CShchorDoc()
{
}

BOOL CShchorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CShchorDoc serialization

void CShchorDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		AfxMessageBox("Can't store document.");
	}
	else
	{
		char s[200];
		ar.ReadString(s,200);
		if(strcmp(s,"shchor data file")!=0) {
			AfxMessageBox("Invalid data file: File must begin with the line 'shchor data file'.");
			return;
		}

		// Deallocate memory of existing table
		DeleteContents();

		// Read table size
		ar.ReadString(s,200);
		sscanf(s,"%d",&m_nX);
		ar.ReadString(s,200);
		sscanf(s,"%d",&m_nY);

		// Allocate memory
		m_xdata = new CArray<short,short>[m_nX];
		m_ydata = new CArray<short,short>[m_nY];
		m_solution = new char[m_nX*m_nY];
		memset(m_solution,0,m_nX*m_nY);

		// Read table data
		if(!ReadList(ar,m_nX,m_xdata,"x-data"))
			return;
		if(!ReadList(ar,m_nY,m_ydata,"y-data"))
			return;

		// Read last line of file
		ar.ReadString(s,200);
		if(strcmp(s,"end")!=0) {
			AfxMessageBox("Invalid data file: File must end with the line 'end'.");
			return;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CShchorDoc diagnostics

#ifdef _DEBUG
void CShchorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CShchorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CShchorDoc commands

void CShchorDoc::DeleteContents() 
{
	if(m_xdata)
		delete[] m_xdata;
	if(m_ydata)
		delete[] m_ydata;
	if(m_solution)
		delete[] m_solution;

	CDocument::DeleteContents();
}

bool CShchorDoc::ReadList(CArchive &ar, int max, CArray<short,short> *array, const char *expected_string)
// internal function called by Serialize
{
	char s[200];
	int n;
	char* pc;
	ar.ReadString(s,200);
	if(strcmp(s,expected_string)!=0) {
		sprintf(s,"Invalid data file (expected '%s').",expected_string);
		AfxMessageBox(s);
		return false;
	}
	for(int i=0; i<max; i++) {
		ar.ReadString(s,200);
		pc = strtok(s," ");
		do {
			sscanf(pc,"%d",&n);
			array[i].Add(n);
			pc = strtok(NULL," ");
		} while(pc != NULL);
	}
	return true;
}

void CShchorDoc::OnUpdateActionSolve(CCmdUI* pCmdUI) 
{
	if(m_nX==0||m_nY==0)
		pCmdUI->Enable(false);
	else
		pCmdUI->Enable(true);
}

void CShchorDoc::require(int i, int j, char val)
{
	if((*this)(i,j)==3)
		(*this)(i,j)=val;
	else if((*this)(i,j)!=val)
		throw(CRequirementFailed());
}

void CShchorDoc::ClearSolution()
{
	memset(m_solution,3,m_nX*m_nY);
}

int CShchorDoc::NumUnknown()
{
	// Find number of unknowns
	int nUnknown=0,i;
	for(i=0; i<m_nX*m_nY; i++) {
		if(m_solution[i]==3)
			nUnknown++;
	}
	return nUnknown;
}

void CShchorDoc::TraceSol()
{
	TRACE("--------------------\n");
	for(int i=0; i<m_nY; i++) {
		for(int j=0; j<m_nX; j++) {
			TRACE("%d ",(*this)(j,i));
		}
		TRACE("\n");
	}
}

