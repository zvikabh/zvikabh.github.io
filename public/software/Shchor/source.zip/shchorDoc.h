// shchorDoc.h : interface of the CShchorDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHCHORDOC_H__A5ED208D_ED4E_11D4_9F4B_B09E77CB0000__INCLUDED_)
#define AFX_SHCHORDOC_H__A5ED208D_ED4E_11D4_9F4B_B09E77CB0000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRequirementFailed {};

class CShchorDoc : public CDocument
{
protected: // create from serialization only
	CShchorDoc();
	DECLARE_DYNCREATE(CShchorDoc)

// Attributes
public:
	int GetX() { return m_nX; };
	int GetY() { return m_nY; };
	char& operator()(int i,int j) { ASSERT(i<m_nX&&i>=0&&j<m_nY&&j>=0); return m_solution[i*m_nY+j]; };
	void require(int i,int j,char val);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShchorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	//}}AFX_VIRTUAL

// Implementation
public:
	void TraceSol();
	bool m_bThreadRunning;
	int NumUnknown();
	void ClearSolution();
	virtual ~CShchorDoc();
	CArray<short,short>* m_xdata;
	CArray<short,short>* m_ydata;
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	char* m_solution;

// Generated message map functions
protected:
	int m_nX,m_nY;
	//{{AFX_MSG(CShchorDoc)
	afx_msg void OnUpdateActionSolve(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	static bool ReadList(CArchive& ar, int max, CArray<short,short>* array, const char* expected_string);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHCHORDOC_H__A5ED208D_ED4E_11D4_9F4B_B09E77CB0000__INCLUDED_)
