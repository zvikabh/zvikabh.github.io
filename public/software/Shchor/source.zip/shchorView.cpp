// shchorView.cpp : implementation of the CShchorView class
//

#include "stdafx.h"
#include "shchor.h"
#include "mainfrm.h"
#include "shchorDoc.h"
#include "shchorView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShchorView

IMPLEMENT_DYNCREATE(CShchorView, CView)

BEGIN_MESSAGE_MAP(CShchorView, CView)
	//{{AFX_MSG_MAP(CShchorView)
	ON_COMMAND(ID_ACTION_SOLVE, OnActionSolve)
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShchorView construction/destruction

CShchorView::CShchorView()
{
	m_nTotalIter=m_nLevel=m_nPrevLevelUnknown=m_nIter=m_nUnknown=m_nPrevUnknown=0;
}

CShchorView::~CShchorView()
{
}

BOOL CShchorView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CShchorView drawing

void CShchorView::OnDraw(CDC* pDC)
{
	CShchorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(pDoc->GetX()==0 || pDoc->GetY()==0)
		return;

	if(!pDoc->m_bThreadRunning) {
		EndWaitCursor();
	}

	CString message;
	if(m_nUnknown!=0 || m_nPrevUnknown!=0) {
		long dtime;
		time_t curTime;
		time(&curTime);
		dtime = curTime - m_timeStart;
		message.Format("Running (Iteration %d / Level %d / %d:%02d minutes); %d unknown elements, %d added during this level, %d added during last iteration",
			m_nTotalIter,m_nLevel,int(dtime/60),int(dtime%60),m_nUnknown,m_nPrevLevelUnknown-m_nUnknown,m_nPrevUnknown-m_nUnknown);
		((CMainFrame*)(AfxGetApp()->GetMainWnd()))->SetMessageText(message);
	} else {
		((CMainFrame*)(AfxGetApp()->GetMainWnd()))->SetMessageText("Ready");
	}

	CRect rect;
	GetClientRect(&rect);
	pDC->SetMapMode(MM_LOMETRIC);
	pDC->DPtoLP(&rect);

	int nCellHeight = (rect.bottom+200)/pDoc->GetY();
	int nCellWidth  = (rect.right-200)/pDoc->GetX();

	for(int i=-200; i>rect.bottom; i+=nCellHeight) {
		pDC->MoveTo(rect.left,i);
		pDC->LineTo(200,i);
	}
	for(i=200; i<rect.right; i+=nCellWidth) {
		pDC->MoveTo(i,0);
		pDC->LineTo(i,-200);
	}

	CString s1,s2;
	CString str;
	int j;
	CRect trect;

	trect.top=0;
	trect.bottom=-200;
	CFont font1;
	font1.CreateFont(28,0,2700,0,0,0,0,0,0,OUT_DEFAULT_PRECIS,CLIP_MASK,
		DEFAULT_QUALITY,DEFAULT_PITCH,"Arial");
	CFont* pOldFont = pDC->SelectObject(&font1);
	for(i=0; i<pDoc->GetX(); i++) {
		trect.left = 201 + i*nCellWidth;
		trect.right = 200 + (i+1)*nCellWidth;
		s2.Empty();
		for(j=0; j<pDoc->m_xdata[i].GetSize(); j++) {
			s1.Format("%d ",pDoc->m_xdata[i][j]);
			s2+=s1;
		}
		pDC->DrawText(s2,trect,DT_CENTER|DT_BOTTOM|DT_SINGLELINE);
	}
	trect.left = 20;
	trect.right = 200;
	CFont font2;
	font2.CreateFont(28,0,0,0,0,0,0,0,0,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,DEFAULT_PITCH,"Arial");
	pDC->SelectObject(&font2);
	for(i=0; i<pDoc->GetY(); i++) {
		trect.top = -200 + i*nCellHeight;
		trect.bottom = -200 + (i+1)*nCellHeight;
		s2.Empty();
		for(j=0; j<pDoc->m_ydata[i].GetSize(); j++) {
			s1.Format("%d ",pDoc->m_ydata[i][j]);
			s2+=s1;
		}
		pDC->DrawText(s2,trect,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
	}
	pDC->SelectObject(pOldFont);

	CBrush dark(RGB(0,0,255)),light(RGB(255,255,0));
	for(i=0; i<pDoc->GetX(); i++) {
		trect.left = 200 + i*nCellWidth;
		trect.right = 200 + (i+1)*nCellWidth;
		for(j=0; j<pDoc->GetY(); j++) {
			trect.top = -200 + j*nCellHeight;
			trect.bottom = -200 + (j+1)*nCellHeight;
			if((*pDoc)(i,j)==1)
				pDC->FillRect(&trect,&dark);
			else if((*pDoc)(i,j)==2)
				pDC->FillRect(&trect,&light);
		}
	}

	if(pDoc->m_bThreadRunning)
		RestoreWaitCursor();
}

/////////////////////////////////////////////////////////////////////////////
// CShchorView printing

BOOL CShchorView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CShchorView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CShchorView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CShchorView diagnostics

#ifdef _DEBUG
void CShchorView::AssertValid() const
{
	CView::AssertValid();
}

void CShchorView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CShchorDoc* CShchorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CShchorDoc)));
	return (CShchorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CShchorView message handlers

DWORD WINAPI SolveThread(LPVOID param);

void CShchorView::OnActionSolve()
{
	DWORD id;
	CreateThread(NULL,0,SolveThread,(LPVOID)this,0,&id);
	GetDocument()->m_bThreadRunning = true;
}

int NumUnknownInLine(const char* line, int length)
{
	int sum=0;
	for(int i=0; i<length; i++) {
		if(line[i]==3)
			sum++;
	}

	return sum;
}

DWORD WINAPI SolveThread(LPVOID param)
{
	CShchorView* pView = (CShchorView*)(param);
	CShchorDoc& doc = *(pView->GetDocument());
	int nX=doc.GetX(),nY=doc.GetY();
	CArray<short,short>* xdata = doc.m_xdata;
	CArray<short,short>* ydata = doc.m_ydata;
	if(nX==0||nY==0) {
		MessageBeep(0);
		doc.m_bThreadRunning=false;
		return 0;
	}

	pView->BeginWaitCursor();
	doc.ClearSolution();
	int i,j;
	pView->m_nIter=0;
	pView->m_nLevel=0;
	pView->m_nTotalIter=0;
	pView->m_nUnknown=pView->m_nPrevUnknown=pView->m_nPrevLevelUnknown=nX*nY;
	char* xline = new char[nY];
	char* yline = new char[nX];
	char* xchanges = new char[nX];
	char* ychanges = new char[nY];
	memset(xchanges,1,nX);
	memset(ychanges,1,nY);
	time_t tt_start,tt_end;
	int clear_changes_until;

	time(& pView->m_timeStart);
	do {
		// Go over xdata
		time(&tt_start);
		clear_changes_until=nX;
		for(i=0; i<nX; i++) {
			if(!xchanges[i])
				continue;
			for(j=0; j<nY; j++)
				xline[j] = doc(i,j);
			if(NumUnknownInLine(xline,nY)>0) {
				pView->SolveLine(xdata[i].GetData(),xdata[i].GetSize(),xline,nY,pView->m_nLevel,
								 ychanges);
				for(j=0; j<nY; j++)
					doc(i,j) = xline[j];
			}
			if(i%10==0 && pView->m_nIter<5) {
				time(&tt_end);
				if(tt_end-tt_start > pView->m_nIter*5) {
					// this is taking too long;
					// stop and let the other half of the iteration have a go
					clear_changes_until=i;
					break;
				}
			}
		}
		// Clear the variable xchanges for those lines which have been tested
		memset(xchanges,0,clear_changes_until);

		// Go over ydata
		clear_changes_until=nY;
		pView->RestoreWaitCursor();
		for(i=0; i<nY; i++) {
			if(!ychanges[i])
				continue;
			for(j=0; j<nX; j++)
				yline[j] = doc(j,i);
			if(NumUnknownInLine(yline,nX)>0) {
				pView->SolveLine(ydata[i].GetData(),ydata[i].GetSize(),yline,nX,pView->m_nLevel,xchanges);
				for(j=0; j<nX; j++)
					doc(j,i) = yline[j];
			}
			if(i%10==0 && pView->m_nIter<5) {
				time(&tt_end);
				if(tt_end-tt_start > pView->m_nIter*5) {
					// this is taking too long;
					// stop and let the other half of the iteration have a go
					clear_changes_until=i;
					break;
				}
			}
		}
		// Clear the variable xchanges for those lines which have been tested
		memset(ychanges,0,clear_changes_until);
		
		pView->InvalidateRect(NULL,FALSE);
		pView->RestoreWaitCursor();
		
		// Check if anything is still unknown
		pView->m_nPrevUnknown = pView->m_nUnknown;
		pView->m_nUnknown = doc.NumUnknown();
		pView->m_nIter++;
		pView->m_nTotalIter++;
		if(pView->m_nPrevUnknown==pView->m_nUnknown && pView->m_nIter>5) {
			pView->m_nLevel++;
			pView->m_nPrevLevelUnknown = pView->m_nUnknown;
			pView->m_nIter = 0;
			memset(xchanges,1,nX);
			memset(ychanges,1,nY);
		}
	} while(pView->m_nUnknown>0 && pView->m_nLevel<50);

	delete[] xline;
	delete[] yline;
	delete[] xchanges;
	delete[] ychanges;
		
	CString s;
	if(pView->m_nUnknown==0) { 
		s.Format("Problem solved in %d iterations.",pView->m_nTotalIter);
		AfxMessageBox(s);
	} else {
		s.Format("Finished with %d unknown(s), after %d iterations.",pView->m_nUnknown,
			pView->m_nTotalIter);
		AfxMessageBox(s);
	}
	pView->InvalidateRect(NULL);
	doc.m_bThreadRunning=false;
	pView->m_nIter=0;
	return 0;
}

bool CShchorView::SolveLine(const short* data, int datalength, char *line, int linelength, 
							int nlevels, char* linechanges)
{
	if(nlevels==0)
		return true; // maximum level exceeded

	int i;
	if(datalength==0) {
		// no more elements to place ==> solution iff rest of line is blank
		for(int i=0; i<linelength; i++) {
			if(line[i]==1)
				return false;
			else
				line[i]=2;
		}
		return true;
	}

	int sum=datalength-1;
	for(i=0; i<datalength; i++) {
		sum += data[i];
	}
	if(sum>linelength)
		return false;
	if(sum==linelength) {
		// only one possible solution
		int j=0;
		for(i=0; i<datalength; i++) {
			for(int k=0; k<data[i]; k++) {
				if(line[j]==2)
					return false;
				line[j++]=1;
			}
			if(i<datalength-1) {
				if(line[j]==1)
					return false;
				line[j++]=2;
			}
		}
		return true;
	}

	// There are several possibilities. Try them all (recursively).
	// In this level of the recursion we find only the position of the first element.
	int firstpos;
	bool solution_exists=false;
	char *linecopy = new char[linelength];
	char *tentative_line = new char[linelength];
	memset(tentative_line,0,linelength);
	for(firstpos=0; firstpos<=linelength-sum; firstpos++) {
		// make sure we can place the element at firstpos
		bool good=true;
		for(i=0; i<firstpos; i++) {
			if(line[i]==1) {
				// there is a nonempty cell before the first element, which is illegal
				good=false;
				break;
			}
		}
		if(!good) {
			// if at this point the position is illegal, then all further positions will also be illegal
			break;
		}
		for(i=0; i<data[0]; i++) {
			if(line[firstpos+i]==2) {
				// element uses a cell which must be empty; illegal
				good=false;
				break;
			}
		}
		if(firstpos+data[0]<linelength && line[firstpos+data[0]]==1) {
			// element must be followed by a blank
			good=false;
		}
		if(!good)
			continue;

		// good value for firstpos. place it there.
		memcpy(linecopy,line,linelength);
		if(firstpos>0)
			memset(linecopy,2,firstpos);
		memset(linecopy+firstpos,1,data[0]);
		if(firstpos+data[0]<linelength)
			linecopy[firstpos+data[0]]=2;

		// start the recursion
		if(SolveLine(data+1,datalength-1,linecopy+firstpos+data[0]+1,linelength-firstpos-data[0]-1,nlevels-1)) {
			// found consistent solution. copy results to 'tentative_line'.
			solution_exists=true;
			for(i=0; i<linelength; i++) {
				tentative_line[i] |= linecopy[i];
			}
			// check if tentative is full of 3's; if so, no further conclusions can be reached
			bool finished=true;
			for(i=0; i<linelength; i++) {
				if(tentative_line[i]!=2) {
					finished=false;
					break;
				}
			}
			if(finished)
				break;
		}
	}

	if(solution_exists) {
		// draw conclusions from tentative line
		if(linechanges==NULL) {
			// simply copy results to line
			for(i=0; i<linelength; i++) {
				if(tentative_line[i]==1 || tentative_line[i]==2)
					line[i]=tentative_line[i];
			}
		} else {
			// copy results to line, and mark changes in 'linechanges'
			for(i=0; i<linelength; i++) {
				if(tentative_line[i]!=line[i] && (tentative_line[i]==1 || tentative_line[i]==2)) {
					line[i]=tentative_line[i];
					linechanges[i] = 1;
				}
			}
		}
	}
		
	delete[] linecopy;
	delete[] tentative_line;
	return solution_exists;
}

void CShchorView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(GetDocument()->m_bThreadRunning)
		RestoreWaitCursor();
	CView::OnMouseMove(nFlags, point);
}
