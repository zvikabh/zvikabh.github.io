// shchorView.h : interface of the CShchorView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHCHORVIEW_H__A5ED208F_ED4E_11D4_9F4B_B09E77CB0000__INCLUDED_)
#define AFX_SHCHORVIEW_H__A5ED208F_ED4E_11D4_9F4B_B09E77CB0000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CShchorView : public CView
{
protected: // create from serialization only
	CShchorView();
	DECLARE_DYNCREATE(CShchorView)

// Attributes
public:
	CShchorDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShchorView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	time_t m_timeStart;
	int m_nTotalIter;
	int m_nPrevLevelUnknown;
	int m_nLevel;
	int m_nIter;
	int m_nPrevUnknown;
	int m_nUnknown;
	bool SolveLine(const short* data,int datalength,char* line, int linelength, int nlevels, 
		char* linechanges=NULL);
	virtual ~CShchorView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CShchorView)
	afx_msg void OnActionSolve();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in shchorView.cpp
inline CShchorDoc* CShchorView::GetDocument()
   { return (CShchorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHCHORVIEW_H__A5ED208F_ED4E_11D4_9F4B_B09E77CB0000__INCLUDED_)
