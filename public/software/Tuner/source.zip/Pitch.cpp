// Pitch.cpp
// This file contains functions which can be used to perform various pitch-detection
// algorithms, cross-correlations and auto-correlations.
// Written by Zvika Ben-Haim <zvikabh@aluf.technion.ac.il>, 1998.

#include "StdAfx.h"
#include "Pitch.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

float correlation(sample a[], sample b[], UINT uLen, int step/*=1*/) {
	return ( crossprod(a,b,uLen,step) / norm(a,uLen,step) / norm(b,uLen,step) );
}

float norm(sample a[], UINT uLen, int step/*=1*/) {
	return (float)sqrt(crossprod(a,a,uLen,step));
}

float crossprod(sample a[], sample b[], UINT uLen, int step/*=1*/) {
	float x=0.;
	UINT u;
	for(u=0; u<uLen; u+=step)
		x += ((int)a[u]*b[u]);
	return x;
}

int int_pitch(sample a[], int minpitch, int maxpitch, int step, float* correl)
// a must be at least 2*maxpitch+1 samples long
{
	const int ncc = (maxpitch-minpitch)/step + 1;
	float *cc = new float[(maxpitch-minpitch)/step + 1];
	int pitch,bestpitch=0,i,j,count;
	float maxcc=-2,c,trig;

	pitch = minpitch;
	for(i=0; i<ncc; i++) {
		c = correlation(a, a+pitch, pitch);
		if(c > maxcc) {
			maxcc=c;
			bestpitch=i*step+minpitch;
		}
		cc[i] = c;
		//TRACE("%.5f\n",cc[i]);
		pitch += step;
	}

	// for explanation of this section of the algorithm, see logbook, Dec. 5
	trig = 0.70f*maxcc; // trigger value of choosing candidates
	c=-2; // maximum cc amongst the candidates
	CArray<float,float> cand_correl;
	CArray<int,int> cand_pitch;
	for(i=3; i<ncc-3; i++) {
		if(cc[i]<trig) continue;
		for(count=0, j=-3; j<=3; j++) {
			if(j==0) continue;
			if(cc[i+j]<cc[i])
				count++;
		}
		if(count==6) {
			// found another candidate
			if(cc[i]>c)
				c=cc[i];
			cand_correl.Add(cc[i]);
			cand_pitch.Add(i*step + minpitch);
			//TRACE("Added candidate, pitch=%d, correl=%.3f\n",i*step+minpitch,cc[i]);
		}
	}

	if(cand_correl.GetSize()==0) {
		// no candidates found, so we'll just take the maximum correlation value.
		// this is already found in maxcc and bestpitch.
	} else {
		if(cand_correl.GetSize()==1) {
			bestpitch = cand_pitch[0];
			maxcc = cand_correl[0];
		} else {
			// choose best candidate.
			trig = 0.70f*c; // trigger value = 80% of cc of the best candidate
			for(i=0; i<cand_pitch.GetSize(); i++) {
				maxcc = correlation(a, a+cand_pitch[i], maxpitch);
				if(maxcc > trig)
					break;
			}
			if(i==cand_pitch.GetSize()) {
				// nothing found, just use the first candidate
				i=0;
			}
			maxcc = cand_correl[i];
			bestpitch = cand_pitch[i];
		}
	}

	delete [] cc;

	if(correl!=0)
		(*correl) = maxcc;

	//TRACE("Chose best pitch: %d\n",bestpitch);
	return bestpitch;
}

float sr_pitch(sample x[], int minpitch, int maxpitch, int step, float *correl, int* nrep/*=NULL*/)
// finds the super-resolution (SR) pitch
{
	// first, find the integer pitch N0
	float ipc0,ipc1;
	int N0 = int_pitch(x,minpitch,maxpitch,step,correl);
	int truncN;
	int i=0;

	// next, find trnucN, the truncated part of the SR pitch
	// (algorithm in Medan et al., p.3 bottom right, and in my notes, bottom p.3)
	ipc0 = correlation(x, x+N0-step, N0-step);
	ipc1 = correlation(x, x+N0+step, N0+step);
	// ipc[1] is the correlation for testing pitch N0, and should be larger than the other
	// two ipc's. The actual value of truncN is determined according to:
	if(ipc0>ipc1 && N0>minpitch)
		truncN = N0 - step;
	else
		truncN = N0;
	
	// now, find the fractional part of the SR pitch.
	// (algorithm in Medan et al., p.3 top right)
	float beta,beta1,beta2;
	float xy1,yy,xy,yy1,y1y1; 
	sample* y;

	do { // under normal circumstances, this is done only once
		y = x+truncN;
		xy1 = crossprod(x,y+1,truncN,step);
		yy = crossprod(y,y,truncN,step);
		xy = crossprod(x,y,truncN,step);
		yy1 = crossprod(y,y+1,truncN,step);
		y1y1 = crossprod(y+1,y+1,truncN,step);
		
		beta1 = xy1*yy - xy*yy1;
		beta2 = xy1*(yy-yy1) + xy*(y1y1-yy1);
		beta = beta1/beta2;

		if(beta>1)
			truncN++;
		else if(beta<0)
			truncN--;
		i++;
		if(i>3) {
			// see Dec. 5, supplemental.
			// see also Jan. 5, supplemental.
			if(nrep!=NULL)
				*nrep = 4;
			return (float)N0;
		}
	} while(beta>1 || beta<0);

	if(nrep!=NULL)
		*nrep = i;
	return truncN + beta;
}
