// Pitch.h
// Include this file in all modules which use functions from Pitch.cpp
// Written by Zvika Ben-Haim <zvikabh@aluf.technion.ac.il>, 1998

typedef short sample;

float correlation(sample a[], sample b[], UINT uLen, int step=1);
	// calculates correlation between two signals

float norm(sample a[], UINT uLen, int step=1);
	// calculates the Euclidian norm of the signal

float crossprod(sample a[], sample b[], UINT uLen, int step=1);
	// calculates the cross product between two signals

int int_pitch(sample a[], int minpitch, int maxpitch, int step, float *correl);
	// calculates the integer pitch

float sr_pitch(sample a[], int minpitch, int maxpitch, int step, float *correl, int* nrep=NULL);
	// calculates the super-resolution (SR) pitch