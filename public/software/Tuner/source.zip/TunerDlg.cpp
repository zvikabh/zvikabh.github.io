// TunerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Tuner.h"
#include "TunerDlg.h"
#include "pitch.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define SMPRATE 8000
#define BUFSIZE 4096
#define ENSEMBLE_SIZE 20

#define WM_USER_NEW_BUFFER WM_USER+1
#define DELTA_NO_VALUE -500

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTunerDlg dialog

CTunerDlg::CTunerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTunerDlg::IDD, pParent), m_sNote("")
{
	//{{AFX_DATA_INIT(CTunerDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_buffer = new sample[BUFSIZE/2];
	m_nDelta = DELTA_NO_VALUE;
}

CTunerDlg::~CTunerDlg()
{
	if(m_buffer)
		delete[] m_buffer;
}

void CTunerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTunerDlg)
	DDX_Control(pDX, IDC_PROGRESS1, m_progress1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTunerDlg, CDialog)
	//{{AFX_MSG_MAP(CTunerDlg)
	ON_MESSAGE(MM_WIM_DATA,OnMMData)
	ON_MESSAGE(WM_USER_NEW_BUFFER,OnNewBuffer)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTunerDlg message handlers

BOOL CTunerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Set progress range
	m_progress1.SetRange32(0,16000);

	// Start recording
	WAVEFORMATEX wfx;
	wfx.wFormatTag = WAVE_FORMAT_PCM;	// PCM format
	wfx.nChannels = 1;					// mono sound
	wfx.nSamplesPerSec = SMPRATE;		// sampling rate
	wfx.nAvgBytesPerSec = SMPRATE*2;	// 16 bytes per sample
	wfx.nBlockAlign = 2;				// bytes per sample
	wfx.wBitsPerSample = 16;			// bits per sample
	wfx.cbSize = 0;						// extra info (ignored for PCM)

	MMResult(waveInOpen(&m_hwi,WAVE_MAPPER,&wfx,(ULONG)(void*)m_hWnd,0,CALLBACK_WINDOW));
	AddBuffer();
	AddBuffer();
	MMResult(waveInStart(m_hwi));

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTunerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTunerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		if(m_nDelta!=DELTA_NO_VALUE) {
			CPaintDC dc(this); // device context for painting

			// Draw text
			CRect rect(10,10,160,100);
			CFont font,*pFont;
			font.CreateFont(90,0,0,0,FW_NORMAL,0,0,0,0,0,0,0,0,"Times New Roman");
			pFont = dc.SelectObject(&font);
			dc.DrawText(m_sNote, &rect, DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			dc.SelectObject(pFont);

			// Draw arrow
			CRgn rgn;
			CBrush brush(RGB(128,128,128));
			const int cx = 200, cy = 120;

			if(abs(m_nDelta)>10) {
				CPoint pts[7];
				pts[0] = CPoint( cx , cy );
				pts[1] = CPoint( cx-20 , cy - (m_nDelta>0 ? 20 : -20) );
				pts[2] = CPoint( cx-10 , pts[1].y );
				pts[3] = CPoint( cx-10 , cy - 2*m_nDelta );
				pts[4] = CPoint( cx+10 , pts[3].y );
				pts[5] = CPoint( cx+10 , pts[2].y );
				pts[6] = CPoint( cx+20 , pts[1].y );
				rgn.CreatePolygonRgn(pts,7,WINDING);
			} else {
				CPoint pts[3];
				pts[0] = CPoint( cx , cy );
				pts[1] = CPoint( cx-m_nDelta*2 , cy-m_nDelta*2 );
				pts[2] = CPoint( cx+m_nDelta*2 , cy-m_nDelta*2 );
				rgn.CreatePolygonRgn(pts,3,WINDING);
			}
			dc.FillRgn(&rgn,&brush);
		}
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTunerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTunerDlg::MMResult(MMRESULT res) {
	if(res==MMSYSERR_NOERROR)
		return;

	char text[MAXERRORLENGTH];
	
	waveInGetErrorText(res, text, MAXERRORLENGTH);
	AfxMessageBox(text);
	return;
}

void CTunerDlg::AddBuffer()
{
	WAVEHDR* wh = new WAVEHDR;
	memset(wh,0,sizeof(WAVEHDR));
	char* buffer = new char[BUFSIZE];
	wh->lpData = buffer;
	wh->dwBufferLength = BUFSIZE;
	MMResult(waveInPrepareHeader(m_hwi, wh, sizeof(WAVEHDR)));
	MMResult(waveInAddBuffer(m_hwi, wh, sizeof(WAVEHDR)));
}

void CTunerDlg::OnClose() 
{
	MMResult(waveInStop(m_hwi));
	MMResult(waveInReset(m_hwi));
	MMResult(waveInClose(m_hwi));
	CDialog::OnClose();
	m_hwi=0;
}

LRESULT CTunerDlg::OnMMData(WPARAM wParam, LPARAM lParam)
{
	LPWAVEHDR pwh = (LPWAVEHDR)lParam;
	sample* buffer = (sample*) pwh->lpData;
	int nSamples = pwh->dwBytesRecorded/2;
	waveInUnprepareHeader(m_hwi, pwh, sizeof(WAVEHDR));
	if(m_hwi)
		AddBuffer();

	long sum=0;
	for(int i=0; i<nSamples; i++) {
		sum+=abs(buffer[i]);
	}
	if(nSamples>0)
		sum/=nSamples;
	else
		sum=0;

	m_progress1.SetPos(sum);

	memcpy(m_buffer,buffer,nSamples*2);
	PostMessage(WM_USER_NEW_BUFFER,0,nSamples);

	delete pwh->lpData;
	delete pwh;

	return 0;
}

LRESULT CTunerDlg::OnNewBuffer(WPARAM wParam, LPARAM lParam)
{
	// Remove all other NEW_BUFFER messages
	MSG msg;
	PeekMessage(&msg,m_hWnd,WM_USER_NEW_BUFFER,WM_USER_NEW_BUFFER,PM_REMOVE);

	const float minfreq=100,maxfreq=800;
	const int minpitch=(int)(SMPRATE/maxfreq), maxpitch=(int)(SMPRATE/minfreq);

	float correl[ENSEMBLE_SIZE];
	float pitch[ENSEMBLE_SIZE];
	int nSamples = lParam;
	float tpitch=0;
	float tpitchsq=0;
	for(int nPitchValues=0; tpitch+maxpitch<nSamples-10 && nPitchValues<ENSEMBLE_SIZE; nPitchValues++) {
		pitch[nPitchValues]=sr_pitch(m_buffer+(int)tpitch,minpitch,maxpitch,1,&(correl[nPitchValues]),0);
		tpitch += pitch[nPitchValues];
		tpitchsq += pitch[nPitchValues]*pitch[nPitchValues];
	}

	if(nPitchValues!=ENSEMBLE_SIZE)
		nPitchValues++;

	tpitch/=nPitchValues;
	tpitchsq/=nPitchValues;
	
	float pitch_sd = (float) sqrt(tpitchsq - tpitch*tpitch);

	if(pitch_sd < 1.f) {
		CString str;
		float good_pitch=0;
		int nGoodPitch=0;
		for(int i=0; i<nPitchValues; i++) {
			if(fabs(pitch[i]-tpitch)<2.5*pitch_sd) {
				nGoodPitch++;
				good_pitch+=pitch[i];
			}
		}
		good_pitch/=nGoodPitch;
		float freq = SMPRATE/good_pitch;
		m_sNote = Note(freq,m_nDelta);
		str.Format("%s %+d�\nAve Freq: %.2f Hz\nPitch SD: %.2f smp\nnGoodPitch: %d",m_sNote,m_nDelta,freq,pitch_sd,nPitchValues);
		GetDlgItem(IDC_STATIC1)->SetWindowText(str);
		Invalidate(true);
	}

	return 0;
}

CString CTunerDlg::Note(float freq,int& delta)
{
	int lf = (int)(1200*log(freq/440)/log(2));
	lf += 1200*3+900;

	CString str;
	switch(((lf+50)/100)%12) {
	case 0:  str = "C-"; break;
	case 1:  str = "C#"; break;
	case 2:  str = "D-"; break;
	case 3:  str = "D#"; break;
	case 4:  str = "E-"; break;
	case 5:  str = "F-"; break;
	case 6:  str = "F#"; break;
	case 7:  str = "G-"; break;
	case 8:  str = "G#"; break;
	case 9:  str = "A-"; break;
	case 10: str = "A#"; break;
	case 11: str = "B-"; break;
	default: str = "?-"; break;
	}

	delta = lf - ((lf+50)/100)*100;

	str += (char)('0'+((lf+50)/100)/12);

	return str;
}
