// TunerDlg.h : header file
//

#if !defined(AFX_TUNERDLG_H__81771587_74B7_11D5_9F4B_B09E77CB0000__INCLUDED_)
#define AFX_TUNERDLG_H__81771587_74B7_11D5_9F4B_B09E77CB0000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTunerDlg dialog

class CTunerDlg : public CDialog
{
// Construction
public:
	CString Note(float freq,int& delta);
	CString m_sNote;
	int m_nDelta;
	void AddBuffer();
	void MMResult(MMRESULT res);
	short* m_buffer;
	CTunerDlg(CWnd* pParent = NULL);	// standard constructor
	~CTunerDlg();

// Dialog Data
	//{{AFX_DATA(CTunerDlg)
	enum { IDD = IDD_TUNER_DIALOG };
	CProgressCtrl	m_progress1;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTunerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	HWAVEIN m_hwi;

	// Generated message map functions
	//{{AFX_MSG(CTunerDlg)
	afx_msg LRESULT OnMMData(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnNewBuffer(WPARAM wParam, LPARAM lParam);
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TUNERDLG_H__81771587_74B7_11D5_9F4B_B09E77CB0000__INCLUDED_)
