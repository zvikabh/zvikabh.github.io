// AlarmDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WakeUp.h"
#include "WakeUpDlg.h"
#include "MixFlakes.h"
#include "AlarmDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAlarmDlg dialog


CAlarmDlg::CAlarmDlg(const CWakeUpDlg* pData, CWnd* pParent /*=NULL*/)
	: CDialog(CAlarmDlg::IDD, pParent)
{
	m_pData = pData;
	m_pMixer = 0;
	//{{AFX_DATA_INIT(CAlarmDlg)
	m_strMessage = _T("");
	//}}AFX_DATA_INIT
}


void CAlarmDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAlarmDlg)
	DDX_Text(pDX, IDC_EDIT1, m_strMessage);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAlarmDlg, CDialog)
	//{{AFX_MSG_MAP(CAlarmDlg)
	ON_BN_CLICKED(IDOK, OnClose)
	ON_BN_CLICKED(IDCANCEL, OnClose)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAlarmDlg message handlers

BOOL CAlarmDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	SelectWakeupMessage();

	if(m_pData->m_bVuFade) {
		m_pMixer = new CMixFlakes;
		if(!m_pMixer->IsOK()) {
			AfxMessageBox("Can't open mixer control; volume fade-in will be disabled.");
			delete m_pMixer;
			m_pMixer=0;
		}
		m_nOrigVolume = m_pMixer->GetVolume();
		m_nTime=0;
		SetTimer(20,1000,NULL);
		OnTimer(20);
	}
	
	if(m_pData->m_bPlayWave) {
		if(m_pData->m_bPlayRepeat)
			PlaySound(m_pData->m_strWave,NULL,SND_ASYNC|SND_LOOP);
		else
			PlaySound(m_pData->m_strWave,NULL,SND_ASYNC);
	}

	if(m_pData->m_bExecApp) {
		WinExec("\"" + m_pData->m_strApp + "\" " + m_pData->m_strParam,SW_SHOW);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAlarmDlg::OnClose() 
{
	if(m_pMixer) {
		m_pMixer->SetVolume(m_nOrigVolume);
		delete m_pMixer;
	}

	if(m_pData->m_bPlayWave)
		PlaySound(NULL,NULL,SND_ASYNC);
	
	CDialog::OnOK();
}

void CAlarmDlg::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent != 20)
		return; // not ours

	if(m_pMixer==0)
		return; // mixer error, vol fade in disabled

	m_nTime++;
	float fRatio = (float) m_nTime / m_pData->m_nFadeInTime;
	DWORD nVol;
	if((UINT)m_nTime >= m_pData->m_nFadeInTime) {
		nVol = m_nOrigVolume;
		KillTimer(20);
	} else {
		nVol = (DWORD)(m_nOrigVolume * fRatio);
	}

	m_pMixer->SetVolume(nVol);
}

void CAlarmDlg::SelectWakeupMessage()
{
	int n = AfxGetApp()->GetProfileInt("Settings","NumMessages",0);
	CString str;
	if(n==0) {
		m_strMessage = "Time to get up!";
	} else {
		n = (rand()*n)/RAND_MAX;
		str.Format("%d",n+1);
		m_strMessage = AfxGetApp()->GetProfileString("Messages",str,"Time to get up!!");
	}
	UpdateData(FALSE);
}
