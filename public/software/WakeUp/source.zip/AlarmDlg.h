#if !defined(AFX_ALARMDLG_H__53542F74_621F_11D2_9F4A_4C8D04C10627__INCLUDED_)
#define AFX_ALARMDLG_H__53542F74_621F_11D2_9F4A_4C8D04C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// AlarmDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAlarmDlg dialog

class CAlarmDlg : public CDialog
{
// Construction
public:
	void SelectWakeupMessage();
	int m_nTime;
	DWORD m_nOrigVolume;
	CAlarmDlg(const CWakeUpDlg* pData, CWnd* pParent = NULL);   // standard constructor
protected:
	const CWakeUpDlg* m_pData;
	CMixFlakes* m_pMixer;

// Dialog Data
	//{{AFX_DATA(CAlarmDlg)
	enum { IDD = IDD_ALARM };
	CString	m_strMessage;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAlarmDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAlarmDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALARMDLG_H__53542F74_621F_11D2_9F4A_4C8D04C10627__INCLUDED_)
