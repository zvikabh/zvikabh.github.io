// MixFlakes.cpp: implementation of the CMixFlakes class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WakeUp.h"
#include "MixFlakes.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMixFlakes::CMixFlakes()
{
	// get the number of mixer devices present in the system
	int nNumMixers = ::mixerGetNumDevs();
	m_hMixer = NULL;

	if(nNumMixers < 1) {
		AfxMessageBox("Error: No audio mixers available.");
		return;
	}
	
	::ZeroMemory(&m_mxcaps, sizeof(MIXERCAPS));

	// open the first mixer
	// A "mapper" for audio mixer devices does not currently exist.
	if (::mixerOpen(&m_hMixer,	// save our mixer's handle
					0,			// first mixer
					0,			// no callback
					NULL,		// no callback data
					MIXER_OBJECTF_MIXER) // default setting
		!= MMSYSERR_NOERROR) {
			AfxMessageBox("Error: Can't open audio mixer.");
			return;
	}

	if (::mixerGetDevCaps((UINT)m_hMixer, &m_mxcaps, sizeof(MIXERCAPS))
		!= MMSYSERR_NOERROR) {
			AfxMessageBox("Error: Can't get mixer properties.");
			return;
	}


	// get dwLineID
	MIXERLINE mxl;
	mxl.cbStruct = sizeof(MIXERLINE);
	mxl.dwComponentType = MIXERLINE_COMPONENTTYPE_DST_SPEAKERS;
	if (::mixerGetLineInfo((HMIXEROBJ)m_hMixer,
						   &mxl,
						   MIXER_OBJECTF_HMIXER |
						   MIXER_GETLINEINFOF_COMPONENTTYPE)
		!= MMSYSERR_NOERROR)
		return;

	// get dwControlID
	MIXERCONTROL mxc;
	MIXERLINECONTROLS mxlc;
	mxlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mxlc.dwLineID = mxl.dwLineID;
	mxlc.dwControlType = MIXERCONTROL_CONTROLTYPE_VOLUME;
	mxlc.cControls = 1;
	mxlc.cbmxctrl = sizeof(MIXERCONTROL);
	mxlc.pamxctrl = &mxc;
	if (::mixerGetLineControls((HMIXEROBJ)m_hMixer,
							   &mxlc,
							   MIXER_OBJECTF_HMIXER |
							   MIXER_GETLINECONTROLSF_ONEBYTYPE)
		!= MMSYSERR_NOERROR)
		return;

	// record dwControlID
	m_strDstLineName = mxl.szName;
	m_strVolumeControlName = mxc.szName;
	m_dwMinimum = mxc.Bounds.dwMinimum;
	m_dwMaximum = mxc.Bounds.dwMaximum;
	m_dwVolumeControlID = mxc.dwControlID;
}

CMixFlakes::~CMixFlakes()
{
	BOOL bSucc = true;

	if (m_hMixer != NULL)
	{
		bSucc = (::mixerClose(m_hMixer) == MMSYSERR_NOERROR);
		m_hMixer = NULL;
	}

	if(!bSucc)
		AfxMessageBox("Error while destroying CMixFlakes object.");
}

DWORD CMixFlakes::GetVolume() const
{
	if (!IsOK()) {
			AfxThrowUserException();
			return FALSE;
	}

	MIXERCONTROLDETAILS_UNSIGNED mxcdVolume;
	MIXERCONTROLDETAILS mxcd;
	mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID = m_dwVolumeControlID;
	mxcd.cChannels = 1;
	mxcd.cMultipleItems = 0;
	mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mxcd.paDetails = &mxcdVolume;
	if (::mixerGetControlDetails((HMIXEROBJ)m_hMixer,
								 &mxcd,
								 MIXER_OBJECTF_HMIXER |
								 MIXER_GETCONTROLDETAILSF_VALUE)
		!= MMSYSERR_NOERROR) {
			AfxThrowUserException();
			return FALSE;
	}
	
	return mxcdVolume.dwValue;
}

bool CMixFlakes::SetVolume(DWORD dwVolume)
{
	if(!IsOK())
		return FALSE;

	MIXERCONTROLDETAILS_UNSIGNED mxcdVolume = { dwVolume };
	MIXERCONTROLDETAILS mxcd;
	mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID = m_dwVolumeControlID;
	mxcd.cChannels = 1;
	mxcd.cMultipleItems = 0;
	mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mxcd.paDetails = &mxcdVolume;
	if (::mixerSetControlDetails((HMIXEROBJ)m_hMixer,
								 &mxcd,
								 MIXER_OBJECTF_HMIXER |
								 MIXER_SETCONTROLDETAILSF_VALUE)
		!= MMSYSERR_NOERROR)
		return FALSE;
	
	return TRUE;
}

bool CMixFlakes::IsOK() const
{
	if (m_hMixer == NULL || m_strDstLineName.IsEmpty() || m_strVolumeControlName.IsEmpty())
		return false;
	else
		return true;
}
