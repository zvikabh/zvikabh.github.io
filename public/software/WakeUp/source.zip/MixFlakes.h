// MixFlakes.h: interface for the CMixFlakes class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MIXFLAKES_H__1FFA7FC2_37AC_11D4_9F4A_00105AB23840__INCLUDED_)
#define AFX_MIXFLAKES_H__1FFA7FC2_37AC_11D4_9F4A_00105AB23840__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Audio mixer wrapper functions
// Zvika Ben-Haim 2000
// Portions copyright (c) 1998 by chensu

class CMixFlakes : public CObject  
{
public:
	bool IsOK() const;
	CMixFlakes();
	virtual ~CMixFlakes();
	DWORD GetVolume() const; // throws user exception on error
	bool SetVolume(DWORD dwVolume);
protected:
	CString m_strDstLineName;
	CString m_strVolumeControlName;
	DWORD m_dwMinimum,m_dwMaximum; // extreme values of mixer
	DWORD m_dwVolumeControlID;
	MIXERCAPS m_mxcaps;
	HMIXER m_hMixer;
};

#endif // !defined(AFX_MIXFLAKES_H__1FFA7FC2_37AC_11D4_9F4A_00105AB23840__INCLUDED_)
