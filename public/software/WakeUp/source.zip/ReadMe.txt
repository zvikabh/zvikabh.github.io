Modifications since last released version:

1. Corrected bug which caused volume to pan to left when using fade-in.
2. Increased maximum fade-in time to 5 minutes (300 sec).