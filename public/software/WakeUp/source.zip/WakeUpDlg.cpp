// WakeUpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WakeUp.h"
#include "WakeUpDlg.h"
#include "MixFlakes.h"
#include "AlarmDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWakeUpDlg dialog

CWakeUpDlg::CWakeUpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWakeUpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWakeUpDlg)
	m_bExecApp = FALSE;
	m_bPlayRepeat = FALSE;
	m_bPlayWave = FALSE;
	m_strApp = _T("");
	m_strTime = _T("");
	m_strWave = _T("");
	m_bEnabled = FALSE;
	m_strParam = _T("");
	m_bVuFade = FALSE;
	m_nFadeInTime = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CWakeUpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWakeUpDlg)
	DDX_Check(pDX, IDC_CHK_EXEC_APP, m_bExecApp);
	DDX_Check(pDX, IDC_CHK_PLAY_REPEAT, m_bPlayRepeat);
	DDX_Check(pDX, IDC_CHK_PLAY_WAVE, m_bPlayWave);
	DDX_Text(pDX, IDC_ED_APP_NAME, m_strApp);
	DDX_Text(pDX, IDC_ED_TIME, m_strTime);
	DDV_MaxChars(pDX, m_strTime, 5);
	DDX_Text(pDX, IDC_ED_WAVE_FILE, m_strWave);
	DDX_Check(pDX, IDC_CHK_ENABLE, m_bEnabled);
	DDX_Text(pDX, IDC_ED_PARAM, m_strParam);
	DDX_Check(pDX, IDC_CHK_VU_FADE, m_bVuFade);
	DDX_Text(pDX, IDC_ED_FADE_IN_TIME, m_nFadeInTime);
	DDV_MinMaxUInt(pDX, m_nFadeInTime, 0, 60000);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWakeUpDlg, CDialog)
	//{{AFX_MSG_MAP(CWakeUpDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_CLOSE, OnClose)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BTN_BRWS_WAVE, OnBrwsWave)
	ON_BN_CLICKED(IDC_BTN_BRWS_APP, OnBrwsApp)
	ON_BN_CLICKED(IDC_BTN_BRWS_PARAM, OnBrwsParam)
	ON_BN_CLICKED(IDC_BTN_TEST, OnTest)
	ON_BN_CLICKED(IDC_BTN_HIDE, OnHide)
	ON_MESSAGE(WM_SYSTRAY_CALLBACK,OnSysTrayCallback)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWakeUpDlg message handlers

BOOL CWakeUpDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	LoadSettings();
#	ifdef _DEBUG
		SetTimer(1,3000,NULL);
#	else
		SetTimer(1,30000,NULL);
#	endif
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWakeUpDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CWakeUpDlg::OnDestroy()
{
	NOTIFYICONDATA nid;

	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hWnd = GetSafeHwnd();
	nid.hIcon = 0;
	strcpy(nid.szTip,"WakeUp");
	nid.uCallbackMessage = WM_SYSTRAY_CALLBACK;
	nid.uFlags = NIF_MESSAGE|NIF_TIP|NIF_ICON;
	nid.uID = 1;

	Shell_NotifyIcon(NIM_DELETE,&nid);

	WinHelp(0L, HELP_QUIT);
	CDialog::OnDestroy();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWakeUpDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWakeUpDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CWakeUpDlg::LoadSettings()
{
	m_bExecApp = AfxGetApp()->GetProfileInt("Settings","bExecApp",FALSE);
	m_bPlayRepeat = AfxGetApp()->GetProfileInt("Settings","bPlayRepeat",TRUE);
	m_bPlayWave = AfxGetApp()->GetProfileInt("Settings","bPlayWave",TRUE);
	m_bEnabled = AfxGetApp()->GetProfileInt("Settings","bEnabled",TRUE);
	m_bVuFade = AfxGetApp()->GetProfileInt("Settings","bVuFade",TRUE);
	m_strApp = AfxGetApp()->GetProfileString("Settings","strApp","");
	m_strTime = AfxGetApp()->GetProfileString("Settings","strTime","06:00");
	m_strWave = AfxGetApp()->GetProfileString("Settings","strWave","Alarm.wav");
	m_strParam = AfxGetApp()->GetProfileString("Settings","strParam","");

	CSpinButtonCtrl* pSpin = (CSpinButtonCtrl*) GetDlgItem(IDC_SPIN1);
	pSpin->SetRange32(0,60000);
	m_nFadeInTime = AfxGetApp()->GetProfileInt("Settings","nFadeInTime",30);
	
	UpdateData(FALSE);
}

void CWakeUpDlg::SaveSettings()
{
	UpdateData(TRUE);
	AfxGetApp()->WriteProfileInt("Settings","bExecApp",m_bExecApp);
	AfxGetApp()->WriteProfileInt("Settings","bPlayRepeat",m_bPlayRepeat);
	AfxGetApp()->WriteProfileInt("Settings","bPlayWave",m_bPlayWave);
	AfxGetApp()->WriteProfileInt("Settings","bEnabled",m_bEnabled);
	AfxGetApp()->WriteProfileInt("Settings","bVuFade",m_bVuFade);
	AfxGetApp()->WriteProfileInt("Settings","nFadeInTime",m_nFadeInTime);
	AfxGetApp()->WriteProfileString("Settings","strApp",m_strApp);
	AfxGetApp()->WriteProfileString("Settings","strTime",m_strTime);
	AfxGetApp()->WriteProfileString("Settings","strWave",m_strWave);
	AfxGetApp()->WriteProfileString("Settings","strParam",m_strParam);
}

void CWakeUpDlg::OnClose() 
{
	OnOK();
}

void CWakeUpDlg::OnOK() 
{
	SaveSettings();
	
	CDialog::OnOK();
}

void CWakeUpDlg::OnTimer(UINT nIDEvent) 
{
	SYSTEMTIME time;
	struct { int nHour,nMinute; } tNow, tAlarm;
	int nDiff;

	UpdateData(TRUE);
	if(!m_bEnabled) // alarm not active, so forget it
		return;

	GetLocalTime(&time);
	tNow.nHour = (int) time.wHour;
	tNow.nMinute = (int) time.wMinute;

	if(sscanf(m_strTime,"%d:%d",&tAlarm.nHour,&tAlarm.nMinute) != 2 ||
		tAlarm.nHour>23 || tAlarm.nHour<0 || 
		tAlarm.nMinute>59 || tAlarm.nMinute<0) {
			AfxMessageBox(IDS_INVALID_TIME);
			return;
	}

	nDiff = (tNow.nHour - tAlarm.nHour)*60 + (tNow.nMinute - tAlarm.nMinute);
	if(nDiff>=0 && nDiff<15) {

		// hide the system tray icon and show the window
		NOTIFYICONDATA nid;
		nid.cbSize = sizeof(NOTIFYICONDATA);
		nid.hWnd = GetSafeHwnd();
		nid.hIcon = 0;
		strcpy(nid.szTip,"WakeUp");
		nid.uCallbackMessage = WM_SYSTRAY_CALLBACK;
		nid.uFlags = NIF_MESSAGE|NIF_TIP|NIF_ICON;
		nid.uID = 1;
		Shell_NotifyIcon(NIM_DELETE,&nid);
		ShowWindow(SW_SHOW);

		CAlarmDlg dlg(this);
		m_bEnabled = FALSE;
		UpdateData(FALSE);
		dlg.DoModal();
	}
}

void CWakeUpDlg::OnBrwsWave() 
{
	UpdateData(TRUE);
	CFileDialog dlg(TRUE,"wav",m_strWave,OFN_HIDEREADONLY,
		"Wave Files (*.wav)|*.wav|All Files (*.*)|*.*||");
	if(dlg.DoModal()==IDOK) {
		m_strWave = dlg.GetPathName();
		UpdateData(FALSE);
	}
}

void CWakeUpDlg::OnBrwsApp() 
{
	UpdateData(TRUE);
	CFileDialog dlg(TRUE,m_strApp,m_strApp,OFN_HIDEREADONLY,
		"Executable Files|*.exe; *.com; *.bat; *.pif|All Files (*.*)|*.*||");
	if(dlg.DoModal()==IDOK) {
		m_strApp = dlg.GetPathName();
		UpdateData(FALSE);
	}
}

void CWakeUpDlg::OnBrwsParam() 
{
	UpdateData(TRUE);
	CFileDialog dlg(TRUE,NULL,m_strApp,OFN_HIDEREADONLY,
		"All Files (*.*)|*.*||");
	if(dlg.DoModal()==IDOK) {
		m_strParam = "\"" + dlg.GetPathName() + "\"";
		UpdateData(FALSE);
	}
	
}

void CWakeUpDlg::OnTest() 
{
		CAlarmDlg dlg(this);
		UpdateData(TRUE);
		m_bEnabled = FALSE;
		UpdateData(FALSE);
		dlg.DoModal();
}

void CWakeUpDlg::OnHide() 
{
	NOTIFYICONDATA nid;

	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hIcon = (HICON)LoadImage(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDR_MAINFRAME),
		IMAGE_ICON,16,16,0);
	nid.hWnd = GetSafeHwnd();
	strcpy(nid.szTip,"WakeUp");
	nid.uCallbackMessage = WM_SYSTRAY_CALLBACK;
	nid.uFlags = NIF_ICON|NIF_MESSAGE|NIF_TIP;
	nid.uID = 1;

	Shell_NotifyIcon(NIM_ADD,&nid);

	DestroyIcon(nid.hIcon);

	ShowWindow(SW_HIDE);
}

afx_msg LRESULT CWakeUpDlg::OnSysTrayCallback(WPARAM wParam, LPARAM lParam)
{
	switch(lParam) {
	case WM_LBUTTONDOWN:
		// User clicked on the taskbar icon; display the full window.

		NOTIFYICONDATA nid;

		nid.cbSize = sizeof(NOTIFYICONDATA);
		nid.hWnd = GetSafeHwnd();
		nid.hIcon = 0;
		strcpy(nid.szTip,"WakeUp");
		nid.uCallbackMessage = WM_SYSTRAY_CALLBACK;
		nid.uFlags = NIF_MESSAGE|NIF_TIP|NIF_ICON;
		nid.uID = 1;

		Shell_NotifyIcon(NIM_DELETE,&nid);

		ShowWindow(SW_SHOW);
		break;
	}

	return (LRESULT) 1;
}
