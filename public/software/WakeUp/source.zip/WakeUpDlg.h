// WakeUpDlg.h : header file
//

#if !defined(AFX_WAKEUPDLG_H__53542F68_621F_11D2_9F4A_4C8D04C10627__INCLUDED_)
#define AFX_WAKEUPDLG_H__53542F68_621F_11D2_9F4A_4C8D04C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CWakeUpDlg dialog

class CWakeUpDlg : public CDialog
{
// Construction
public:
	void SaveSettings();
	void LoadSettings();
	CWakeUpDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CWakeUpDlg)
	enum { IDD = IDD_WAKEUP_DIALOG };
	BOOL	m_bExecApp;
	BOOL	m_bPlayRepeat;
	BOOL	m_bPlayWave;
	CString	m_strApp;
	CString	m_strTime;
	CString	m_strWave;
	BOOL	m_bEnabled;
	CString	m_strParam;
	BOOL	m_bVuFade;
	UINT	m_nFadeInTime;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWakeUpDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	afx_msg LRESULT OnSysTrayCallback(WPARAM wParam, LPARAM lParam);

	// Generated message map functions
	//{{AFX_MSG(CWakeUpDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBrwsWave();
	afx_msg void OnBrwsApp();
	afx_msg void OnBrwsParam();
	afx_msg void OnTest();
	afx_msg void OnHide();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WAKEUPDLG_H__53542F68_621F_11D2_9F4A_4C8D04C10627__INCLUDED_)
