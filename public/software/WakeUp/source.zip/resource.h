//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WakeUp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WAKEUP_DIALOG               102
#define IDS_INVALID_TIME                102
#define IDS_WAKE_UP_CALL                103
#define IDR_MAINFRAME                   128
#define IDD_ALARM                       129
#define IDS_MESSAGES                    1000
#define IDC_ED_TIME                     1002
#define IDC_CHK_PLAY_WAVE               1003
#define IDC_ED_WAVE_FILE                1004
#define IDC_BTN_BRWS_WAVE               1005
#define IDC_CHK_PLAY_REPEAT             1006
#define IDC_CHK_EXEC_APP                1007
#define IDC_ED_APP_NAME                 1008
#define IDC_BTN_BRWS_APP                1009
#define IDC_BTN_CLOSE                   1010
#define IDC_CHK_ENABLE                  1011
#define IDC_ED_PARAM                    1012
#define IDC_BTN_BRWS_PARAM              1013
#define IDC_BTN_TEST                    1014
#define IDC_EDIT1                       1015
#define IDC_CHK_VU_FADE                 1015
#define IDC_ED_FADE_IN_TIME             1016
#define IDC_SPIN1                       1017
#define IDC_BTN_HIDE                    1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
