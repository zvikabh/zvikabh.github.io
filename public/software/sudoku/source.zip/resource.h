//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Sudoku.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SUDOKU_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003
#define IDC_EDIT5                       1004
#define IDC_EDIT6                       1005
#define IDC_EDIT7                       1006
#define IDC_EDIT8                       1007
#define IDC_EDIT9                       1008
#define IDC_EDIT10                      1009
#define IDC_EDIT11                      1010
#define IDC_EDIT12                      1011
#define IDC_EDIT13                      1012
#define IDC_EDIT14                      1013
#define IDC_EDIT15                      1014
#define IDC_EDIT16                      1015
#define IDC_EDIT17                      1016
#define IDC_EDIT18                      1017
#define IDC_EDIT19                      1018
#define IDC_EDIT20                      1019
#define IDC_EDIT21                      1020
#define IDC_EDIT22                      1021
#define IDC_EDIT23                      1022
#define IDC_EDIT24                      1023
#define IDC_EDIT25                      1024
#define IDC_EDIT26                      1025
#define IDC_EDIT27                      1026
#define IDC_EDIT28                      1027
#define IDC_EDIT29                      1028
#define IDC_EDIT30                      1029
#define IDC_EDIT31                      1030
#define IDC_EDIT32                      1031
#define IDC_EDIT33                      1032
#define IDC_EDIT34                      1033
#define IDC_EDIT35                      1034
#define IDC_EDIT36                      1035
#define IDC_EDIT37                      1036
#define IDC_EDIT38                      1037
#define IDC_EDIT39                      1038
#define IDC_EDIT40                      1039
#define IDC_EDIT41                      1040
#define IDC_EDIT42                      1041
#define IDC_EDIT43                      1042
#define IDC_EDIT44                      1043
#define IDC_EDIT45                      1044
#define IDC_EDIT46                      1045
#define IDC_EDIT47                      1046
#define IDC_EDIT48                      1047
#define IDC_EDIT49                      1048
#define IDC_EDIT50                      1049
#define IDC_EDIT51                      1050
#define IDC_EDIT52                      1051
#define IDC_EDIT53                      1052
#define IDC_EDIT54                      1053
#define IDC_EDIT55                      1054
#define IDC_EDIT56                      1055
#define IDC_EDIT57                      1056
#define IDC_EDIT58                      1057
#define IDC_EDIT59                      1058
#define IDC_EDIT60                      1059
#define IDC_EDIT61                      1060
#define IDC_EDIT62                      1061
#define IDC_EDIT63                      1062
#define IDC_EDIT64                      1063
#define IDC_EDIT65                      1064
#define IDC_EDIT66                      1065
#define IDC_EDIT67                      1066
#define IDC_EDIT68                      1067
#define IDC_EDIT69                      1068
#define IDC_EDIT70                      1069
#define IDC_EDIT71                      1070
#define IDC_EDIT72                      1071
#define IDC_EDIT73                      1072
#define IDC_EDIT74                      1073
#define IDC_EDIT75                      1074
#define IDC_EDIT76                      1075
#define IDC_EDIT77                      1076
#define IDC_EDIT78                      1077
#define IDC_EDIT79                      1078
#define IDC_EDIT80                      1079
#define IDC_EDIT81                      1080

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
