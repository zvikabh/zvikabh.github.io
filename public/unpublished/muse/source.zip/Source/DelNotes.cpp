// DelNotes.cpp : implementation file
//

#include "stdafx.h"
#include "muse.h"
#include "DelNotes.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgDelNotes dialog


CDlgDelNotes::CDlgDelNotes(int nNotes,CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDelNotes::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgDelNotes)
	m_nFrom = 0;
	m_nTo = 0;
	//}}AFX_DATA_INIT
	m_nNotes = nNotes;
}


void CDlgDelNotes::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgDelNotes)
	DDX_Text(pDX, IDC_EDIT1, m_nFrom);
	DDX_Text(pDX, IDC_EDIT2, m_nTo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgDelNotes, CDialog)
	//{{AFX_MSG_MAP(CDlgDelNotes)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgDelNotes message handlers

BOOL CDlgDelNotes::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CString str;
	str.Format(IDS_DEL_NOTE_INFO,m_nNotes);
	GetDlgItem(IDC_INFO)->SetWindowText(str);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
