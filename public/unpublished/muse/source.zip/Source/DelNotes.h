#if !defined(AFX_DELNOTES_H__067688CB_644C_11D3_9F4A_306B06C10627__INCLUDED_)
#define AFX_DELNOTES_H__067688CB_644C_11D3_9F4A_306B06C10627__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DelNotes.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgDelNotes dialog

class CDlgDelNotes : public CDialog
{
// Construction
public:
	CDlgDelNotes(int nNotes,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgDelNotes)
	enum { IDD = IDD_DEL_NOTES };
	int		m_nFrom;
	int		m_nTo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgDelNotes)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int m_nNotes;

	// Generated message map functions
	//{{AFX_MSG(CDlgDelNotes)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DELNOTES_H__067688CB_644C_11D3_9F4A_306B06C10627__INCLUDED_)
