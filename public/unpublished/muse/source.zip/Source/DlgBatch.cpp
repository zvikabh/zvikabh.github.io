// DlgBatch.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "MainFrm.h"
#include "SegParam.h"
#include "MuseDoc.h"
#include "DlgBatch.h"
#include "DlgNotes.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//#define STAT_DEBUG // statistical debug mode: writes detailed output to
				   // correct.txt and incorrect.txt

/////////////////////////////////////////////////////////////////////////////
// CDlgBatch dialog


CDlgBatch::CDlgBatch(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgBatch::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgBatch)
	m_sFiles = _T("");
	m_sOutput = _T("");
	m_sStatus = _T("");
	//}}AFX_DATA_INIT
}


void CDlgBatch::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgBatch)
	DDX_Text(pDX, IDC_FILES, m_sFiles);
	DDX_Text(pDX, IDC_OUTPUT, m_sOutput);
	DDX_Text(pDX, IDC_STATUS, m_sStatus);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgBatch, CDialog)
	//{{AFX_MSG_MAP(CDlgBatch)
	ON_BN_CLICKED(IDC_LOAD_FILE_LIST, OnLoadFileList)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_ADD_FILE, OnAddFile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgBatch message handlers

void CDlgBatch::OnLoadFileList() 
{
	CFileDialog dlg(TRUE, "txt", NULL, OFN_HIDEREADONLY|OFN_FILEMUSTEXIST,
		"Lists of Files (*.txt)|*.txt|All Files (*.*)|*.*||");
	if(dlg.DoModal()==IDOK) {
		m_sFiles = "";
		try {
			CStdioFile file(dlg.GetPathName(), CFile::modeRead|CFile::typeText);
			CString str;
			while(file.ReadString(str))
				m_sFiles += str + "\r\n";
		}
		catch(CException* e) {
			AfxMessageBox("An error occured while reading the file.");
			e->Delete();
		}
		UpdateData(false);
	}
}

void CDlgBatch::OnBrowse() 
{
	CFileDialog dlg(FALSE, "txt", NULL, OFN_HIDEREADONLY,
		"Text Files (*.txt)|*.txt|All Files (*.*)|*.*||");
	if(dlg.DoModal()==IDOK) {
		m_sOutput = dlg.GetPathName();
		UpdateData(false);
	}
}

void CDlgBatch::OnStart() 
{
	SaveSettings();
	CString str = m_sFiles;
	char * p1 = str.GetBuffer(0);
	char * p2 = strtok(p1, "\r\n");
	int nTotal=0,nBest=0,nTop5=0,n;

	// load segmentation settings (do this once for entire batch process)
	CSegParam dlg("Segmentation Parameters");
	dlg.Create(NULL,WS_SYSMENU | WS_POPUP | WS_CAPTION | DS_MODALFRAME);
	dlg.SetActivePage(&dlg.p2);
	dlg.SetActivePage(&dlg.p3);
	dlg.DestroyWindow();

	BeginWaitCursor();
	try {
		OFSTRUCT of;
		OpenFile(m_sOutput,&of,OF_EXIST);
		if(of.nErrCode != ERROR_FILE_NOT_FOUND) {
			if(AfxMessageBox("Output file already exists. Do you want to overwrite?",MB_YESNO)==IDNO)
				return;
			if(remove(m_sOutput)!=0) {
				AfxMessageBox("Unable to overwrite the file. It may be read-only.");
				return;
			}
		}
		CStdioFile file(m_sOutput,CFile::modeWrite|CFile::modeCreate|CFile::modeNoTruncate);
		while(p2) {
			n=ProcessFile(p2,file,dlg);
			if(n!=-1) {
				// add this song to statistics
				nTotal++;
				if(n==1) nBest++;
				if(n<=5) nTop5++;
			}
			p2 = strtok(NULL, "\r\n");
		}
		str.Format("\nNumber of Top Matches: %d\nNumber of Top 5 Matches: %d\nNumber of Songs: %d\n",
			nBest,nTop5,nTotal);
		file.WriteString(str);
	}
	catch(CFileException* e) {
		e->Delete();
		AfxMessageBox("An error occured while writing to the output file.");
		return;
	}
	EndWaitCursor();
	AfxMessageBox("Batch execution completed!");
	CDialog::OnOK();
}

int CDlgBatch::ProcessFile(const char* filename, CStdioFile& output, const CSegParam& dlgSegParam)
{
	CMainFrame * pMainFrame = (CMainFrame*) AfxGetMainWnd();
	ASSERT_KINDOF(CMainFrame,pMainFrame);
	CMDIChildWnd * pChild = pMainFrame->MDIGetActive();
	CMuseDoc * pDoc = (CMuseDoc*) pChild->GetActiveDocument();
	ASSERT_KINDOF(CMuseDoc, pDoc);
	int i;

	// Read filename and correct value from batch line
	char fname[80];
	int nCorrect;
	switch(sscanf(filename,"%s %d",fname,&nCorrect)) {
	case 0:
		AfxMessageBox("Invalid filename specified in batch execution.");
		return -1;
	case 1:
		nCorrect=-1;
		break;
	case 2:
		break;
	}
	CString str(fname);
	
	// Update display
	GetDlgItem(IDC_STATUS)->SetWindowText("Processing "+str+"...");

	// Open the file
	if(!pDoc->DoFileOpenWave(&str))
		return -1;

#ifdef STAT_DEBUG
	// statistical debug mode: open statistics files
	FILE* correct = fopen("c:\\windows\\desktop\\correct.txt","at");
	FILE* incorrect = fopen("c:\\windows\\desktop\\incorrect.txt","at");
#endif

	// Find pitch and perform segmentation
	pDoc->OnAnalyzePitch();
	pDoc->DoSegmentation(dlgSegParam);

	// Perform search
	CDlgNotes dlg(pDoc);
	CArray<int,int> result;
	switch(AfxGetApp()->GetProfileInt("SearchParam","nSearchMode",2)) {
	case 0:
		dlg.SearchParsons(pDoc,result);
		break;
	case 1:
		dlg.SearchFrequency(pDoc,result);
		break;
	case 2:
		dlg.SearchFreqDur(pDoc,result);
		break;
	default:
		ASSERT(0);
		AfxMessageBox("Invalid registry entry.");
		return -1;
	}

	// Write results to file
	str.Format("Matches for %3d-note file: %s\n",pDoc->m_segment.GetSize(),fname);
	if(nCorrect==-1) {
		// detailed mode
		output.WriteString(str);
		for(i=0; i<10; i++) {
			str.Format("%2d: (%d%%) %40s   N[%d]\n",i+1,result[2*i+1],
				(const char*)(pDoc->m_database[result[2*i]].m_name), result[2*i]);
			output.WriteString(str);
		}
		output.WriteString("\n");
#ifdef STAT_DEBUG
		fclose(correct);
		fclose(incorrect);
#endif
		return -1;
	} else {
		// undetailed mode
		bool flag=false;
		output.WriteString(str);
		for(i=0; i<result.GetSize(); i+=2) {
			if(nCorrect == result[i]) {
				str.Format("%2d: (%d%%) %40s   N[%d]\n\n",i/2+1,result[i+1],
					(const char*)(pDoc->m_database[result[i]].m_name), result[i]);
				flag=true;
#ifdef STAT_DEBUG
				fprintf(correct,"%d\n",result[i+1]);
#else
				break;
#endif
			} else {
#ifdef STAT_DEBUG
				fprintf(incorrect,"%d\n",result[i+1]);
#endif
			}
		}
		if(!flag) {
			str.Format("No Match\n\n");
			AfxMessageBox("Warning! No match! You might be running on an empty database file.");
#ifdef STAT_DEBUG
			fclose(correct);
			fclose(incorrect);
#endif
			return -1;
		}
		output.WriteString(str);
#ifdef STAT_DEBUG
		fclose(correct);
		fclose(incorrect);
#endif
		return (i/2)+1;
	}
}

void CDlgBatch::OnAddFile() 
{
	UpdateData(true);
	CFileDialog dlg(TRUE, "raw", NULL, OFN_HIDEREADONLY|OFN_FILEMUSTEXIST,
		"Raw Sound Files (*.raw)|*.raw|PCM Sound Files (*.pcm)|*.pcm|All Files (*.*)|*.*||");
	if(dlg.DoModal()==IDOK) {
		m_sFiles += dlg.GetPathName() + "\r\n";
		UpdateData(false);
	}
}

void CDlgBatch::SaveSettings()
{
	UpdateData(true);
	AfxGetApp()->WriteProfileString("Batch","Files",m_sFiles);
	AfxGetApp()->WriteProfileString("Batch","Output",m_sOutput);
}

void CDlgBatch::LoadSettings()
{
	m_sFiles = AfxGetApp()->GetProfileString("Batch","Files","");
	m_sOutput= AfxGetApp()->GetProfileString("Batch","Output","");
	UpdateData(false);
}

BOOL CDlgBatch::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	LoadSettings();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
