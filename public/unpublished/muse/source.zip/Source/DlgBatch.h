#if !defined(AFX_DLGBATCH_H__9EBB33A1_4CB0_11D3_9F4A_346B06C10627__INCLUDED_)
#define AFX_DLGBATCH_H__9EBB33A1_4CB0_11D3_9F4A_346B06C10627__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgBatch.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgBatch dialog

class CDlgBatch : public CDialog
{
// Construction
public:
	void LoadSettings();
	void SaveSettings();
	int ProcessFile(const char * filename, CStdioFile& output, const CSegParam& dlgSegParam);
	CDlgBatch(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgBatch)
	enum { IDD = IDD_BATCH };
	CString	m_sFiles;
	CString	m_sOutput;
	CString	m_sStatus;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgBatch)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgBatch)
	afx_msg void OnLoadFileList();
	afx_msg void OnBrowse();
	afx_msg void OnStart();
	afx_msg void OnAddFile();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGBATCH_H__9EBB33A1_4CB0_11D3_9F4A_346B06C10627__INCLUDED_)
