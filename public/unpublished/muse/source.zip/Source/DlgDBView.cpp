// DlgDBView.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "SegParam.h"
#include "MuseDoc.h"
#include "DlgDBView.h"
#include "DlgNoteWriter.h"
#include "DlgSearchName.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgDBView dialog


CDlgDBView::CDlgDBView(CMuseDoc* pDoc, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDBView::IDD, pParent)
{
	m_pDoc = pDoc;
	//{{AFX_DATA_INIT(CDlgDBView)
	//}}AFX_DATA_INIT
}


void CDlgDBView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgDBView)
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgDBView, CDialog)
	//{{AFX_MSG_MAP(CDlgDBView)
	ON_BN_CLICKED(IDC_SORT, OnSort)
	ON_BN_CLICKED(IDC_STAT, OnStat)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	ON_NOTIFY(LVN_KEYDOWN, IDC_LIST1, OnKeydownList1)
	ON_BN_CLICKED(IDC_FIND_NAME, OnFindName)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgDBView message handlers

BOOL CDlgDBView::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_list.InsertColumn(0,"Song Name",LVCFMT_LEFT,250,1);
	m_list.InsertColumn(1,"Notes",LVCFMT_LEFT,35,2);
	m_list.InsertColumn(2,"#",LVCFMT_LEFT,35,0);

	RefreshList();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgDBView::RefreshList()
{
	int i;
	CString str;

	m_list.DeleteAllItems();

	if(m_pDoc==0)
		return;

	for(i=0; i<m_pDoc->m_database.GetSize(); i++) {
		m_list.InsertItem(i,m_pDoc->m_database[i].m_name);
		m_list.SetItem(i,0,0,0,0,0,0,0);
		str.Format("%d",m_pDoc->m_database[i].m_durnote.GetSize());
		m_list.SetItemText(i,1,str);
		str.Format("%d",i);
		m_list.SetItemText(i,2,str);
	}
}

int __cdecl SongCompareFunc(const void *elem1, const void *elem2)
{
	CSong *psong1=(CSong*)elem1, *psong2=(CSong*)elem2;
	return psong1->m_name.CompareNoCase(psong2->m_name);
}

void CDlgDBView::OnSort() 
{
	CSong* array = m_pDoc->m_database.GetData();
	if(array==NULL)
		return; // empty database
	qsort(array,m_pDoc->m_database.GetSize(),sizeof(CSong),SongCompareFunc);
	RefreshList();
}


void CDlgDBView::OnStat() 
{
	CString str,s2;
	int i,j,k,max,min;
	
	s2.Format("Number of songs: %d\r\n",m_pDoc->m_database.GetSize());
	max=0;
	min=1000000;
	for(i=j=0; i<m_pDoc->m_database.GetSize(); i++) {
		k=m_pDoc->m_database[i].m_durnote.GetSize();
		j+=k;
		if(k>max)
			max=k;
		if(k<min)
			min=k;
	}
	str.Format("Total number of notes: %d\r\nLongest song: %d notes\r\nShortest song: %d notes\r\n",
		j,max,min);
	s2 += str;

	CDlgInfo dlg("Database Statistics",s2);
	dlg.DoModal();
}

void CDlgDBView::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMList = (NM_LISTVIEW*)pNMHDR; 
    int pos=pNMList->iItem;
	if(pos==-1) return;
	CDlgNoteWriter dlg;
	dlg.m_song = m_pDoc->m_database[pos];
	dlg.GetDataFromSong();

	if(dlg.DoModal()==IDOK) {
		m_pDoc->m_database.SetAt(pos, dlg.m_song);
		m_pDoc->SetModifiedFlag();
	}

	RefreshList();
	
	*pResult = 0;
}


void CDlgDBView::OnKeydownList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;
	POSITION pos;
	int n;
	
	switch(pLVKeyDow->wVKey) {
	case VK_INSERT:
		m_pDoc->AddNote();
		RefreshList();
		break;
	case VK_DELETE:
		pos = m_list.GetFirstSelectedItemPosition();
		if(pos==NULL)
			break;
		n = m_list.GetNextSelectedItem(pos);
		m_pDoc->m_database.RemoveAt(n);
		m_list.DeleteItem(n);
		m_pDoc->SetModifiedFlag();
		break;
	default:
		// ignore other buttons
		break;
	}

	*pResult = 0;
}

void CDlgDBView::OnFindName() 
{
	CDlgSearchName dlg;
	int i;
	if(dlg.DoModal()==IDOK) {
		CString strToFind = dlg.m_sEdit;
		CString strTarget;
		strToFind.MakeLower();
		for(i=0; i<m_pDoc->m_database.GetSize(); i++) {
			strTarget = m_pDoc->m_database[i].m_name;
			strTarget.MakeLower();
			if(strTarget.Find(strToFind) != -1) {
				m_list.SetItemState(i,LVIS_SELECTED,LVIS_SELECTED);
				m_list.EnsureVisible(i,false);
				m_list.SetFocus();
				return;
			}
		}
		AfxMessageBox("The search string was not found.");
	}
}
