#if !defined(AFX_DLGDBVIEW_H__0307EB2E_1F7D_11D3_9F4A_0C8A06C10627__INCLUDED_)
#define AFX_DLGDBVIEW_H__0307EB2E_1F7D_11D3_9F4A_0C8A06C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgDBView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgDBView dialog

class CDlgDBView : public CDialog
{
// Construction
public:
	void RefreshList();
	CDlgDBView(CMuseDoc* pDoc, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgDBView)
	enum { IDD = IDD_VIEW_DB };
	CListCtrl	m_list;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgDBView)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CMuseDoc* m_pDoc;

	// Generated message map functions
	//{{AFX_MSG(CDlgDBView)
	virtual BOOL OnInitDialog();
	afx_msg void OnSort();
	afx_msg void OnStat();
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeydownList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnFindName();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGDBVIEW_H__0307EB2E_1F7D_11D3_9F4A_0C8A06C10627__INCLUDED_)
