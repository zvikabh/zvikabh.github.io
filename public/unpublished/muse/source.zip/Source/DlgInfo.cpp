// DlgInfo.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "DlgInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInfo dialog


CDlgInfo::CDlgInfo(const CString& strTitle, const CString& strData, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInfo::IDD, pParent)
{
	m_strTitle = strTitle;
	m_strData = strData;
	//{{AFX_DATA_INIT(CDlgInfo)
	m_edit = _T("");
	//}}AFX_DATA_INIT
}


void CDlgInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInfo)
	DDX_Text(pDX, IDC_RICHEDIT1, m_edit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInfo, CDialog)
	//{{AFX_MSG_MAP(CDlgInfo)
	ON_BN_CLICKED(IDC_COPY, OnCopy)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInfo message handlers

void CDlgInfo::OnOK() 
{
	// intentionally left blank, see Kruglinski, pp. 127-128
}

BOOL CDlgInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(m_strTitle);
	GetDlgItem(IDC_RICHEDIT1)->SetWindowText(m_strData);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgInfo::OnCopy() 
{
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_RICHEDIT1);
	ASSERT(pEdit!=0);
	pEdit->SetSel(0,-1,TRUE); // select all
	pEdit->Copy();
	pEdit->SetSel(-1,0); // cancel selection
	AfxMessageBox(IDS_INFO_COPIED);
}

void CDlgInfo::OnSave() 
{
	// get the file name
	CFileDialog dlg(FALSE,"txt","*.txt",OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,
		"Text Files (*.txt)|*.txt||");
	if(dlg.DoModal()==IDOK) {
		// get the string to be saved
		CEdit* pEdit = (CEdit*)GetDlgItem(IDC_RICHEDIT1);
		ASSERT(pEdit!=0);
		CString str;
		pEdit->GetWindowText(str);

		// save it
		try {
			CFile file(dlg.GetPathName(),CFile::modeWrite|CFile::modeCreate);
			file.Write(str,str.GetLength());
			file.Close();
		}
		catch(CException* e) {
			AfxMessageBox("Can't write file.");
			e->Delete();
		}
	}
}
