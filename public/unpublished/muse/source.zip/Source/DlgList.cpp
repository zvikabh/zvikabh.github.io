// DlgList.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "DlgList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgList dialog


CDlgList::CDlgList(const CString& title, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgList::IDD, pParent)
{
	m_sTitle = title;
	//{{AFX_DATA_INIT(CDlgList)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgList::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgList)
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgList, CDialog)
	//{{AFX_MSG_MAP(CDlgList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgList message handlers

BOOL CDlgList::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(m_sTitle);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
