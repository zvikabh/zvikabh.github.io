#if !defined(AFX_DLGLIST_H__F8271EE3_8E10_11D2_9F4A_CCF705C10627__INCLUDED_)
#define AFX_DLGLIST_H__F8271EE3_8E10_11D2_9F4A_CCF705C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgList.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgList dialog

class CDlgList : public CDialog
{
// Construction
public:
	CDlgList(const CString& title, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgList)
	enum { IDD = IDD_LIST };
	CListBox	m_list;
	//}}AFX_DATA

protected:
	CString m_sTitle;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgList)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgList)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGLIST_H__F8271EE3_8E10_11D2_9F4A_CCF705C10627__INCLUDED_)
