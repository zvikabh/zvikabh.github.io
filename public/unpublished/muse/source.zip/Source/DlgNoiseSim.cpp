// DlgNoiseSim.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "MuseDoc.h"
#include "DlgNoiseSim.h"
#include "DlgNotes.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgNoiseSim dialog


CDlgNoiseSim::CDlgNoiseSim(CMuseDoc* pDoc, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgNoiseSim::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgNoiseSim)
	m_nFreqNoise = 0;
	m_nDurErr = 0;
	m_nNotes = 0;
	m_nRuns = 0;
	m_bStatis = FALSE;
	//}}AFX_DATA_INIT
	m_pDoc = pDoc;
}


void CDlgNoiseSim::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgNoiseSim)
	DDX_Text(pDX, IDC_EDIT1, m_nFreqNoise);
	DDX_Text(pDX, IDC_EDIT2, m_nDurErr);
	DDX_Text(pDX, IDC_EDIT3, m_nNotes);
	DDX_Text(pDX, IDC_EDIT4, m_nRuns);
	DDX_Check(pDX, IDC_CHECK1, m_bStatis);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgNoiseSim, CDialog)
	//{{AFX_MSG_MAP(CDlgNoiseSim)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgNoiseSim message handlers

void CDlgNoiseSim::LoadSettings()
{
	CWinApp* pApp = AfxGetApp();
	m_nFreqNoise = pApp->GetProfileInt("CDlgNoiseSim","m_nFreqNoise",0);
	m_nDurErr = pApp->GetProfileInt("CDlgNoiseSim","m_nDurErr",0);
	m_nNotes = pApp->GetProfileInt("CDlgNoiseSim","m_nNotes",10);
	m_nRuns = pApp->GetProfileInt("CDlgNoiseSim","m_nRuns",1000);
	m_bStatis = pApp->GetProfileInt("CDlgNoiseSim","m_bStatis",1);
}

void CDlgNoiseSim::SaveSettings()
{
	CWinApp* pApp = AfxGetApp();
	pApp->WriteProfileInt("CDlgNoiseSim","m_nFreqNoise",m_nFreqNoise);
	pApp->WriteProfileInt("CDlgNoiseSim","m_nDurErr",m_nDurErr);
	pApp->WriteProfileInt("CDlgNoiseSim","m_nNotes",m_nNotes);
	pApp->WriteProfileInt("CDlgNoiseSim","m_nRuns",m_nRuns);
	pApp->WriteProfileInt("CDlgNoiseSim","m_bStatis",m_bStatis);
}

BOOL CDlgNoiseSim::OnInitDialog() 
{
	CDialog::OnInitDialog();

	LoadSettings();
	UpdateData(false);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgNoiseSim::OnOK() 
{
	UpdateData(true);
	SaveSettings();
	Simulate();
	
	CDialog::OnOK();
}

// Perform actual simulation
// This function can be called without displaying the dialog, if the member variables
// are manually set to their correct values. When the dialog is displayed, the member
// variables receive default values.
void CDlgNoiseSim::Simulate()
{
	int i,j,nSong,nDivis,n;
	int nTopMatch=0,nTopFive=0,nRuns=0;
	CDlgNotes dlg(m_pDoc);
	CArray<int,int> result;
	CMuseDoc::CSegment seg;
	CSong noisy;
	float fPctTopMatch[5],fPctTopFive[5];

	if(m_pDoc->m_database.GetSize()==0) {
		AfxMessageBox("Database is empty. First open a database file, and then run the noise simulation.");
		return;
	}

	if(m_bStatis)
		nDivis = 5;
	else
		nDivis = 1;

	for(n=0; n<nDivis; n++) {
		nTopMatch=nTopFive=nRuns=0;
		for(i=0; i<m_nRuns/nDivis; i++) {
			// show progress on screen
			CString str;
			str.Format("%d%% - Noise Simulation Running...",100*i/m_nRuns + 100*n/nDivis);
			SetWindowText(str);

			// choose a song
			nSong = random(m_pDoc->m_database.GetSize());
			m_pDoc->m_segment.RemoveAll();
			result.RemoveAll();

			// create (noisy) segment array
			noisy = m_pDoc->m_database[nSong];
			for(j=0; j<noisy.m_durnote.GetSize() && j<m_nNotes; j++) {
				if(random(2)) {
					noisy.m_durnote[j].SetDuration(
						noisy.m_durnote[j].GetDuration()*(random(m_nDurErr)+100)/100);
				} else {
					noisy.m_durnote[j].SetDuration(
						noisy.m_durnote[j].GetDuration()*100/(random(m_nDurErr)+100));
				}
				noisy.m_durnote[j].TransposeCents(random(m_nFreqNoise*2+1)-m_nFreqNoise);
				seg.tstart=seg.start=0;
				seg.tend=seg.end=noisy.m_durnote[j].GetDuration();
				seg.note=noisy.m_durnote[j];
				seg.pitch=8000.f/seg.note.GetFreq();
				m_pDoc->m_segment.Add(seg);
			}

			// Perform search
			switch(AfxGetApp()->GetProfileInt("SearchParam","nSearchMode",2)) {
			case 0:
				dlg.SearchParsons(m_pDoc,result);
				break;
			case 1:
				dlg.SearchFrequency(m_pDoc,result);
				break;
			case 2:
				dlg.SearchFreqDur(m_pDoc,result);
				break;
			default:
				ASSERT(0);
				AfxMessageBox("Invalid registry entry.");
				return;
			}

			// Check if results were correct
			nRuns++;
			if(nSong == result[0])
				nTopMatch++;
			for(j=0; j<10; j+=2) {
				if(nSong==result[j])
					nTopFive++;
			}

			// Write results to output array
			fPctTopMatch[n] = 100.f*(float)nTopMatch/nRuns;
			fPctTopFive[n]  = 100.f*(float)nTopFive/nRuns;
		}
	}

	SetWindowText("Noise Simulation");

	CString str;
	if(m_bStatis) {
		float sx=0,sxx=0,sy=0,syy=0;
		for(n=0; n<5; n++) {
			sx += fPctTopMatch[n];
			sxx += fPctTopMatch[n]*fPctTopMatch[n];
			sy += fPctTopFive[n];
			syy += fPctTopFive[n]*fPctTopFive[n];
		}
		str.Format("Number of Runs: %d\nPercent Top Matches: %.1f%% (� %.1f%%)\nPercent Top Five: %.1f%% (� %.1f%%)",
			m_nRuns,sx/5,(float)sqrt(sxx/5 - sx*sx/25),sy/5,(float)sqrt(syy/5 - sy*sy/25));
	} else {
		str.Format("Number of runs: %d\nNumber of top matches: %d (%d%%)\nNumber of top fives: %d (%d%%)",
			nRuns,nTopMatch,nTopMatch*100/nRuns,nTopFive,nTopFive*100/nRuns);
	}
	AfxMessageBox(str);
}

int random(int nMax)
{
	return (rand()*nMax / RAND_MAX);
}
