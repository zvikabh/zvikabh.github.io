#if !defined(AFX_DLGNOISESIM_H__ADAB4181_58D0_11D3_9F4A_346B06C10627__INCLUDED_)
#define AFX_DLGNOISESIM_H__ADAB4181_58D0_11D3_9F4A_346B06C10627__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgNoiseSim.h : header file
//

int random(int nMax);

/////////////////////////////////////////////////////////////////////////////
// CDlgNoiseSim dialog

class CDlgNoiseSim : public CDialog
{
	public:
		void LoadSettings();
		void SaveSettings();
// Construction
public:
	void Simulate();
	CDlgNoiseSim(CMuseDoc* pDoc, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgNoiseSim)
	enum { IDD = IDD_NOISE_SIM };
	int		m_nFreqNoise;
	int		m_nDurErr;
	int		m_nNotes;
	int		m_nRuns;
	BOOL	m_bStatis;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgNoiseSim)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CMuseDoc* m_pDoc;

	// Generated message map functions
	//{{AFX_MSG(CDlgNoiseSim)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGNOISESIM_H__ADAB4181_58D0_11D3_9F4A_346B06C10627__INCLUDED_)
