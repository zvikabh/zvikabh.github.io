// DlgNoteWriter.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "DlgNoteWriter.h"
#include "DelNotes.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgNoteWriter dialog


CDlgNoteWriter::CDlgNoteWriter(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgNoteWriter::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgNoteWriter)
	m_sSongName = _T("");
	m_sData = _T("");
	m_nNoteLen = 4;
	m_nTempo = 500;
	m_sComments = _T("");
	m_nMode = 0;
	//}}AFX_DATA_INIT
	m_pWave = 0;

	int i;
	for(i=0; i<7; i++)
		m_nKey[i]=0;
}

CDlgNoteWriter::~CDlgNoteWriter()
{
	DeleteWave();
}

void CDlgNoteWriter::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgNoteWriter)
	DDX_Control(pDX, IDC_SCROLLBAR1, m_scroll);
	DDX_Text(pDX, IDC_SONG_NAME, m_sSongName);
	DDX_Text(pDX, IDC_DATA, m_sData);
	DDX_Text(pDX, IDC_NOTE_LEN, m_nNoteLen);
	DDX_Text(pDX, IDC_TEMPO, m_nTempo);
	DDV_MinMaxInt(pDX, m_nTempo, 100, 3000);
	DDX_Text(pDX, IDC_COMMENTS, m_sComments);
	DDX_Radio(pDX, IDC_RADIO1, m_nMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgNoteWriter, CDialog)
	//{{AFX_MSG_MAP(CDlgNoteWriter)
	ON_WM_PAINT()
	ON_WM_LBUTTONUP()
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_BN_CLICKED(IDC_PLAY, OnPlay)
	ON_WM_RBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_NW_HELP_INSTRUC, OnNwHelpInstruc)
	ON_COMMAND(ID_TRANS_DOWN, OnTransDown)
	ON_COMMAND(ID_TRANS_DOWN_OCT, OnTransDownOct)
	ON_COMMAND(ID_TRANS_UP, OnTransUp)
	ON_COMMAND(ID_TRANS_UP_OCT, OnTransUpOct)
	ON_WM_HSCROLL()
	ON_COMMAND(ID_SONG_PLAY, OnSongPlay)
	ON_COMMAND(ID_SONG_STOP, OnSongStop)
	ON_COMMAND(ID_NW_NOTES_DELETE, OnNwNotesDelete)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgNoteWriter message handlers

void CDlgNoteWriter::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	DrawNotes(&dc);
}

void CDlgNoteWriter::DrawNotes(CDC * pdc)
{
	CRect rect,screen;
	GetClientRect(rect);
	rect.top += 10;
	rect.left += 10;
	rect.right -= 10;
	rect.bottom = 95;
	screen=rect;

	int i,j,n,x,y;
	int firstnote = m_scroll.GetScrollPos();

	{
		// draw treble clef
		CDC memdc;
		memdc.CreateCompatibleDC(pdc);
		CBitmap bmp;
		BITMAP bm;
		bmp.LoadBitmap(IDB_TREBLE_CLEF);
		bmp.GetBitmap(&bm);
		memdc.SelectObject(&bmp);
		rect.left += 10;
		rect.top += 20;
		rect.bottom -= 10;
		rect.right = rect.left+15;
		pdc->BitBlt(rect.left,rect.top,bm.bmWidth,bm.bmHeight,&memdc,0,0,SRCCOPY);
		rect=screen;

		// draw bar
		for(i=0; i<5; i++) {
			pdc->MoveTo(rect.left,30+i*10);
			pdc->LineTo(rect.right,30+i*10);
		}

		// draw sharps and flats
		rect.left += 35;
		CBitmap bmSharp, bmFlat;
		bmSharp.LoadBitmap(IDB_SHARP);
		bmSharp.GetBitmap(&bm);
		bmFlat.LoadBitmap(IDB_FLAT);

		for(i=0; i<7; i++) {
			if(m_nKey[i]==0)
				continue;
			memdc.SelectObject(m_nKey[i]==1 ? &bmSharp : &bmFlat);
			pdc->BitBlt(rect.left,
				Note2Y(CNote( (short)(i<4 ? 5 : 4),
							  (short)(i*2-(i>2?1:0)),
							  0))
				- (m_nKey[i]==1 ? 8 : 12),
				bm.bmWidth,bm.bmHeight,&memdc,0,0,SRCAND);
			rect.left += 20;
		}

		rect.left += 10;
	}

	// draw notes
	{
		int nFeathers; // number of "feathers" (those things on the top of the note)
		BOOL bTail; // specifies whether the note has a tail (the stick coming out of the circle)
		BOOL bDot; // specifies whether duration is multiplied by 3/2
		BOOL bSharp; // specifies whether to draw a small sharp symbol before the note
		CBrush black(RGB(0,0,0)),white(RGB(255,255,255)),red(RGB(255,0,0));
		CBrush* pOldBrush = pdc->SelectObject(&black);
		for(i=firstnote; i<m_song.m_durnote.GetSize(); i++) {
			y = Note2Y(m_song.m_durnote[i]);
			n = m_song.m_durnote[i].Tone();
			if(n%2==1 && n<4)
				bSharp=TRUE;
			else if(n%2==0 && n>5)
				bSharp=TRUE;
			else
				bSharp=FALSE;
			x = rect.left + 20*(i-firstnote);
			bDot = FALSE;
			switch(m_song.m_durnote[i].GetDuration()) {
			case 16: // whole note
				pdc->SelectObject(&white);
				nFeathers = 0;
				bTail = FALSE;
				break;
			case 12: // 3/4 note
				bDot = TRUE; // fall thru
			case 8: // half note
				pdc->SelectObject(&white);
				nFeathers = 0;
				bTail = TRUE;
				break;
			case 6: // 3/8 note
				bDot = TRUE; // fall thru
			case 4: // quarter note
				pdc->SelectObject(&black);
				nFeathers = 0;
				bTail = TRUE;
				break;
			case 3: // 3/16 note
				bDot = TRUE; // fall thru
			case 2: // eigth note
				pdc->SelectObject(&black);
				nFeathers = 1;
				bTail = TRUE;
				break;
			case 1: // sixteenth note
				pdc->SelectObject(&black);
				nFeathers = 2;
				bTail = TRUE;
				break;
			default:
				pdc->SelectObject(&red);
				nFeathers=0;
				bTail=TRUE;
			}
			pdc->Ellipse(x-5,y-5,x+5,y+5);
			if(bTail) {
				if(y>45) {
					pdc->MoveTo(x+5,y);
					pdc->LineTo(x+5,y-33);
					for(j=0; j<nFeathers; j++) {
						pdc->MoveTo(x+5,y-33+j*10);
						pdc->LineTo(x+12,y-33+j*10);
						pdc->MoveTo(x+5,y-32+j*10);
						pdc->LineTo(x+12,y-32+j*10);
						pdc->LineTo(x+14,y-31+j*10);
						pdc->LineTo(x+15,y-30+j*10);
					}
				} else {
					pdc->MoveTo(x-5,y);
					pdc->LineTo(x-5,y+33);
					for(j=0; j<nFeathers; j++) {
						pdc->MoveTo(x-5,y+33-j*10);
						pdc->LineTo(x+2,y+30-j*10);
						pdc->MoveTo(x-5,y+32-j*10);
						pdc->LineTo(x+2,y+29-j*10);
						pdc->LineTo(x+4,y+26-j*10);
						pdc->LineTo(x+5,y+24-j*10);
					}
				}
			}
			if(bDot) {
				pdc->SelectObject(&black);
				pdc->Ellipse(x+7,y-2,x+11,y+2);
			}
			if(bSharp) {
				pdc->MoveTo(x-11,y-2);
				pdc->LineTo(x-6,y-2);
				pdc->MoveTo(x-11,y+2);
				pdc->LineTo(x-6,y+2);
				pdc->MoveTo(x-7,y-4);
				pdc->LineTo(x-7,y+4);
				pdc->MoveTo(x-10,y-4);
				pdc->LineTo(x-10,y+4);
			}
		}
		pdc->SelectObject(pOldBrush);
	}
}


void CDlgNoteWriter::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(!m_bActivated)
		return; // see OnLButtonDown
	
	if(point.y<10 || point.y>95)
		return;

	UpdateData(true);

	if(m_nMode == 0)
		OnLButtonUpAppend(nFlags,point);
	else
		OnLButtonUpModify(nFlags,point);
}

void CDlgNoteWriter::OnLButtonUpAppend(UINT nFlags, CPoint point) 
{
	if(nFlags&MK_SHIFT) {
		// delete last note entered

		if(m_song.m_durnote.GetSize()==0)
			return;
		m_song.m_durnote.RemoveAt(m_song.m_durnote.GetSize()-1);
		UpdateString();
		InvalidateRect(NULL);
		return;
	}

	// add new note
	CString str;
	CNote note = Y2Note(point.y);
	note.Transpose(m_nKey[(note.Tone()+1)/2]);
	str.Format("(%d %d)  ",note.Distance(),m_nNoteLen);
	m_sData += str;
	CDurNote durnote(note,m_nNoteLen);
	m_song.m_durnote.Add(durnote);
	m_scroll.SetScrollRange(0,m_song.m_durnote.GetSize()-1);
	UpdateData(FALSE);
	InvalidateRect(NULL);
}

void CDlgNoteWriter::OnLButtonUpModify(UINT /*nFlags*/, CPoint point) 
{
	if(point.y<10 || point.y>95)
		return;

	int i; // index of note to be modified
	int left=50;
	for(i=0; i<7; i++) {
		if(m_nKey[i])
			left+=20;
	}
	if(point.x<left)
		return;
	i = (point.x + m_scroll.GetScrollPos()*20 - left)/20;
	if(i>=m_song.m_durnote.GetSize())
		return;
	CNote note = Y2Note(point.y);
	note.Transpose(m_nKey[(note.Tone()+1)/2]);
	CDurNote durnote(note,m_nNoteLen);
	m_song.m_durnote.SetAt(i,durnote);
	m_song.m_nTempo = m_nTempo;
	m_song.m_name = m_sSongName;
	m_song.m_comments = m_sComments;
	GetDataFromSong();
	UpdateData(false);
	InvalidateRect(NULL);
}

CNote CDlgNoteWriter::Y2Note(int y)
{
	short octave,tone;
	int n = (82-y)/5;
	int t;
	if(n<0) {
		octave=3;
		tone=(short)(n==-1 ? 10 : 8);
	}
	octave = (short)(4+n/7);
	t = n - (octave-4)*7;
	tone = (short)(2*t - (t>2 ? 1 : 0));
	return CNote(octave,tone);
}

int CDlgNoteWriter::Note2Y(const CNote & note)
{
	int d = note.Distance();
	if(d<-3)
		return 1000;
	if(d<0)
		return (d==-1 ? 80 : 85);
	int oct = d/12;
	int tone = (d - oct*12 + (d-oct*12>3?1:0))/2;
	return 80 - 5 * (oct*7 + tone);
}

void CDlgNoteWriter::OnReset() 
{
	int i;
	for(i=0; i<7; i++)
		m_nKey[i]=0;
	m_sData = "";
	m_song.Clear();
	m_scroll.SetScrollRange(0,0);
	InvalidateRect(NULL);
	UpdateData(FALSE);
}

void CDlgNoteWriter::OnOK() 
{	
	CDialog::OnOK();

	UpdateData(TRUE);
	m_song.m_name = m_sSongName;
	m_song.m_comments = m_sComments;
	m_song.m_nTempo = m_nTempo;
}

void CDlgNoteWriter::OnPlay() 
{
	int i,j,len,dur;
	float freq,delta,phase;
	
	UpdateData(TRUE);
	int nBreak = m_nTempo/2;

	// calculate length of wave file, in samples
	for(i=len=0; i<m_song.m_durnote.GetSize(); i++) {
		len += m_song.m_durnote[i].GetDuration()*m_nTempo + nBreak;
	}

	if(len>8000000) {
		AfxMessageBox("File is too long to play. This is probably because of a note with an invalid duration value.");
		return;
	}

	// allocate memory
	// header length is 0x2C
	BeginWaitCursor();
	DeleteWave(); // delete previously allocated memory and stop previous playback
	m_pWave = new char[0x2C+len]; // deleted by the destructor

	// write header for 8-bit, 8 kHz, mono
	char* pc = m_pWave;
	char hdr[0x2c] = {
		0x52, 0x49, 0x46, 0x46, 0x00, 0x00, 0x00, 0x00,
		0x57, 0x41, 0x56, 0x45, 0x66, 0x6D, 0x74, 0x20,
		0x10, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
		0x40, 0x1F, 0x00, 0x00, 0x40, 0x1F, 0x00, 0x00,
		0x01, 0x00, 0x08, 0x00, 0x64, 0x61, 0x74, 0x61, 
		0x20, 0x03, 0x00, 0x00 };
	*(LONG*)(hdr+0x04) = (LONG)(len + 0x2c - 8);
	*(LONG*)(hdr+0x28) = (LONG)len;
	for(i=0; i<0x2c; i++)
		*(pc++) = hdr[i];
	
	// write actual note data
	phase = 0;
	for(i=0; i<m_song.m_durnote.GetSize(); i++) {
		dur = m_song.m_durnote[i].GetDuration() * m_nTempo;
		freq = m_song.m_durnote[i].GetFreq();
		delta = 2*3.1415927f*freq/8000;
		for(j=0; j<dur; j++) {
			*(pc++) = (BYTE)(128 + 100*sin(phase));
			phase += delta;
			if(phase > 2*3.1415927)
				phase -= 2*3.1415927f;
		}
		// remove the following lines to generate continuous tones.
		phase=0;
		for(j=0; j<nBreak; j++)
			*(pc++) = 0;
	}
	EndWaitCursor();

	// start playing the wave file
	PlaySound(m_pWave, NULL, SND_MEMORY|SND_ASYNC);
}

void CDlgNoteWriter::DeleteWave()
{
	// deletes m_pWave, if it's initialized
	if(m_pWave) {
		PlaySound(NULL,NULL,NULL); // stop the wave file from playing
		delete[] m_pWave;
		m_pWave=0;
	}
}

void CDlgNoteWriter::OnRButtonUp(UINT nFlags, CPoint point) 
{
	if(point.y<10 || point.y>95)
		return;

	UpdateData(true);

	if(m_nMode == 0)
		OnRButtonUpAppend(nFlags,point);
	else
		OnRButtonUpModify(nFlags,point);
}

void CDlgNoteWriter::OnRButtonUpAppend(UINT nFlags, CPoint point) 
{
	CNote note = Y2Note(point.y);
	int i = (note.Tone()+1)/2;
	int newval;
	if(nFlags&MK_SHIFT)
		newval=-1;
	else if(nFlags&MK_CONTROL)
		newval=0;
	else
		newval=1;

	m_nKey[i] = (char)newval;

	InvalidateRect(NULL);
}

void CDlgNoteWriter::OnRButtonUpModify(UINT nFlags, CPoint point) 
// If shift is pressed - deletes the note pointed at;
// otherwise - inserts a note in the position of the mouse
{
	int i; // index of note to be deleted or inserted
	int left=50;
	for(i=0; i<7; i++) {
		if(m_nKey[i])
			left+=20;
	}
	if(point.x<left)
		return;
	i = (point.x + m_scroll.GetScrollPos()*20 - left)/20;
	if(i>=m_song.m_durnote.GetSize())
		return;

	if(nFlags&MK_SHIFT) {
		m_song.m_durnote.RemoveAt(i);
	} else {
		CNote note = Y2Note(point.y);
		note.Transpose(m_nKey[(note.Tone()+1)/2]);
		CDurNote durnote(note,m_nNoteLen);
		m_song.m_durnote.InsertAt(i,durnote);
	}

	m_song.m_nTempo = m_nTempo;
	m_song.m_name = m_sSongName;
	m_song.m_comments = m_sComments;
	GetDataFromSong();
	UpdateData(false);
	InvalidateRect(NULL);
}

void CDlgNoteWriter::UpdateString()
// updates m_sData and m_scroll based on m_song
{
	int i;
	CString str;
	m_sData="";
	m_nTempo = m_song.m_nTempo;
	for(i=0; i<m_song.m_durnote.GetSize(); i++) {
		str.Format("(%d %d)  ",m_song.m_durnote[i].Distance(),m_song.m_durnote[i].GetDuration());
		m_sData += str;
	}
	m_scroll.SetScrollRange(0,m_song.m_durnote.GetSize()-1);
	UpdateData(FALSE);
}

BOOL CDlgNoteWriter::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_bActivated = FALSE; // see OnLButtonDown
	m_scroll.SetScrollRange(0,m_song.m_durnote.GetSize()-1);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgNoteWriter::OnLButtonDown(UINT /*nFlags*/, CPoint /*point*/) 
{
	// this activation mechanism ensures that double-clicks from previous
	// windows, which send WM_LBUTTONUP messages to our window, won't interfere.
	m_bActivated = TRUE;
}

void CDlgNoteWriter::GetDataFromSong()
{
	int i;
	CString str;

	m_sSongName = m_song.m_name;
	m_sComments = m_song.m_comments;
	m_sData = "";
	m_nTempo = m_song.m_nTempo;

	for(i=0; i<m_song.m_durnote.GetSize(); i++) {
		str.Format("(%d %d)  ",m_song.m_durnote[i].Distance(),m_song.m_durnote[i].GetDuration());
		m_sData += str;
	}
	if(::IsWindow(m_hWnd))
		m_scroll.SetScrollRange(0,m_song.m_durnote.GetSize()-1);
}

void CDlgNoteWriter::OnNwHelpInstruc() 
{
	AfxMessageBox(IDS_NOTE_WRITER_TEXT,MB_ICONINFORMATION);
}

void CDlgNoteWriter::OnTransDown() 
{
	Transpose(-1);
}

void CDlgNoteWriter::OnTransDownOct() 
{
	Transpose(-12);
}

void CDlgNoteWriter::OnTransUp() 
{
	Transpose(1);
}

void CDlgNoteWriter::OnTransUpOct() 
{
	Transpose(12);
}

void CDlgNoteWriter::Transpose(int nSemitones)
{
	UpdateData(true);
	m_song.m_nTempo = m_nTempo;
	m_song.Transpose(nSemitones);
	UpdateString();
	InvalidateRect(NULL);
}

void CDlgNoteWriter::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	int a,b;
	a=pScrollBar->GetScrollPos();
	switch(nSBCode) {
	case SB_THUMBPOSITION:
		b=nPos;
		break;
	case SB_THUMBTRACK:
		b=nPos;
		break;
	case SB_LINELEFT:
		b=a-1;
		break;
	case SB_LINERIGHT:
		b=a+1;
		break;
	case SB_PAGELEFT:
		b=a-10;
		break;
	case SB_PAGERIGHT:
		b=a+10;
		break;
	default:
		return;
	}
	if(b<0) b=0;
	if(b>m_song.m_durnote.GetSize()-1) b=m_song.m_durnote.GetSize()-1;
	pScrollBar->SetScrollPos(b);
	InvalidateRect(CRect(0,0,750,110));
}

void CDlgNoteWriter::OnSongPlay() 
{
	OnPlay();
}

void CDlgNoteWriter::OnSongStop() 
{
	DeleteWave();
}

void CDlgNoteWriter::OnNwNotesDelete() 
{
	if(m_song.m_durnote.GetSize()==0)
		return;

	CDlgDelNotes dlg(m_song.m_durnote.GetSize());
	if(dlg.DoModal()==IDOK) {
		if(dlg.m_nFrom<0)
			dlg.m_nFrom=0;
		if(dlg.m_nTo>=m_song.m_durnote.GetSize())
			dlg.m_nTo = m_song.m_durnote.GetSize()-1;
		m_song.m_durnote.RemoveAt(dlg.m_nFrom,dlg.m_nTo-dlg.m_nFrom-1);
		m_song.m_nTempo = m_nTempo;
		m_song.m_name = m_sSongName;
		m_song.m_comments = m_sComments;
		GetDataFromSong();
		UpdateData(false);
		InvalidateRect(NULL);
	}
}
