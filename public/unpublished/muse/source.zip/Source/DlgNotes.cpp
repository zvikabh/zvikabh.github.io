// DlgNotes.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "DlgNotes.h"
#include "SegParam.h"
#include "MuseDoc.h"
#include "EditDist.h"
#include "DlgSearchRes.h"
#include "DlgNoteWriter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int __cdecl DoubleIntCompareFunc( const void * di1, const void * di2 ); // for qsort

/////////////////////////////////////////////////////////////////////////////
// CDlgNotes dialog


CDlgNotes::CDlgNotes(CMuseDoc* pDoc, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgNotes::IDD, pParent)
{
	m_pDoc = pDoc;
	//{{AFX_DATA_INIT(CDlgNotes)
	m_nSearchMethod = -1;
	//}}AFX_DATA_INIT
}


void CDlgNotes::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgNotes)
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Radio(pDX, IDC_RADIO1, m_nSearchMethod);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgNotes, CDialog)
	//{{AFX_MSG_MAP(CDlgNotes)
	ON_BN_CLICKED(IDC_SEARCH, OnSearch)
	ON_BN_CLICKED(IDC_ADD_TO_DB, OnAddToDb)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgNotes message handlers

BOOL CDlgNotes::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_nSearchMethod = AfxGetApp()->GetProfileInt("SearchParam","nSearchMode",2);
	UpdateData(false);

	SetupList(&m_list,m_pDoc);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgNotes::OnSearch() 
{
	UpdateData(TRUE);
	CArray<int,int> result;

	switch(m_nSearchMethod) {
	case 0:
		SearchParsons(m_pDoc,result);
		break;
	case 1:
		SearchFrequency(m_pDoc,result);
		break;
	case 2:
		SearchFreqDur(m_pDoc,result);
		break;
	}

	CDlgSearchRes dlg(m_pDoc, &result);
	dlg.DoModal();
}

int __cdecl DoubleIntCompareFunc( const void * di1, const void * di2 )
{
	int *p1 = (int*)di1;
	int *p2 = (int*)di2;
	if(*(p1+1) > *(p2+1))
		return 1;
	return -1;
}

void CDlgNotes::OnAddToDb() 
{
	CDlgNoteWriter dlg;
	CArray<CDurNote, CDurNote&>& m_durnote = dlg.m_song.m_durnote;
	int i;
	CMuseDoc::CSegment* pseg;
	float minfreq=1e8;
	float f,pf,cf;
	int maxdur=0,dur;

	// find minimum pitch and maximum duration
	// (the minimum pitch will be moved to C-4, more or less)
	// (the maximum duration will be translated to a half note)
	for(i=0; i<m_pDoc->m_segment.GetSize(); i++) {
		pseg = &(m_pDoc->m_segment[i]);
		f = 8000.f/pseg->pitch;
		if(f<minfreq)
			minfreq=f;
		dur = (pseg->tend - pseg->tstart) / 8;
		if(dur>maxdur)
			maxdur=dur;
	}

	// translate first note
	CDurNote note(4,0,0,4); // C-4 quarter note
	pseg = &(m_pDoc->m_segment[0]);
	f = 8000.f/pseg->pitch; // frequency (Hz)
	cf = float(1200*log(f/minfreq)/log(2)); // diff in cents betw f and minfreq
	note.Transpose(int(cf/100));
	note.SetDuration( GuessDuration((pseg->tend - pseg->tstart) / maxdur) );
	m_durnote.Add(note);

	// translate rest of notes, each one relative to the previous
	for(i=1; i<m_pDoc->m_segment.GetSize(); i++) {
		pf = f;
		pseg = &(m_pDoc->m_segment[i]);
		f = 8000.f/pseg->pitch;				// freq (Hz)
		cf = float(1200*log(f/pf)/log(2));	// diff betw f and pf (cents)
		note.Transpose((int)((cf+50)/100));
		note.SetDuration( GuessDuration((pseg->tend - pseg->tstart) / maxdur) );
		m_durnote.Add(note);
	}

	// display NoteWriter dialog
	dlg.m_song.m_nTempo = 500;
	dlg.GetDataFromSong();
	if(dlg.DoModal()==IDOK) {
		if(AfxMessageBox(IDS_ADD_TO_DATABASE,MB_YESNO)==IDYES) {
			m_pDoc->m_database.Add(dlg.m_song);
			m_pDoc->SetModifiedFlag();
		}
	}
}

int CDlgNotes::GuessDuration(int n)
{
	if(n<=1)  return 1;
	if(n==2)  return 2;
	if(n==3)  return 3;
	if(n==4)  return 4;
	if(n<=6)  return 6;
	if(n<=8)  return 8;
	if(n<=12) return 12;
	else      return 16;
}

/*static*/ void CDlgNotes::SearchFrequency(CMuseDoc* m_pDoc, CArray<int,int>& result)
{
	CArray<int,int> recording,database;
	// The array result contains pairs of integers. The first member
	// (with an even index) is the song index, and the second is the
	// edit distance for that song. This array is then sorted and the
	// top ten results are displayed.
	int i,j;
	CMuseDoc::CSegment* pseg;
	CNote note,pnote;
	float f;
	int cost;

	m_pDoc->BeginWaitCursor();

	// convert recording to an array of relative pitches
	for(i=0; i<m_pDoc->m_segment.GetSize(); i++) {
		pseg = &(m_pDoc->m_segment[i]);
		f = 8000.f/pseg->pitch;
		note = CNote(f);
		if(i>0) {
			recording.Add(note.DistanceCents()-pnote.DistanceCents());
		}
		pnote=note;
	}

	// find edit distances of all songs
	CWinApp* app = AfxGetApp();
	int nInsCost = app->GetProfileInt("SearchParam","nFInsertCost",15000);
	int nDelCost = app->GetProfileInt("SearchParam","nFDeleteCost",15000);
	bool bProp = (app->GetProfileInt("SearchParam","bFProp",1) != 0);
	CIntEditDist ied(nInsCost,nDelCost,bProp);
	for(i=0; i<m_pDoc->m_database.GetSize(); i++) {
		database.RemoveAll();
		for(j=0; j<m_pDoc->m_database[i].m_durnote.GetSize(); j++) {
			note = m_pDoc->m_database[i].m_durnote[j];
			if(j>0)
				database.Add(note.DistanceCents()-pnote.DistanceCents());
			pnote = note;
		}
		cost = ied.EditDistance(recording.GetData(), recording.GetSize(), 
			database.GetData(), database.GetSize());
		result.Add(i);
		result.Add(cost); // see comments for definition of result
	}

	// sort songs by increasing edit distance
	qsort(result.GetData(), result.GetSize()/2, sizeof(int)*2, DoubleIntCompareFunc);

	// convert edit distance to percent similarity
	for(i=0; i<result.GetSize()/2; i++) {
		result[2*i+1] = 100-(result[2*i+1]/40);
	}

	m_pDoc->EndWaitCursor();
}

/*static*/ void CDlgNotes::SearchFreqDur(CMuseDoc* m_pDoc, CArray<int,int>& result)
{
	CArray<CDblInt,CDblInt&> recording,database;
	// The array result contains pairs of integers. The first member
	// (with an even index) is the song index, and the second is the
	// edit distance for that song. This array is then sorted and the
	// top ten results are displayed.
	int i,j;
	CMuseDoc::CSegment* pseg;
	CMuseDoc::CSegment* ppseg;
	CNote note,pnote;
	CDurNote durnote,pdurnote;
	float f;
	int cost;
	CDblInt di;

	CMuseApp* app = (CMuseApp*)AfxGetApp();

	int nInsCost = app->GetProfileInt("SearchParam","nFInsertCost",15000);
	int nDelCost = app->GetProfileInt("SearchParam","nFDeleteCost",15000);
	bool bProp = (app->GetProfileInt("SearchParam","bFProp",1) != 0);
	float fNear = app->GetProfileFloat("SearchParam","fDNear",1.5f);
	float fFar = app->GetProfileFloat("SearchParam","fDTotal",3.0f);
	float fLong = app->GetProfileFloat("SearchParam","fDLong",1.7f);
	float fShort = app->GetProfileFloat("SearchParam","fDShort",0.7f);

	m_pDoc->BeginWaitCursor();

	// convert recording to an array of relative pitches and durations
	ppseg = 0;
	for(i=0; i<m_pDoc->m_segment.GetSize(); i++) {
		pseg = &(m_pDoc->m_segment[i]);
		note = pseg->note;
		if(i>0) {
			di.a = note.DistanceCents()-pnote.DistanceCents();
			f = (float)(pseg->tend-pseg->tstart)/(ppseg->tend-ppseg->tstart);
			if(f > fLong)
				di.b = 1;
			else if(f < fShort)
				di.b = -1;
			else
				di.b = 0;
			recording.Add(di);
		}
		pnote=note;
		ppseg = pseg;
	}

	// find edit distances of all songs
	CDblIntEditDist ied(nInsCost,nDelCost,bProp,fNear,fFar);
	for(i=0; i<m_pDoc->m_database.GetSize(); i++) {
		database.RemoveAll();
		for(j=0; j<m_pDoc->m_database[i].m_durnote.GetSize(); j++) {
			durnote = m_pDoc->m_database[i].m_durnote[j];
			if(j>0) {
				di.a = durnote.DistanceCents()-pdurnote.DistanceCents();
				f = (float)durnote.GetDuration()/pdurnote.GetDuration();
				if(f > fLong)
					di.b = 1;
				else if(f < fShort)
					di.b = -1;
				else
					di.b = 0;
				database.Add(di);
			}
			pdurnote = durnote;
		}
		cost = ied.EditDistance(recording.GetData(), recording.GetSize(), 
			database.GetData(), database.GetSize());
		result.Add(i);
		result.Add(cost); // see comments for definition of result
	}

	// sort songs by increasing edit distance
	qsort(result.GetData(), result.GetSize()/2, sizeof(int)*2, DoubleIntCompareFunc);

	// convert edit distance to percent similarity
	for(i=0; i<result.GetSize()/2; i++) {
		result[2*i+1] = 100-(result[2*i+1]/40);
	}

	m_pDoc->EndWaitCursor();
}

/*static*/ void CDlgNotes::SearchParsons(CMuseDoc* m_pDoc, CArray<int,int>& result)
{
	CArray<int,int> recording,database;
	// The array result contains pairs of integers. The first member
	// (with an even index) is the song index, and the second is the
	// edit distance for that song. This array is then sorted and the
	// top ten results are displayed.
	int i,j;
	CNote note,pnote;
	int cost;
	CMuseDoc::CSegment* pseg;
	float f;

	m_pDoc->BeginWaitCursor();

	// convert recording to an array of relative pitches
	CString code; // parsons code (for debugging use)
	for(i=0; i<m_pDoc->m_segment.GetSize(); i++) {
		pseg = &(m_pDoc->m_segment[i]);
		f = 8000.f/pseg->pitch;
		note = CNote(f);
		if(i>0) {
			if(note.DistanceCents()-pnote.DistanceCents() > 50) {
				recording.Add(1);
				code += "U";
			}
			else if(note.DistanceCents()-pnote.DistanceCents() < -50) {
				recording.Add(-1);
				code += "D";
			}
			else {
				recording.Add(0); // R
				code += "R";
			}
		}
		pnote=note;
	}

	// find edit distances of all songs
	CWinApp* app = AfxGetApp();
	int nNoteDiff = app->GetProfileInt("SearchParam","nPNoteDiff",50);
	int nURCost = app->GetProfileInt("SearchParam","nPURCost",2);
	int nRUCost = app->GetProfileInt("SearchParam","nPRUCost",2);
	int nUDCost = app->GetProfileInt("SearchParam","nPUDCost",20);
	int nInsertRCost = app->GetProfileInt("SearchParam","nPInsertRCost",1);
	int nInsertUCost = app->GetProfileInt("SearchParam","nPInsertUCost",3);
	CParsonsEditDist ied(nURCost,nRUCost,nUDCost,nInsertRCost,nInsertUCost);
	for(i=0; i<m_pDoc->m_database.GetSize(); i++) {
		database.RemoveAll();
		for(j=0; j<m_pDoc->m_database[i].m_durnote.GetSize(); j++) {
			note = m_pDoc->m_database[i].m_durnote[j];
			if(j>0) {
				if(note.DistanceCents()-pnote.DistanceCents() > nNoteDiff) {
					database.Add(1); // U
				}
				else if(note.DistanceCents()-pnote.DistanceCents() < -nNoteDiff) {
					database.Add(-1); // D
				}
				else {
					database.Add(0); // R
				}
			}
			pnote = note;
		}
		cost = ied.EditDistance(recording.GetData(), recording.GetSize(), 
			database.GetData(), database.GetSize());
		result.Add(i);
		result.Add(cost); // see comments for definition of result
	}

	// sort songs by increasing edit distance
	qsort(result.GetData(), result.GetSize()/2, sizeof(int)*2, DoubleIntCompareFunc);

	// convert edit distance to percent similarity
	for(i=0; i<result.GetSize()/2; i++) {
		result[2*i+1] = 100-2*result[2*i+1];
	}

	m_pDoc->EndWaitCursor();
}

/*static*/ void CDlgNotes::SetupList(CListCtrl* pList, CMuseDoc* pDoc)
// this function is used by OnInitDialog and by CDlgWizard::StartStep.
{
	CMuseDoc::CSegment* pseg;
	CString str;
	float f,pf=0;

	pList->InsertColumn(0,"Frequency (�)",LVCFMT_LEFT,100,0);
	pList->InsertColumn(1,"Delta (�)",LVCFMT_LEFT,100,1);
	pList->InsertColumn(2,"Duration (ms)",LVCFMT_LEFT,100,2);

	for(int i=0; i<pDoc->m_segment.GetSize(); i++) {
		pseg = &(pDoc->m_segment[i]);
		f = (float)(1200*log((8000/pseg->pitch)/440)/log(2));
		str.Format("%.0f", f);
		pList->InsertItem(i,str);
		pList->SetItem(i,0,0,0,0,0,0,0);
		if(i!=0) {
			str.Format("%.0f", f-pf);
			pList->SetItemText(i,1,str);
		}
		pf=f;
		str.Format("%d", (pseg->tend - pseg->tstart) / 8);
		pList->SetItemText(i,2,str);
	}
}
