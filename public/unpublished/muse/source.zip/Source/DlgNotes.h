#if !defined(AFX_DLGNOTES_H__BCF6AD63_17A2_11D3_9F4A_883D06C10627__INCLUDED_)
#define AFX_DLGNOTES_H__BCF6AD63_17A2_11D3_9F4A_883D06C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgNotes.h : header file
//

class CMuseDoc;

/////////////////////////////////////////////////////////////////////////////
// CDlgNotes dialog

class CDlgNotes : public CDialog
{
// Construction
public:
	static void SetupList(CListCtrl* pList, CMuseDoc* pDoc);
	static void SearchParsons(CMuseDoc* m_pDoc, CArray<int,int>& result);
	static void SearchFrequency(CMuseDoc* m_pDoc, CArray<int,int>& result);
	static void SearchFreqDur(CMuseDoc* m_pDoc, CArray<int,int>& result);
	CDlgNotes(CMuseDoc* pDoc, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgNotes)
	enum { IDD = IDD_NOTES };
	CListCtrl	m_list;
	int		m_nSearchMethod;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgNotes)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
private:
	int GuessDuration(int n);
protected:
	CMuseDoc* m_pDoc;

	// Generated message map functions
	//{{AFX_MSG(CDlgNotes)
	virtual BOOL OnInitDialog();
	afx_msg void OnSearch();
	afx_msg void OnAddToDb();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGNOTES_H__BCF6AD63_17A2_11D3_9F4A_883D06C10627__INCLUDED_)
