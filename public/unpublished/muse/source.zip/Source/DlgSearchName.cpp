// DlgSearchName.cpp : implementation file
//

#include "stdafx.h"
#include "muse.h"
#include "DlgSearchName.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSearchName dialog


CDlgSearchName::CDlgSearchName(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSearchName::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSearchName)
	m_sEdit = _T("");
	//}}AFX_DATA_INIT
}


void CDlgSearchName::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSearchName)
	DDX_Text(pDX, IDC_EDIT1, m_sEdit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSearchName, CDialog)
	//{{AFX_MSG_MAP(CDlgSearchName)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSearchName message handlers
