// DlgSearchRes.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "SegParam.h"
#include "MuseDoc.h"
#include "DlgSearchRes.h"
#include "DlgNoteWriter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSearchRes dialog


CDlgSearchRes::CDlgSearchRes(CMuseDoc* pDoc, CArray<int,int>* pArray, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSearchRes::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSearchRes)
	m_sComments = _T("");
	//}}AFX_DATA_INIT
	m_pDoc = pDoc;
	m_pArray = pArray;
}


void CDlgSearchRes::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSearchRes)
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Text(pDX, IDC_COMMENTS, m_sComments);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSearchRes, CDialog)
	//{{AFX_MSG_MAP(CDlgSearchRes)
	ON_NOTIFY(NM_CLICK, IDC_LIST1, OnClickList1)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSearchRes message handlers

BOOL CDlgSearchRes::OnInitDialog() 
{
	CString str;
	CSong* psong;
	int i;

	CDialog::OnInitDialog();
	
	m_list.InsertColumn(0,"Song Name",LVCFMT_LEFT,250,0);
	m_list.InsertColumn(1,"Similarity",LVCFMT_LEFT,60,1);
	m_list.InsertColumn(2,"Notes",LVCFMT_LEFT,60,2);

	for(i=0; i<20 && i<m_pArray->GetSize(); i+=2) {
		psong = & m_pDoc->m_database[m_pArray->ElementAt(i)];
		m_list.InsertItem(i/2,psong->m_name);
		m_list.SetItem(i,0,0,0,0,0,0,0);
		str.Format("%d%%",m_pArray->ElementAt(i+1));
		m_list.SetItemText(i/2,1,str);
		str.Format("%d",psong->m_durnote.GetSize());
		m_list.SetItemText(i/2,2,str);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgSearchRes::OnClickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMList = (NM_LISTVIEW*)pNMHDR; 
    int pos=pNMList->iItem;
	
	m_sComments = m_pDoc->m_database[m_pArray->ElementAt(pos*2)].m_comments;
	UpdateData(FALSE);

	*pResult = 0;
}

void CDlgSearchRes::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMList = (NM_LISTVIEW*)pNMHDR; 
    int pos=pNMList->iItem;

	CDlgNoteWriter dlg;
	CSong& cursong = m_pDoc->m_database[m_pArray->ElementAt(pos*2)];
	dlg.m_song = cursong;
	dlg.GetDataFromSong();

	if(dlg.DoModal()==IDOK) {
		m_pDoc->m_database.SetAt(m_pArray->ElementAt(pos*2), dlg.m_song);
		m_pDoc->SetModifiedFlag();
	}

	*pResult = 0;
}
