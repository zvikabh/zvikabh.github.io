#if !defined(AFX_DLGSEARCHRES_H__148B8087_28FD_11D3_9F4A_0C8A06C10627__INCLUDED_)
#define AFX_DLGSEARCHRES_H__148B8087_28FD_11D3_9F4A_0C8A06C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgSearchRes.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgSearchRes dialog

class CDlgSearchRes : public CDialog
{
// Construction
public:
	CDlgSearchRes(CMuseDoc* pDoc, CArray<int,int>* pArray, CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CDlgSearchRes)
	enum { IDD = IDD_SEARCH_RESULT };
	CListCtrl	m_list;
	CString	m_sComments;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSearchRes)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CMuseDoc* m_pDoc;
	CArray<int,int>* m_pArray;

	// Generated message map functions
	//{{AFX_MSG(CDlgSearchRes)
	virtual BOOL OnInitDialog();
	afx_msg void OnClickList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSEARCHRES_H__148B8087_28FD_11D3_9F4A_0C8A06C10627__INCLUDED_)
