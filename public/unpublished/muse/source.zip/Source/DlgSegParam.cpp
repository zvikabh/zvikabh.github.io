// DlgSegParam.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "DlgSegParam.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSegParam dialog


CDlgSegParam::CDlgSegParam(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSegParam::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSegParam)
	m_nMinLen = 0;
	m_nTrigger = 0;
	m_nFlukes = 0;
	m_nNFDist = 0;
	m_nLen4Note = 0;
	m_nSD = 0;
	m_bBacktrack = FALSE;
	m_bRemove = FALSE;
	m_nSmooth = 0;
	m_bVolTrig = FALSE;
	m_bInvVolTrig = FALSE;
	m_bVolDC = FALSE;
	//}}AFX_DATA_INIT
}

void CDlgSegParam::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSegParam)
	DDX_Text(pDX, IDC_EDIT1, m_nMinLen);
	DDX_Text(pDX, IDC_EDIT2, m_nTrigger);
	DDX_Text(pDX, IDC_EDIT3, m_nFlukes);
	DDX_Text(pDX, IDC_EDIT4, m_nNFDist);
	DDX_Text(pDX, IDC_EDIT5, m_nLen4Note);
	DDX_Text(pDX, IDC_EDIT6, m_nSD);
	DDX_Check(pDX, IDC_CHECK1, m_bBacktrack);
	DDX_Check(pDX, IDC_CHECK2, m_bRemove);
	DDX_Text(pDX, IDC_EDIT7, m_nSmooth);
	DDX_Check(pDX, IDC_CHECK3, m_bVolTrig);
	DDX_Check(pDX, IDC_CHECK4, m_bInvVolTrig);
	DDX_Check(pDX, IDC_CHECK5, m_bVolDC);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSegParam, CDialog)
	//{{AFX_MSG_MAP(CDlgSegParam)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSegParam message handlers

void CDlgSegParam::OnOK() 
{
	UpdateData(TRUE);
	SaveSettings();
	
	CDialog::OnOK();
}

BOOL CDlgSegParam::OnInitDialog() 
{
	CDialog::OnInitDialog();

	LoadSettings();
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgSegParam::LoadSettings()
{
	CWinApp* app = AfxGetApp();
	const CString str = "Segmentation Parameters";
	m_nFlukes = app->GetProfileInt(str,"Flukes",2);
	m_nMinLen = app->GetProfileInt(str,"MinLen",10);
	m_nTrigger = app->GetProfileInt(str,"Trigger",100);
	m_nNFDist = app->GetProfileInt(str,"NFDist",50);
	m_nSD = app->GetProfileInt(str,"Slope",40);
	m_nLen4Note = app->GetProfileInt(str,"Len4Note",8);
	m_nSmooth = app->GetProfileInt(str,"Smooth",400);
	m_bBacktrack = app->GetProfileInt(str,"Backtrack",1);
	m_bRemove = app->GetProfileInt(str,"Remove",1);
	m_bVolTrig = app->GetProfileInt(str,"VolTrig",1);
	m_bInvVolTrig = app->GetProfileInt(str,"InvVolTrig",1);
	m_bVolDC = app->GetProfileInt(str,"VolDC",1);
}

void CDlgSegParam::SaveSettings()
{
	CWinApp* app = AfxGetApp();
	const CString str = "Segmentation Parameters";
	app->WriteProfileInt(str,"Flukes",m_nFlukes);
	app->WriteProfileInt(str,"MinLen",m_nMinLen);
	app->WriteProfileInt(str,"Trigger",m_nTrigger);
	app->WriteProfileInt(str,"NFDist",m_nNFDist);
	app->WriteProfileInt(str,"Slope",m_nSD);
	app->WriteProfileInt(str,"Len4Note",m_nLen4Note);
	app->WriteProfileInt(str,"Smooth",m_nSmooth);
	app->WriteProfileInt(str,"Backtrack",m_bBacktrack);
	app->WriteProfileInt(str,"Remove",m_bRemove);
	app->WriteProfileInt(str,"VolTrig",m_bVolTrig);
	app->WriteProfileInt(str,"InvVolTrig",m_bInvVolTrig);
	app->WriteProfileInt(str,"VolDC",m_bVolDC);
}
