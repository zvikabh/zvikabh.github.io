#if !defined(AFX_DLGSEGPARAM_H__5558C4C6_AA67_11D2_9F4A_F0F705C10627__INCLUDED_)
#define AFX_DLGSEGPARAM_H__5558C4C6_AA67_11D2_9F4A_F0F705C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgSegParam.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgSegParam dialog

class CDlgSegParam : public CDialog
{
// Construction
public:
	void SaveSettings();
	void LoadSettings();
	CDlgSegParam(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgSegParam)
	enum { IDD = IDD_SEGMENT_PARAM };
	int		m_nMinLen;
	int		m_nTrigger;
	int		m_nFlukes;
	int		m_nNFDist;
	int		m_nLen4Note;
	int		m_nSD;
	BOOL	m_bBacktrack;
	BOOL	m_bRemove;
	int		m_nSmooth;
	BOOL	m_bVolTrig;
	BOOL	m_bInvVolTrig;
	BOOL	m_bVolDC;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSegParam)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgSegParam)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSEGPARAM_H__5558C4C6_AA67_11D2_9F4A_F0F705C10627__INCLUDED_)
