// DlgSegment.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "DlgSegment.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSegment dialog


CDlgSegment::CDlgSegment(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSegment::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSegment)
	m_nFrom = 0;
	m_nTo = 0;
	//}}AFX_DATA_INIT
}


void CDlgSegment::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSegment)
	DDX_Control(pDX, IDC_LIST1, m_listbox);
	DDX_Text(pDX, IDC_EDIT1, m_nFrom);
	DDX_Text(pDX, IDC_EDIT2, m_nTo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSegment, CDialog)
	//{{AFX_MSG_MAP(CDlgSegment)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_LOAD, OnLoad)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSegment message handlers

void CDlgSegment::OnAdd() 
{
	UpdateData(TRUE);
	CString str;
	str.Format("%d-%d",m_nFrom,m_nTo);
	m_listbox.AddString(str);
	m_nFrom = 0;
	m_nTo = 0;
	UpdateData(FALSE);
	GetDlgItem(IDC_EDIT1)->SetFocus();
}

void CDlgSegment::OnOK() 
{
	int i;
	CString str;

	UpdateData(TRUE);
	for(i=0; i<m_listbox.GetCount(); i++) {
		m_listbox.GetText(i,str);
		m_list.AddTail(str);
	}
	
	CDialog::OnOK();
}

void CDlgSegment::OnLoad() 
{
	m_listbox.ResetContent();
	CFileDialog dlg(TRUE, "txt", NULL, OFN_FILEMUSTEXIST,
		"Text Files (*.txt)|*.txt|All Files (*.*)|*.*||");
	dlg.DoModal();
	try {
		CStdioFile file(dlg.GetPathName(), CFile::modeRead|CFile::typeText);
		CString str;
		while(file.ReadString(str))
			m_listbox.AddString(str);
	}
	catch(CException* e) {
		AfxMessageBox("Error reading file.");
		e->Delete();
	}

}
