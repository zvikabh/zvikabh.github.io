#if !defined(AFX_DLGSEGMENT_H__98D19CC3_9808_11D2_9F4A_F0F705C10627__INCLUDED_)
#define AFX_DLGSEGMENT_H__98D19CC3_9808_11D2_9F4A_F0F705C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgSegment.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgSegment dialog

class CDlgSegment : public CDialog
{
// Construction
public:
	CDlgSegment(CWnd* pParent = NULL);   // standard constructor
	CList<CString,CString&> m_list;
		// after pressing OK, this member contains a list of all items in the listbox.
		// (the listbox cannot be accessed directly after OK has been pressed).

// Dialog Data
	//{{AFX_DATA(CDlgSegment)
	enum { IDD = IDD_SEGMENT };
	CListBox	m_listbox;
	int		m_nFrom;
	int		m_nTo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSegment)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgSegment)
	afx_msg void OnAdd();
	virtual void OnOK();
	afx_msg void OnLoad();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSEGMENT_H__98D19CC3_9808_11D2_9F4A_F0F705C10627__INCLUDED_)
