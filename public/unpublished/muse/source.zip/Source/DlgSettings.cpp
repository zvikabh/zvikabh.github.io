// DlgSettings.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "DlgSettings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSettings dialog


CDlgSettings::CDlgSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSettings::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSettings)
	m_sOutputRawDir = _T("");
	m_bNumeric = FALSE;
	m_bOutput = FALSE;
	//}}AFX_DATA_INIT
}


void CDlgSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSettings)
	DDX_Text(pDX, IDC_EDIT2, m_sOutputRawDir);
	DDX_Check(pDX, IDC_CHECK1, m_bNumeric);
	DDX_Check(pDX, IDC_CHECK2, m_bOutput);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSettings, CDialog)
	//{{AFX_MSG_MAP(CDlgSettings)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSettings message handlers

BOOL CDlgSettings::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_sOutputRawDir = AfxGetApp()->GetProfileString("PitchSettings","OutputRawDir",".");
	m_bOutput = AfxGetApp()->GetProfileInt("PitchSettings","Output",0);
	m_bNumeric = AfxGetApp()->GetProfileInt("PitchSettings","Numeric",0);
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgSettings::OnOK() 
{
	UpdateData(TRUE);
	AfxGetApp()->WriteProfileString("PitchSettings","OutputRawDir",m_sOutputRawDir);
	AfxGetApp()->WriteProfileInt("PitchSettings","Output",m_bOutput);
	AfxGetApp()->WriteProfileInt("PitchSettings","Numeric",m_bNumeric);
	
	CDialog::OnOK();
}
