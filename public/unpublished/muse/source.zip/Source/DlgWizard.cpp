// DlgWizard.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "SegParam.h"
#include "MuseDoc.h"
#include "MainFrm.h"
#include "DlgNotes.h"
#include "DlgNoteWriter.h"
#include "DlgWizard.h"
#include "DlgDBView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgWizard dialog


CDlgWizard::CDlgWizard(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgWizard::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgWizard)
	m_sText = _T("");
	m_nRadio = -1;
	m_sEdit = _T("");
	//}}AFX_DATA_INIT
	m_nStep=0;
	m_pDib=0;
}


void CDlgWizard::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgWizard)
	DDX_Control(pDX, IDC_TEXT_BUTTON2, m_button2);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_TEXT_BUTTON, m_button);
	DDX_Text(pDX, IDC_TEXT, m_sText);
	DDX_Radio(pDX, IDC_RADIO1, m_nRadio);
	DDX_Text(pDX, IDC_EDIT1, m_sEdit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgWizard, CDialog)
	//{{AFX_MSG_MAP(CDlgWizard)
	ON_BN_CLICKED(IDC_NEXT, OnNext)
	ON_BN_CLICKED(IDC_PREV, OnPrev)
	ON_BN_CLICKED(IDC_TEXT_BUTTON, OnTextButton)
	ON_BN_CLICKED(IDC_TEXT_BUTTON2, OnTextButton2)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	ON_WM_TIMER()
	ON_COMMAND(ID_FILE_EXIT, OnFileExit)
	ON_COMMAND(ID_HELP_ABOUT, OnHelpAbout)
	ON_COMMAND(ID_VIEW_DETAILS, OnViewDetails)
	ON_COMMAND(ID_VIEW_SONGLIST, OnViewSonglist)
	ON_WM_PALETTECHANGED()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgWizard message handlers

/* Description of the wizard implementation:
   The wizard is an alternaitve method for using the most common parts of the
   Muse program in a simple method, without messing with all the parameters.
   All wizard-related settings are stored in directory Wizard in the registry.
   The wizard is a dialog box which displays different controls depending on 
   its step, which is stored in m_nStep.
   The registry variable "bWizardMode" determines whether the wizard is loaded
   on startup. In any case, the underlying program exists; it is simply invisible
   when the wizard is active. The wizard is started from InitInstance if
   the registry settings indicate that it should be started automatically, and
   transition to and from the wizard can be performed at any time.
   The wizard uses the same underlying mechanism as the rest of the program,
   but does it in a transparent way.

   Important functions:
   StartStep() - hides and unhides controls in order to make the dialog box
   look like the step number that it's supposed to represent. Called after
   m_nStep is changed.
   FinishStep() - activates settings selected in the current step. Called before
   moving on to the next step.
 */

void CDlgWizard::OnNext() 
{
	if(!FinishStep())
		return;
	m_nStep++;
	InvalidateRect(NULL);
	StartStep();
}

void CDlgWizard::OnPrev() 
{
	m_nStep--;
	if(m_nStep<0) {
		ASSERT(0);
		return;
	}
	InvalidateRect(NULL);
	StartStep();
}

void CDlgWizard::StartStep()
{
	switch(m_nStep) {
	
	case 0: // welcome screen
		SetWindowText("Welcome to the Muse Query Wizard");
		m_pDib = new CDib;
		m_pDib->AttachMemory((LPVOID) ::LoadResource(NULL,
			::FindResource(NULL, MAKEINTRESOURCE(IDB_WIZARD_WELCOME), RT_BITMAP)));
		UpdateData(FALSE);
		GetDlgItem(IDC_TEXT)->ShowWindow(SW_HIDE);
		m_button.ShowWindow(SW_SHOW);
		m_button.SetWindowPlacement(&m_wp1);
		m_button.SetFocus();
		HideAll();
		GetDlgItem(IDC_PREV)->ShowWindow(SW_HIDE);
		break;

	case 1: // select db file
		SetWindowText("Muse Query Wizard - Step 1 of 6");
		m_sText.LoadString(IDS_WZ_STEP1);
		m_sEdit = AfxGetApp()->GetProfileString("Wizard","DBFile","Database.mus");
		GetDlgItem(IDC_TEXT)->ShowWindow(SW_SHOW);
		UpdateData(FALSE);
		HideAll();
		m_button.ShowWindow(SW_SHOW);
		m_button.SetWindowPlacement(&m_wp1);
		GetDlgItem(IDC_EDIT1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_PREV)->ShowWindow(SW_SHOW);
		m_button.SetWindowText("Browse...");
		break;

	case 2: // select recording source
		SetWindowText("Muse Query Wizard - Step 2 of 6");
		m_sText.LoadString(IDS_WZ_STEP2);
		UpdateData(FALSE);
		HideAll();
		GetDlgItem(IDC_RADIO1)->SetWindowText("&Record from Sound Card (Microphone)");
		GetDlgItem(IDC_RADIO2)->SetWindowText("&Load from Audio File in RAW Format");
		GetDlgItem(IDC_RADIO1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_RADIO2)->ShowWindow(SW_SHOW);
		((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(1);
		break;

	case 3: // record / load raw file
		SetWindowText("Muse Query Wizard - Step 3 of 6");
		m_sText.LoadString(m_nSource?IDS_WZ_STEP3_MIKE:IDS_WZ_STEP3_FILE);
		m_sEdit = AfxGetApp()->GetProfileString("Wizard","RawFileName","");
		UpdateData(FALSE);
		HideAll();
		m_button.ShowWindow(SW_SHOW);
		m_button.SetFocus();
		if(m_nSource) {
			m_button.SetWindowText("Record");
			m_button2.SetWindowText("Playback");
			m_button2.ShowWindow(SW_SHOW);
			m_button2.EnableWindow(FALSE);
			m_button.SetWindowPos(0,160,80,0,0,SWP_NOSIZE|SWP_NOZORDER);
			m_button2.SetWindowPos(0,160,120,0,0,SWP_NOSIZE|SWP_NOZORDER);
			CProgressCtrl* prog = (CProgressCtrl*)GetDlgItem(IDC_PROGRESS1);
			prog->ShowWindow(SW_SHOW);
			prog->SetPos(0);
			prog->SetRange(0,130);
			GetDlgItem(IDC_VU_LABEL)->ShowWindow(SW_SHOW);
		} else {
			GetDlgItem(IDC_EDIT1)->ShowWindow(SW_SHOW);
			m_button.SetWindowText("Browse...");
			m_button.SetWindowPlacement(&m_wp1);
		}
		break;

	case 4: // perform calculations
		SetWindowText("Muse Query Wizard - Step 4 of 6");
		GetDlgItem(IDC_TEXT)->ShowWindow(SW_SHOW);
		m_sText.LoadString(IDS_WZ_STEP4);
		UpdateData(FALSE);
		HideAll();
		break;

	case 5: // view confidence level
		SetWindowText("Muse Query Wizard - Step 5 of 6");
		m_sText.LoadString(IDS_WZ_STEP5);
		UpdateData(FALSE);
		HideAll();
		GetDlgItem(IDC_TEXT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_NEXT)->SetWindowText("&Next >");
		SetConfidenceWarnings();
		break;

	case 6: // show results
		SetWindowText("Muse Query Wizard - Step 6 of 6");
		GetDlgItem(IDC_TEXT)->ShowWindow(SW_SHOW);
		m_sText.LoadString(IDS_WZ_STEP6);
		UpdateData(FALSE);
		HideAll();
		GetDlgItem(IDC_NEXT)->SetWindowText("&Another");
		m_list.ShowWindow(SW_SHOW);
		break;

	default:
		TRACE("Error: Invalid step number %d\n",m_nStep);
		ASSERT(0);
		break;
	}
}

bool CDlgWizard::FinishStep()
{
	CMainFrame* pMainWnd = (CMainFrame*)AfxGetMainWnd();
	ASSERT_KINDOF(CMainFrame,pMainWnd);

	switch(m_nStep) {
	case 0: // welcome screen
		delete m_pDib;
		m_pDib=0;
		return true;

	case 1: // select db file
		UpdateData(TRUE);
		AfxGetApp()->WriteProfileString("Wizard","DBFile",m_sEdit);
		if(!AfxGetApp()->OpenDocumentFile(m_sEdit))
			return false; // file open failed
		pMainWnd->ShowWindow(SW_HIDE);
		SetFocus();
		m_pDoc = (CMuseDoc*) pMainWnd->MDIGetActive()->GetActiveDocument();
		ASSERT_KINDOF(CMuseDoc,m_pDoc);
		return true;

	case 2: // select recording source
		m_nSource = ((CButton*)GetDlgItem(IDC_RADIO1))->GetCheck();
		return true;

	case 3: // perform recording / choose input file
		UpdateData(TRUE);
		if(m_nSource==0) {
			AfxGetApp()->WriteProfileString("Wizard","RawFileName",m_sEdit);
			m_pDoc->DoFileOpenWave(&m_sEdit);
		} else {
			if(m_pDoc->DataLen() == 0) {
				AfxMessageBox("You must first record a query, then press Next.");
				return false;
			}
			if(((CButton*)GetDlgItem(IDC_TEXT_BUTTON))->GetState()) {
				AfxMessageBox("First end the recording by pressing the Stop button; then press Next.");
				return false;
			}
		}
		return true;

	case 4: // calculate
		// reset warning list
		((CMuseApp*)AfxGetApp())->m_saWarnings.RemoveAll();
		((CMuseApp*)AfxGetApp())->m_nConfidence = 0;

		// calculate
		m_pDoc->OnAnalyzePitch();	 // pitch calculation
		m_pDoc->OnAnalyzeSegment2(); // alternate segmentation

		// prepare list of top matches (which will be hidden until step 6)
		m_list.DeleteAllItems();
		while(m_list.DeleteColumn(0)); // null loop
		DoSearch();					 // perform search
		return true;

	case 5: // show confidence level
		return true;

	case 6: // show results
		// if we reached here, the user pressed the 'Again' button,
		// meaning that we must switch to step 3 and perform another query.
		GetDlgItem(IDC_NEXT)->SetWindowText("&Next >");
		m_nStep = 2; // m_nStep is advanced to 3 in OnNext, the caller.
		return true;

	default:
		ASSERT(0);
		return false;
	}
}

// hides all items in the dialog box, except for the top static text.
void CDlgWizard::HideAll()
{
	m_button.ShowWindow(SW_HIDE);
	m_button2.ShowWindow(SW_HIDE);
	m_list.ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO3)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_PROGRESS1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_VU_LABEL)->ShowWindow(SW_HIDE);
}

BOOL CDlgWizard::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_pDoc=0;

	m_button.GetWindowPlacement(&m_wp1);
	m_button2.GetWindowPlacement(&m_wp2);

	StartStep();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgWizard::OnOK() 
{
	OnNext();
}

void CDlgWizard::OnCancel() 
{
	if(m_pDoc!=0 && m_pDoc->IsRecording()) {
		AfxMessageBox("You must first end the recording, then quit.");
		return;
	}

	// switch back to classic mode, in order to destroy dialog
	((CMuseApp*)AfxGetApp())->SetWizardMode(false);

	// end the program
	AfxGetMainWnd()->PostMessage(WM_CLOSE,0,0);
	
	// change mode back to wizard, so we will start in wizard mode automatically next time
	// the user runs the program.
	AfxGetApp()->WriteProfileInt("Wizard","bWizardMode",1);
}

void CDlgWizard::OnTextButton() 
{
	CString newName;
	CFileDialog dlg3(TRUE, "raw", NULL, OFN_HIDEREADONLY | OFN_FILEMUSTEXIST,
		"Raw Wave Files (*.raw)|*.raw|PCM Wave Files (*.pcm)|*.pcm|All Files (*.*)|*.*||");
	switch(m_nStep) {
	case 1:
		if (!DoPromptFileName(newName, OFN_HIDEREADONLY | OFN_FILEMUSTEXIST))
			return; // open cancelled
		m_sEdit = newName;
		UpdateData(FALSE);
		break;
	case 3:
		if(m_nSource!=0) {
			if(m_pDoc->IsRecording()) {
				m_button.SetWindowText("Overwrite");
				m_button2.EnableWindow(TRUE);
				VERIFY(KillTimer(100));
				m_pDoc->OnFileRecord();
			}
			else {
				m_pDoc->OnFileRecord();
				if(m_pDoc->IsRecording()) {
					m_button2.EnableWindow(FALSE);
					m_button.SetWindowText("Stop");
					VERIFY(SetTimer(100,100,0));
				}
			}
		} else {
			if(dlg3.DoModal() != IDOK)
				return;
			m_sEdit = dlg3.GetPathName();
			UpdateData(FALSE);
		}
		break;
	default:
		ASSERT(0);
		break;
	}
}

void CDlgWizard::OnTextButton2() 
{
	switch(m_nStep) {
	case 3:
		ASSERT(m_nSource!=0);
		m_pDoc->OnRecordPlayback();
		break;
	default:
		ASSERT(0);
		return;
	}
}

BOOL CDlgWizard::DoPromptFileName(CString& fileName, DWORD lFlags)
{
	CFileDialog dlg(TRUE, "mus", NULL, lFlags,
		"Muse Database Files (*.mus)|*.mus||");
	if(dlg.DoModal() != IDOK)
		return false;
	fileName = dlg.GetPathName();
	return true;
}

void CDlgWizard::DoSearch()
{
	m_result.RemoveAll();

	switch(AfxGetApp()->GetProfileInt("SearchParam","nSearchMode",2)) {
	case 0:
		CDlgNotes::SearchParsons(m_pDoc, m_result);
		break;
	case 1:
		CDlgNotes::SearchFrequency(m_pDoc, m_result);
		break;
	case 2:
		CDlgNotes::SearchFreqDur(m_pDoc,m_result);
		break;
	}

	// confidence level check: ensure top match has a reasonable similarity value
	if(m_result.GetSize()>1 && m_result[1]<70) {
		CMuseApp* pApp = (CMuseApp*) AfxGetApp();
		if(m_result[1]<40)
			pApp->AddWarning(IDS_V_LOW_SIMILARITY,(80-m_result[1])/10);
		else if(m_result[1]<60)
			pApp->AddWarning(IDS_LOW_SIMILARITY,(80-m_result[1])/10);
		else
			pApp->AddWarning(0,(80-m_result[1])/10);
	}

	CString str;
	CSong* psong;
	int i;

	m_list.InsertColumn(0,"Song Name",LVCFMT_LEFT,250,0);
	m_list.InsertColumn(1,"Similarity",LVCFMT_LEFT,60,1);
	m_list.InsertColumn(2,"Notes",LVCFMT_LEFT,60,2);

	for(i=0; i<20 && i<m_result.GetSize(); i+=2) {
		psong = & m_pDoc->m_database[m_result[i]];
		m_list.InsertItem(i/2,psong->m_name);
		m_list.SetItem(i,0,0,0,0,0,0,0);
		str.Format("%d%%",m_result[i+1]);
		m_list.SetItemText(i/2,1,str);
		str.Format("%d",psong->m_durnote.GetSize());
		m_list.SetItemText(i/2,2,str);
	}
}

void CDlgWizard::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	switch(m_nStep) {
	case 6:
		DblclkResultList((NM_LISTVIEW*)pNMHDR);
		break;
	default:
		ASSERT(0);
		break;
	}
	
	*pResult = 0;
}

void CDlgWizard::DblclkResultList(NM_LISTVIEW * pNMHDR)
{
    int pos=pNMHDR->iItem;
	CDlgNoteWriter dlg;
	CSong& cursong = m_pDoc->m_database[m_result[pos*2]];
	dlg.m_song = cursong;
	dlg.GetDataFromSong();

	if(dlg.DoModal()==IDOK) {
		m_pDoc->m_database.SetAt(m_result[pos*2], dlg.m_song);
		m_pDoc->SetModifiedFlag();
	}
}

void CDlgWizard::OnTimer(UINT nIDEvent) 
// updates volume control (performed during recording)
{
	if(nIDEvent!=100) {
		ASSERT(0);
		return; // not our timer
	}

	UINT i,sum=0;
	char smp;
	for(i = max(0,m_pDoc->DataLen()-1000); i<m_pDoc->DataLen(); i++) {
		smp = HIBYTE((*m_pDoc)[i]);
		sum += abs(smp);
	}

	sum/=1000;
	CProgressCtrl* prog = (CProgressCtrl*)GetDlgItem(IDC_PROGRESS1);
	prog->SetPos(sum);

	CDialog::OnTimer(nIDEvent);
}

void CDlgWizard::OnFileExit() 
{
	OnCancel();
}

void CDlgWizard::OnHelpAbout() 
{
	CAboutDlg dlg;
	dlg.DoModal();
}

void CDlgWizard::OnViewDetails() 
{
	((CMuseApp*)AfxGetApp())->SetWizardMode(false);
}

void CDlgWizard::OnViewSonglist() 
{
	if(m_pDoc==0) {
		AfxMessageBox("You must open a database file before you can view the song list.");
		return;
	}

	CDlgDBView dlg(m_pDoc);
	dlg.DoModal();
}

void CDlgWizard::SetConfidenceWarnings()
{
	CMuseApp* pApp = (CMuseApp*) AfxGetApp();
	int i;
	CString str;

	if(pApp->m_saWarnings.GetSize() > 0)
		str.LoadString(IDS_READ_COMMENTS);
	else
		str.LoadString(IDS_NO_COMMENTS);

	for(i=0; i<pApp->m_saWarnings.GetSize(); i++) {
		str += pApp->m_saWarnings[i] + "\r\n\r\n";
	}

	GetDlgItem(IDC_EDIT2)->SetWindowText(str);
}

void CDlgWizard::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	switch(m_nStep) {
	case 0:
		OnPaintStep0(dc);
		return;
	case 5:
		OnPaintStep5(dc);
		return;
	default:
		return;
	}
}

void CDlgWizard::OnPaintStep0(CDC& dc)
{
	m_pDib->UsePalette(&dc,FALSE);
	m_pDib->Draw(&dc,CPoint(0,0),m_pDib->GetDimensions());
}

void CDlgWizard::OnPaintStep5(CDC& dc)
{
	CMuseApp* pApp = (CMuseApp*) AfxGetApp();
	CDC memdc;
	memdc.CreateCompatibleDC(&dc);
	CBitmap bmp;
	BITMAP bm;
	if(pApp->m_nConfidence < 3)
		bmp.LoadBitmap(IDB_GREEN);
	else if(pApp->m_nConfidence < 6)
		bmp.LoadBitmap(IDB_YELLOW);
	else
		bmp.LoadBitmap(IDB_RED);
	bmp.GetBitmap(&bm);
	memdc.SelectObject(&bmp);
	dc.BitBlt(15,15,bm.bmWidth,bm.bmHeight,&memdc,0,0,SRCCOPY);

	CString str;
	dc.SetBkColor(RGB(192,192,192));
	if(pApp->m_nConfidence < 3)
		str = "Confidence Level: High";
	else if(pApp->m_nConfidence < 6)
		str = "Confidence Level: Medium";
	else
		str = "Confidence Level: Low";
	dc.TextOut(70,30,str);
}

void CDlgWizard::OnPaletteChanged( CWnd* /*pFocusWindow*/ )
{
	InvalidateRect(NULL);
}

BOOL CDlgWizard::OnQueryNewPalette( )
{
	InvalidateRect(NULL);
	return true;
}
