#if !defined(AFX_DLGWIZARD_H__06687263_3933_11D3_9F4A_D45B06C10627__INCLUDED_)
#define AFX_DLGWIZARD_H__06687263_3933_11D3_9F4A_D45B06C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgWizard.h : header file
//

class CMuseDoc;

/////////////////////////////////////////////////////////////////////////////
// CDlgWizard dialog

class CDlgWizard : public CDialog
{
// Construction
public:
	void OnPaintStep5(CDC& dc);
	void OnPaintStep0(CDC& dc);
	void SetConfidenceWarnings();
	void DblclkResultList(NM_LISTVIEW* pNMHDR);
	void DoSearch();
	BOOL DoPromptFileName(CString& fileName, DWORD lFlags);
	CMuseDoc* m_pDoc;
	void HideAll();
	void StartStep();
	bool FinishStep();
	CDlgWizard(CWnd* pParent = NULL);   // standard constructor
	
// Dialog Data
	//{{AFX_DATA(CDlgWizard)
	enum { IDD = IDD_WIZARD };
	CButton	m_button2;
	CListCtrl	m_list;
	CButton	m_button;
	CString	m_sText;
	int		m_nRadio;
	CString	m_sEdit;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgWizard)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CDib* m_pDib;
	int m_nSource; // 1=from sound card, 0=from file
	int m_nStep;
	CArray<int,int> m_result; // search results

	// Generated message map functions
	//{{AFX_MSG(CDlgWizard)
	afx_msg void OnNext();
	afx_msg void OnPrev();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnTextButton();
	afx_msg void OnTextButton2();
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnFileExit();
	afx_msg void OnHelpAbout();
	afx_msg void OnViewDetails();
	afx_msg void OnViewSonglist();
	afx_msg void OnPaint();
	afx_msg void OnPaletteChanged( CWnd* pFocusWindow );
	afx_msg BOOL OnQueryNewPalette( );
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	WINDOWPLACEMENT m_wp1,m_wp2;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGWIZARD_H__06687263_3933_11D3_9F4A_D45B06C10627__INCLUDED_)
