// DurNoteEditDist.cpp: implementation of the CDurNoteEditDist class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Muse.h"
#include "DurNoteEditDist.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

int CDurNoteEditDist::DeleteCost(const CDurNote& /*deleted*/)
{
	return 10;
}

int CDurNoteEditDist::InsertCost(const CDurNote& /*inserted*/)
{
	return 10;
}

int CDurNoteEditDist::ChangeCost(const CDurNote& from, const CDurNote& to)
{
	int d1 = from.Distance(), d2 = to.Distance();
	if(d1==d2)
		return 0;
	return abs(d1-d2);
}

