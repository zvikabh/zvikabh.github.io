// DurNoteEditDist.h: interface for the CDurNoteEditDist class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DURNOTEEDITDIST_H__EE27A789_2766_11D3_9F4A_0C8A06C10627__INCLUDED_)
#define AFX_DURNOTEEDITDIST_H__EE27A789_2766_11D3_9F4A_0C8A06C10627__INCLUDED_

#if !defined(AFX_EDITDIST_H__34A34743_2727_11D3_9F4A_0C8A06C10627__INCLUDED_)
#	include "EditDist.h"
#endif

#if !defined(AFX_NOTE_H__F8271EE7_8E10_11D2_9F4A_CCF705C10627__INCLUDED_)
#	include "Note.h"
#endif

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CDurNoteEditDist : public CEditDist<CDurNote>
{
public:
	int DeleteCost(const CDurNote& deleted); // cost of deletion
	int InsertCost(const CDurNote& inserted); // cost of insertion
	int ChangeCost(const CDurNote& from, const CDurNote& to); // cost of changing
};

#endif // !defined(AFX_DURNOTEEDITDIST_H__EE27A789_2766_11D3_9F4A_0C8A06C10627__INCLUDED_)
