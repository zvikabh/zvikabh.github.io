// EditDist.cpp: implementation of the CEditDist class.
// CEditDist is a class for performing calculations of edit distance
// on generic data types.
// Zvika Ben-Haim, 1999.
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Muse.h"
#include "EditDist.h"
#include "Note.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#pragma warning(disable: 4661)

template <class Type>
int CEditDist<Type>::EditDistance(const Type* ar1, int n, const Type* ar2, int m)
{
	int *graph = new int[(n+1)*(m+1)];
	int a,b,p1,p2,p3;
	int nPrice;
	int maxnm = (n>m ? n : m);

	m_xmax = n;
	m_ymax = m;

	// Fill first row and column of graph
	graph[0] = 0;
	for(a=1; a<=n; a++)
		graph[a] = graph[a-1] + InsertCost(ar1[a-1],a,0);
	for(a=1; a<=m; a++)
		graph[a*(n+1)] = graph[(a-1)*(n+1)] + DeleteCost(ar2[a-1],0,a);

	// Fill the rest of the graph
	// Order of filling is in an L-shape: One row, then one column, then one row etc.
	for(a=1; a<=maxnm; a++) {
		// fill all (remaining) entries in row 'a'.
		for(b=a; b<=n; b++) {
			if(a>m) continue;
			p1 = graph[(a-1)*(n+1)+b-1] + ChangeCost(ar1[b-1],ar2[a-1],b,a);
			p2 = graph[(a-1)*(n+1)+b]   + InsertCost(ar2[a-1],b,a);
			p3 = graph[a*(n+1)+b-1]     + DeleteCost(ar1[b-1],b,a);
			graph[a*(n+1)+b] = min(min(p1,p2),p3);
		}

		// fill all (remaining) entries in column 'a'.
		for(b=a; b<=m; b++) {
			if(a>n) continue;
			p1 = graph[(b-1)*(n+1)+a-1] + ChangeCost(ar1[a-1],ar2[b-1],a,b);
			p2 = graph[(b-1)*(n+1)+a]   + InsertCost(ar2[b-1],a,b);
			p3 = graph[b*(n+1)+a-1]     + DeleteCost(ar1[a-1],a,b);
			graph[b*(n+1)+a] = min(min(p1,p2),p3);
		}
	}

	nPrice = graph[(n+1)*(m+1)-1];
	delete[] graph;
	return nPrice;
}

// Implementation of CIntEditDist class.
//////////////////////////////////////////////////////////////////////

int CIntEditDist::DeleteCost(const int& /*deleted*/, int x, int y)
{
	if(x==m_xmax || y==m_ymax)
		return 0;
	if(m_bProp)
		return m_nDeleteCost/(m_xmax+m_ymax);
	else
		return m_nDeleteCost;
}

int CIntEditDist::InsertCost(const int& /*inserted*/, int x, int y)
{
	if(x==m_xmax || y==m_ymax)
		return 0;
	if(m_bProp)
		return m_nInsertCost/(m_xmax+m_ymax);
	else
		return m_nInsertCost;
}

int CIntEditDist::ChangeCost(const int& from, const int& to, int /*x*/, int /*y*/)
{
	if(m_bProp)
		return (abs(from-to)*15)/min(m_xmax,m_ymax);
	else
		return abs(from-to);
}

int CParsonsEditDist::DeleteCost(const int& deleted, int x, int y)
{
	if(x==m_xmax || y==m_ymax)
		return 0;
	switch(deleted) {
	case 0: // R
		return m_nInsertRCost;
	case 1: // U
	case -1: // D
		return m_nInsertUCost;
	default:
		ASSERT(0);
		return 100;
	}
}

int CParsonsEditDist::InsertCost(const int& inserted, int x, int y)
{
	if(x==m_xmax || y==m_ymax)
		return 0;
	switch(inserted) {
	case 0: // R
		return m_nInsertRCost;
	case 1: // U
	case -1: // D
		return m_nInsertUCost;
	default:
		ASSERT(0);
		return 100;
	}
}

int CParsonsEditDist::ChangeCost(const int& from, const int& to, int /*x*/, int /*y*/)
{
	if(from==to)
		return 0;
	switch(from) {
	case 1:  // U
		return (to==0 ? m_nURCost : m_nUDCost);
	case 0:  // R
		return m_nRUCost;
	case -1: // D
		return (to==0 ? m_nURCost : m_nUDCost);
	default:
		ASSERT(0);
		return 100;
	}
}

int CDblIntEditDist::InsertCost(const CDblInt& inserted, int x, int y)
{
	ied.m_xmax = m_xmax;
	ied.m_ymax = m_ymax;
	return ied.InsertCost(inserted.a,x,y);
}

int CDblIntEditDist::DeleteCost(const CDblInt& deleted, int x, int y)
{
	ied.m_xmax = m_xmax;
	ied.m_ymax = m_ymax;
	return ied.DeleteCost(deleted.a,x,y);
}

int CDblIntEditDist::ChangeCost(const CDblInt& from, const CDblInt& to, int x, int y)
{
	ied.m_xmax = m_xmax;
	ied.m_ymax = m_ymax;
	int base = ied.ChangeCost(from.a,to.a,x,y);
	float factor;
	if(from.b == to.b)
		factor=1;
	else if(abs(from.b-to.b)==1)
		factor=m_fNearFactor;
	else
		factor=m_fFarFactor;
	return (int)(factor*base);
}

CDblIntEditDist::CDblIntEditDist(int nInsertCost, int nDeleteCost, bool bProp,
								 float fNearFactor, float fFarFactor)
 : ied(nInsertCost, nDeleteCost, bProp)
{
	m_fNearFactor = fNearFactor;
	m_fFarFactor = fFarFactor;
}

// use lines like this to explicitly instantiate all member functions of a class
// (these lines must appear in this file)
#pragma warning(disable: 4660)
template class CEditDist<int>; // see "Explicit Instantiation" in the online help
template class CEditDist<CDblInt>;
#pragma warning(default: 4660)
#pragma warning(default: 4661)
