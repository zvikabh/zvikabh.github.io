// Muse.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Muse.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "SegParam.h"
#include "MuseDoc.h"
#include "MuseView.h"
#include "DlgSettings.h"
#include "EditDist.h"
#include "DlgWizard.h"
#include "SearchParam.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMuseApp

BEGIN_MESSAGE_MAP(CMuseApp, CWinApp)
	//{{AFX_MSG_MAP(CMuseApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_SETTINGS_WIZARD, OnSettingsWizard)
	ON_COMMAND(ID_SETTINGS_PITCH, OnSettingsPitch)
	ON_COMMAND(ID_SETTINGS_SEG2, OnSettingsSeg2)
	ON_COMMAND(ID_SETTINGS_SEARCH, OnSettingsSearch)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMuseApp construction

CMuseApp::CMuseApp()
{
	m_nConfidence = 0;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMuseApp object

CMuseApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMuseApp initialization

BOOL CMuseApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	AfxInitRichEdit();

	srand( (unsigned) time(NULL) );

	// Change the registry key under which our settings are stored.
	// You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Zvika Ben-Haim"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(
		IDR_MUSETYPE,
		RUNTIME_CLASS(CMuseDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CMuseView));
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Generate the low-pass filter
	GenerateLPF();

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(SW_SHOWMAXIMIZED);
	pMainFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About


CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CMuseApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CMuseApp commands

static float sinc(float x) {
	if(x!=0)
		return float(sin(x)/x);
	else
		return 1;
}

void CMuseApp::GenerateLPF()
{
	// generate the filter coefficients
	int i;
	const float cutoff = 800; // in hertz
	const float W = float(2*PI*cutoff/SMPRATE);

	for(i=0; i<=FILTER_N; i++) {
		m_fLPF[i] = W * float(sinc(W*float(i-FILTER_N/2)) / PI);
		m_fLPF[i] *= 0.5f * float(1 - cos(2*PI*i/FILTER_N)); // Han window
	}
}

void CMuseApp::OnSettingsWizard() 
{
	SetWizardMode(true);
}

void CMuseApp::SetWizardMode(BOOL bWizard)
{
	if(bWizard) {
		AfxGetMainWnd()->ShowWindow(SW_HIDE);
		WriteProfileInt("Wizard","bWizardMode",1);
		m_pWizardDlg = new CDlgWizard;
		m_pWizardDlg->Create(CDlgWizard::IDD);
		m_pWizardDlg->ShowWindow(SW_SHOW);
	} else {
		AfxGetMainWnd()->ShowWindow(SW_SHOWMAXIMIZED);
		WriteProfileInt("Wizard","bWizardMode",0);
		m_pWizardDlg->DestroyWindow();
		delete m_pWizardDlg;
	}
}

void CMuseApp::OnSettingsPitch() 
{
	CDlgSettings dlg;
	dlg.DoModal();
}


void CMuseApp::OnSettingsSeg2() 
{
	CSegParam dlg("Segmentation Settings");
	dlg.DoModal();
}

void CMuseApp::OnSettingsSearch() 
{
	CSearchParam dlg("Search Parameters");
	dlg.DoModal();
}

int CMuseApp::WriteProfileFloat(LPCSTR sSection, LPCSTR sEntry, float fValue)
{
	return WriteProfileBinary(sSection,sEntry,(LPBYTE)(void*)&fValue,sizeof(float));
}

float CMuseApp::GetProfileFloat(LPCSTR sSection, LPCSTR sEntry, float fDefault)
{
	float *pdata,actual_data;
	UINT size;
	GetProfileBinary(sSection,sEntry,(LPBYTE*)(void**)&pdata,&size);
	if(pdata && size==sizeof(float)) {
		actual_data = *pdata;
		delete [] pdata;
		return actual_data;
	}
	else
		return fDefault;
}

void CMuseApp::AddWarning(UINT nResourceID, int nConfidence)
{
	if(nResourceID) {
		CString str;
		str.LoadString(nResourceID);
		m_saWarnings.Add(str);
	}
	m_nConfidence += nConfidence;
}
