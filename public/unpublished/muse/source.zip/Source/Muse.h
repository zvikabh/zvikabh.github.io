// Muse.h : main header file for the MUSE application
//

#if !defined(AFX_MUSE_H__3D418087_7FA5_11D2_9F4A_1CF705C10627__INCLUDED_)
#define AFX_MUSE_H__3D418087_7FA5_11D2_9F4A_1CF705C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "DlgInfo.h"		// Generic information report dialog
#include "DlgWizard.h"	// Added by ClassView

/////////////////////////////////////////////////////////////////////////////
// CMuseApp:
// See Muse.cpp for the implementation of this class
//

class CMuseApp : public CWinApp
{
public:
	void AddWarning(UINT nResourceID, int nConfidence);
	int m_nConfidence; // confidence-lowering points (0-2: green, 3-5: yellow, 6+: red)
	CStringArray m_saWarnings; // confidence-level warnings
	float GetProfileFloat(LPCSTR sSection,LPCSTR sEntry,float fDefault=0.f);
	int WriteProfileFloat(LPCSTR sSection,LPCSTR sEntry,float fValue);
	void SetWizardMode(BOOL bWizard);
	void GenerateLPF();
	CMuseApp();
	float Filter(UINT n) { ASSERT(n<=FILTER_N); return m_fLPF[n]; } ;

protected:
	CDlgWizard* m_pWizardDlg;
	float m_fLPF[FILTER_N + 1];

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMuseApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMuseApp)
	afx_msg void OnAppAbout();
	afx_msg void OnSettingsWizard();
	afx_msg void OnSettingsPitch();
	afx_msg void OnSettingsSeg2();
	afx_msg void OnSettingsSearch();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MUSE_H__3D418087_7FA5_11D2_9F4A_1CF705C10627__INCLUDED_)
