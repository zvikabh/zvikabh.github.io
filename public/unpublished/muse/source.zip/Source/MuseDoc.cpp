// MuseDoc.cpp : implementation of the CMuseDoc class
//

#include "stdafx.h"
#include "Muse.h"
#include "MuseDoc.h"
#include "Pitch.h"
#include "DlgSegment.h"
#include "DlgSegParam.h"
#include "DlgNotes.h"
#include "DlgNoteWriter.h"
#include "DlgDBView.h"
#include "DlgWizard.h"
#include "DlgBatch.h"
#include "SegParam.h"
#include "DlgNoiseSim.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMuseDoc

IMPLEMENT_DYNCREATE(CMuseDoc, CDocument)

BEGIN_MESSAGE_MAP(CMuseDoc, CDocument)
	//{{AFX_MSG_MAP(CMuseDoc)
	ON_COMMAND(ID_FILE_RECORD, OnFileRecord)
	ON_UPDATE_COMMAND_UI(ID_FILE_RECORD, OnUpdateFileRecord)
	ON_COMMAND(ID_ANALYZE_LPF, OnAnalyzeLpf)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_RAW, OnUpdateFileSaveRaw)
	ON_COMMAND(ID_FILE_SAVE_RAW, OnFileSaveRaw)
	ON_COMMAND(ID_FILE_OPEN_WAVE, OnFileOpenWave)
	ON_UPDATE_COMMAND_UI(ID_ANALYZE_PITCH, OnUpdateAnalyzePitch)
	ON_COMMAND(ID_ANALYZE_PITCH, OnAnalyzePitch)
	ON_COMMAND(ID_VIEW_NOTES, OnViewNotes)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NOTES, OnUpdateViewNotes)
	ON_COMMAND(ID_DATABASE_NOTE_WRITER, OnDatabaseNoteWriter)
	ON_COMMAND(ID_DATABASE_VIEW, OnDatabaseView)
	ON_COMMAND(ID_RECORD_PLAYBACK, OnRecordPlayback)
	ON_UPDATE_COMMAND_UI(ID_RECORD_PLAYBACK, OnUpdateRecordPlayback)
	ON_UPDATE_COMMAND_UI(ID_ANALYZE_SEGMENT2, OnUpdateAnalyzeSegment2)
	ON_COMMAND(ID_ANALYZE_SEGMENT2, OnAnalyzeSegment2)
	ON_COMMAND(ID_SETTINGS_BATCH, OnSettingsBatch)
	ON_COMMAND(ID_SETTINGS_NOISE_SIM, OnSettingsNoiseSim)
	ON_COMMAND(ID_DATABASE_IMPORT, OnDatabaseImport)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMuseDoc construction/destruction

CMuseDoc::CMuseDoc()
{
	m_bRecording = 0;
	m_pwi = 0;
	m_data = 0;
	m_cDataLen = 0;
	m_pDlg = 0;
}

CMuseDoc::~CMuseDoc()
{
}

BOOL CMuseDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMuseDoc serialization

void CMuseDoc::Serialize(CArchive& ar)
{
	int i,nmax;
	if(ar.IsStoring()) {
		nmax = m_database.GetSize();
		ar << nmax;
		for(i=0; i<nmax; i++)
			m_database[i].Serialize(ar);
	} else {
		CSong song;
		ar >> nmax;
		for(i=0; i<nmax; i++) {
			song.Clear();
			song.Serialize(ar);
			m_database.Add(song);
		}
	}
	UpdateAllViews(NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CMuseDoc diagnostics

#ifdef _DEBUG
void CMuseDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMuseDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMuseDoc commands

void CMuseDoc::OnFileRecord() 
{
	m_bRecording ^= 1; // toggle recording state

	if(m_bRecording) {
		// start recording
		if(!ClearData()) {
			m_bRecording=0;
			return;
		}

		WAVEFORMATEX wfx;
		wfx.wFormatTag = WAVE_FORMAT_PCM;	// PCM format
		wfx.nChannels = 1;					// mono sound
		wfx.nSamplesPerSec = SMPRATE;		// sampling rate
		wfx.nAvgBytesPerSec = SMPRATE*2;	// 16 bytes per sample
		wfx.nBlockAlign = 2;				// bytes per sample
		wfx.wBitsPerSample = 16;			// bits per sample
		wfx.cbSize = 0;						// extra info (ignored for PCM)

		POSITION pos = GetFirstViewPosition();
		CView* pView = GetNextView(pos);

		try {
			m_pwi = new CWaveIn(WAVE_MAPPER, &wfx, 2048, pView->m_hWnd);
			m_pwi->Start();
		}
		catch(CException* e) {
			// an error messsage has already been displayed
			m_bRecording ^= 1;
			e->Delete();
		}

	} else {
		// stop recording
		try {
			m_pwi->Stop();
			delete m_pwi; // automatically deletes all remaining buffers
		}
		catch(CException* e) {
			// an error message has already been displayed
			m_bRecording ^= 1;
			e->Delete();
		}
	}
}

void CMuseDoc::OnUpdateFileRecord(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bRecording);
}

void CMuseDoc::OnCloseDocument() 
{
	if(m_bRecording)
		OnFileRecord();
	
	if(m_cDataLen > 0) {
		m_cDataLen = 0;
		free(m_data);
		m_data=0;
	}

	if(m_pDlg!=0) {
		m_pDlg->EndDialog(0);
		delete m_pDlg;
	}

	CDocument::OnCloseDocument();
}

void CMuseDoc::OnWaveInNotify()
{
	// if m_bRecording is false, then these are just leftover messages and their buffers
	// have already been deleted by the destructor, so ignore them.
	if(!m_bRecording)
		return;

	WAVEHDR* pwh = m_pwi->StackPop();
	sample* newdata = (sample*)pwh->lpData;
	m_data = (sample*)realloc(m_data, sizeof(sample)*m_cDataLen + pwh->dwBytesRecorded);
	if(m_data==NULL)
		AfxThrowMemoryException();
	memcpy(m_data + m_cDataLen, newdata, pwh->dwBytesRecorded);
	m_cDataLen += pwh->dwBytesRecorded/2;

	DeleteWaveHdr( pwh );

	if(AfxGetApp()->GetProfileInt("Wizard","bWizardMode",1)) {
		// wizard mode; don't do anything.
	} else {
		// classic mode
		UpdateAllViews(NULL);
	}
}

void CMuseDoc::OnAnalyzeLpf() 
// performs a low-pass filter on the entire file
{
	if(m_cDataLen == 0)
		return;

	CWaitCursor waitcursor;
	int i,j;
	const int N2 = FILTER_N/2;
	sample* newdata = new sample[m_cDataLen];
	float d;
	CMuseApp* pApp = (CMuseApp*) AfxGetApp();

	for(i=N2; (UINT)i<m_cDataLen-N2; i++) {
		d=0;
		for(j=0; j<=FILTER_N; j++) {
			d += m_data[i+j-N2] * pApp->Filter(j);
		}
		newdata[i] =(sample)d;
	}

	m_data = (sample*)realloc(m_data, 2*(m_cDataLen-FILTER_N));

	for(i=N2; (UINT)i<m_cDataLen-N2; i++) {
		m_data[i-N2] = newdata[i];
	}
	
	m_cDataLen -= FILTER_N;
	delete[] newdata;

	UpdateAllViews(NULL);
}

void CMuseDoc::LPF(int nsmp, int nFilterLen)
{
	// performs a low-pass filter on the last nsmp samples of the file.
	// the low-pass filter is a moving average of the surrounding samples, nFilterLen samples
	// in each direction.

	ASSERT( (int)m_cDataLen > nFilterLen*3 + nsmp );
	
	sample* output = new sample[nsmp];
	memset( output, 0, sizeof(sample)*nsmp);

	int i,j,c,s,start;
	start = m_cDataLen - nsmp - nFilterLen - 1;
	for(i=0; i<nsmp; i++) {
		for(j=-nFilterLen, c=s=0; j<=nFilterLen; j++) {
			s += m_data[start+i+j];
		}
		output[i] = (sample)(s/(nFilterLen*2+1));
	}

	memcpy( m_data+start, output, sizeof(sample)*nsmp );
	delete[] output;
}

sample& CMuseDoc::operator[](UINT nPos)
{
	ASSERT(nPos<m_cDataLen);
	return m_data[nPos];
}

void CMuseDoc::OnUpdateFileSaveRaw(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_cDataLen>0 );
}

void CMuseDoc::OnFileSaveRaw() 
{
	CFileDialog dlg(FALSE, "raw", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,
		"Raw Wave Files (*.raw)|*.raw|All Files (*.*)|*.*||");
	if(dlg.DoModal() != IDOK)
		return;

	try {
		CFile file(dlg.GetPathName(), CFile::modeCreate|CFile::modeWrite);
		file.Write( m_data, sizeof(sample)*m_cDataLen );
		file.Close();
	}

	catch(CFileException* e) {
		AfxMessageBox(IDS_FILE_ERROR);
		e->Delete();
	}
}

void CMuseDoc::OnFileOpenWave() 
{
	DoFileOpenWave(NULL);
}

bool CMuseDoc::DoFileOpenWave(const CString* pPathName)
// if pPathName==NULL, prompts for a file name; otherwise, opens the file pPathName.
{
	CString name;

	if(!ClearData(pPathName!=NULL))
		return false;

	if(pPathName==NULL) {
		CFileDialog dlg(TRUE, "raw", NULL, OFN_FILEMUSTEXIST,
			"Raw Wave Files (*.raw)|*.raw|PCM Wave Files (*.pcm)|*.pcm|All Files (*.*)|*.*||");
		if(dlg.DoModal() != IDOK) {
			UpdateAllViews(NULL);
			return false;
		}
		name = dlg.GetPathName();
	} else
		name = *pPathName;

	try {
		CFile file(name, CFile::modeRead);
		m_cDataLen = file.GetLength()/2;
		m_data = (sample*)malloc(m_cDataLen*2);
		file.Read(m_data, m_cDataLen*2);
		file.Close();
	}

	catch(CException* e) {
		AfxMessageBox(IDS_FILE_ERROR);
		e->Delete();
		UpdateAllViews(NULL);
		return false;
	}

	UpdateAllViews(NULL);
	return true;
}

BOOL CMuseDoc::ClearData(bool bNoPrompt/*=false*/)
// asks for confirmation, then frees the memory allocated by m_data, and sets
// m_data and m_cDataLen to 0. Returns TRUE on success, FALSE if user aborted operation.
{
	if(m_data != 0) {
		if(!bNoPrompt)
			if(AfxMessageBox(IDS_ALREADY_EXISTS,MB_OKCANCEL) == IDCANCEL)
				return FALSE;
		free(m_data); // clear current buffer
		m_data = 0;
		m_cDataLen = 0;
		m_break.SetSize(0);
		m_segment.SetSize(0);
		m_pitch.SetSize(0);
		m_nrep.SetSize(0);
	}
	return TRUE;
}

void CMuseDoc::OnUpdateAnalyzePitch(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_cDataLen>0 && (!m_bRecording) );
}

void CMuseDoc::OnUpdateAnalyzeSegment2(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_pitch.GetSize() > 0 );
}

void CMuseDoc::OnAnalyzePitch() 
{
	float tpitch,f;
	int i,j;
	CString str,str2;

	m_pitch.SetSize(0);
	m_nrep.SetSize(0);
	m_segment.SetSize(0);
	m_volume.SetSize(0);

	FindPitch(0, m_cDataLen-310, 10, 150, 1);

	if(AfxGetApp()->GetProfileInt("PitchSettings","Numeric",0)) {
		BeginWaitCursor();
		if(m_pDlg==0) {
			m_pDlg = new CDlgInfo("Pitch Results","");
			m_pDlg->Create(CDlgInfo::IDD);
		}
		m_pDlg->m_edit = "";
		RestoreWaitCursor();

		tpitch=0;
		m_pDlg->m_edit = "time\tnsamples\tfreq (hz)\tvolume\r\n";
		for(i=0; i<m_pitch.GetSize(); i++) {
			str.Format("%5d\t%7.2f\t%6.2f\t%6.2f\r\n",
				(int)tpitch,m_pitch[i],SMPRATE/m_pitch[i],m_volume[i]);
			tpitch += m_pitch[i];
			str2 += str;
		}
		m_pDlg->m_edit += str2;

		m_pDlg->UpdateData(FALSE);
		m_pDlg->ShowWindow(SW_SHOW);
		RestoreWaitCursor();
	}

	if(AfxGetApp()->GetProfileInt("PitchSettings","Output",0)) {
		BeginWaitCursor();
		try {
			str.Format("%s\\output.raw",
				(const char*)AfxGetApp()->GetProfileString("PitchSettings","OutputRawDir","."));
			CFile file(str,CFile::modeWrite|CFile::modeCreate);
			sample smp;
			f=0;
			for(i=0; i<m_pitch.GetSize(); i++) {
				for(j=0; j<m_pitch[i]; j++) {
					smp = sample(m_volume[i] * sin(j/m_pitch[i]*2*PI));
					file.Write(&smp, sizeof(sample));
				}
			}
		}
		catch(CException* e) {
			AfxMessageBox("Error writing OUTPUT.RAW, Check directory settings.");
			e->Delete();
		}
	}
	EndWaitCursor();
	UpdateAllViews(NULL);
}


/*
void CMuseDoc::OnAnalyzeSegPitch() 
// archaic function. used for manual segmentation.
{
	CDlgSegment dlg;
	CDlgInfo info("Segmented Pitch Output","");
	int i,j,from,to;
	CString str;
	CNote note;
	float avecorr, sdcorr, avepitch, sdpitch;
	CArray<float,float> arPitch;
	POSITION pos;

	dlg.DoModal();

	pos = dlg.m_list.GetHeadPosition();
	for(i=0; pos; i++) {
		str = dlg.m_list.GetNext(pos);
		sscanf(str,"%d-%d",&from,&to);
		FindPitch(from, to, 10, 150, 1, &avecorr, &sdcorr, &avepitch, &sdpitch);
		note = CNote(SMPRATE/avepitch);
		str.Format("#%d: Pitch %.2f (%.2f) == %.2f Hz == %s\r\n",
			i+1, avepitch, sdpitch, SMPRATE/avepitch, (const char*)note.Name());
		arPitch.Add(avepitch);
		info.m_edit += str;
	}

	info.DoModal();

	BeginWaitCursor();
	
	m_pitch.SetSize(0);
	m_nrep.SetSize(0);
	m_segment.SetSize(0);
	CSegment seg;
	for(i=0; i<arPitch.GetSize(); i++) {
		m_pitch.Add(arPitch[i]);
		seg.start = i;
		seg.end = i+1;
		seg.note = CNote(SMPRATE/arPitch[i]);
		m_segment.Add(seg);
	}

	try {
		str.Format("%s\\output.raw",
			(const char*)AfxGetApp()->GetProfileString("PitchSettings","OutputRawDir","."));
		CFile file(str,CFile::modeWrite|CFile::modeCreate);
		sample smp;
		for(i=0; i<m_pitch.GetSize(); i++) {
			for(j=0; j<4000; j++) {
				smp = sample(25000 * sin(j/m_pitch[i]*2*PI));
				file.Write(&smp, sizeof(sample));
			}
		}
	}
	catch(CException* e) {
		AfxMessageBox("Error writing OUTPUT.RAW, Check directory settings.");
		e->Delete();
	}

	EndWaitCursor();
}
*/

void CMuseDoc::FindPitch(int posStart, int posEnd, int minPitch, int maxPitch, int stepPitch,
						 float * pAveCorr /*=NULL*/, float * pSdCorr /*=NULL*/, 
						 float * pAvePitch /*=NULL*/, float * pSdPitch /*=NULL*/)
/* Finds pitch values for specified segment, and places them in m_pitch, which is an array
   containing one pitch value for every pitch cycle.
   Also, finds volume of each of these segments. The volume is determined using GetVolume
   for the region of 25 msec around the current segment.
*/
{
	double tpitch, tp2, tcorr, tc2;
	int posCur;
	float correl,pitch,sx,sxx,f;
	int i,nrep;
	CMuseApp* pApp = (CMuseApp*)AfxGetApp();

	BeginWaitCursor();

	// Find pitch and volume
	tcorr=tc2=tpitch=tp2=0;
	posCur = posStart;
	for(i=0; (int)posCur<posEnd-2*maxPitch; i++) {
		posCur = (int) tpitch;
		pitch = sr_pitch(m_data+posCur, minPitch, maxPitch, stepPitch, &correl, &nrep);
		// Pitch interpolation
		if(i>0) {
			m_pitch.Add((pitch+m_pitch[2*i-2])/2);
			m_nrep.Add(1);
		}
		m_pitch.Add(pitch);
		m_nrep.Add(nrep);
		tcorr += correl;
		tc2 += correl*correl;
		tpitch += pitch;
		tp2 += pitch*pitch;
		if(tpitch>=100 && tpitch<posEnd-100)
			m_volume.Add(GetVolume((int)(tpitch-100), (int)(tpitch+100)));
		else if(tpitch>=100)
			m_volume.Add(GetVolume((int)(tpitch-100), posEnd)); // not enough samples - use whatever you've got
		else
			m_volume.Add(GetVolume(0, (int)(tpitch+100)));
		// Volume interpolation
		if(i>0) {
			float j=m_volume[2*i-1];
			m_volume.SetAt(i*2-1,(m_volume[2*i-2]+j)/2);
			m_volume.Add(j);
		}
	}

	// Normalize volume
	// Multiply the volume by a factor, so that its SD is equal to 5000.
	// This ensures that the volume units are normalized, so that the same triggers can
	// be used on different volume sets. (Aug 6)
	sx=sxx=0;
	for(i=0; i<m_volume.GetSize(); i++) {
		f = m_volume[i];
		sx += f;
		sxx += f*f;
	}
	f = (float)sqrt((sxx/m_volume.GetSize()) - (sx*sx/m_volume.GetSize()/m_volume.GetSize()));

	// Volume confidence level
	if(f<100)
		pApp->AddWarning(IDS_VERY_LOW_VOL,6);
	else if(f<300)
		pApp->AddWarning(IDS_LOW_VOL,3);
	else if(f<500)
		pApp->AddWarning(IDS_MAYBE_LOW_VOL,1);
	else if(f>12000)
		pApp->AddWarning(IDS_HIGH_VOL,3);

	// Sufficient length confidence level
	if(m_volume.GetSize() < 400)
		pApp->AddWarning(IDS_VERY_SHORT_LEN, 5);
	else if(m_volume.GetSize() < 800)
		pApp->AddWarning(IDS_SHORT_LEN, 3);

	// Normalize volume
	if(f<1) f=1;
	for(i=0; i<m_volume.GetSize(); i++)
		m_volume.SetAt(i, m_volume[i]*5000/f);

	// Return statistical information, if required
	if(pAveCorr!=NULL) {
		(*pAveCorr) = (float)(tcorr/i);
		(*pSdCorr) = (float)sqrt(tc2/i - (*pAveCorr)*(*pAveCorr));
		(*pAvePitch) = (float)(tpitch/i);
		(*pSdPitch) = (float)sqrt(tp2/i - (*pAvePitch)*(*pAvePitch));
	}

	EndWaitCursor();
}

#if(0)
/* This function is archaic. It is replaced by OnAnalyzeSegment2(). */
void CMuseDoc::OnAnalyzeSegment() 
{
	int start=-1;
	int i,j,n,repeat;
	float f,f1,f2,f3,s=0,ave=m_pitch[0];
	float maxvol; // maximum volume in entire file
	float vtrig;  // volume trigger = maxvol*0.2
	float cmaxvol=0; // maximum volume in current segment
	float file_ave_vol = GetVolume(0,m_cDataLen-1);

	// this is used to load the settings for the segmentation
	CDlgSegParam dlg;
	dlg.Create(CDlgSegParam::IDD);
	dlg.DestroyWindow();

	m_break.SetSize(0);
	m_segment.SetSize(0);

	// SMOOTHING:
	// Removes obvoius flukes from m_pitch (Feb 25)
	f = dlg.m_nSmooth/100.f; // smoothing trigger
	f2 = CNote::Smp2Semitone(m_pitch[0]);
	f3 = CNote::Smp2Semitone(m_pitch[1]);
	for(i=1; i<m_pitch.GetSize()-1; i++) {
		f1 = f2;
		f2 = f3;
		f3 = CNote::Smp2Semitone(m_pitch[i+1]);
		if( (f2-f1>4 && f2-f3>4 && abs(f1-f3)<4)  ||  (f2-f1<-4 && f2-f3<-4 && abs(f1-f3)<4) ) {
			m_pitch.SetAt(i,0.5f*(m_pitch[i-1]+m_pitch[i+1]));
			f2 = CNote::Smp2Semitone(m_pitch[i]);
			m_nrep.SetAt(i,-1);
		}
	}

	// FIND MAXIMUM VOLUME
	maxvol=0;
	for(i=0; i<m_pitch.GetSize(); i++)
		if(maxvol < m_volume[i])
			maxvol=m_volume[i];
	vtrig = maxvol*0.2f;

	// BREAK DETECTION:
	// Place breaks between suspected segments
	// Volume triggering added May 26
	for(i=0; i<m_pitch.GetSize()-dlg.m_nFlukes; i++) {
		f = m_pitch[i];
		s += f;
		if(cmaxvol < m_volume[i])
			cmaxvol = m_volume[i];
		if(i-start < dlg.m_nMinLen) {
			ave = s / (i-start);
			continue;
		}
		
		// Volume triggering (May 26, June 6)
		if(dlg.m_bVolTrig) {
			if( m_volume[i] < cmaxvol*0.2 ) {
				// place break
				start = i-1;
				cmaxvol=0;
				s = f;
				ave=s;
				m_break.Add(i);
				continue;
			}
		}

		// Inverse volume triggering (May 31)
		if(dlg.m_bInvVolTrig) {
			if( m_volume[i]>vtrig && m_volume[i-1]<vtrig && m_volume[i-2]<vtrig && 
				m_volume[i-3]<vtrig )
			{
				start = i-1;
				cmaxvol=0;
				s = f;
				ave=s;
				m_break.Add(i);
				continue;
			}
		}
		
		f3 = CNote::Smp2Semitone(f);
		f2 = CNote::Smp2Semitone(ave);
		if(abs(f3-f2) > dlg.m_nTrigger/100.) {
			// make sure this isn't a fluke
			for(j=1; j<dlg.m_nFlukes; j++) {
				f1 = f3;
				f3 = CNote::Smp2Semitone(m_pitch[i+j]);
				// the second part of the 'if' condition below was commented on Feb 25.
				if(abs(f3-f2) < dlg.m_nTrigger/100. /*|| abs(f1-f3) > dlg.m_nNFDist/100.*/) {
					// fluke; ignore it
					break;
				}
			}
			if(j==dlg.m_nFlukes) {
				// not a fluke, so add a break
				start = i-1;
				cmaxvol=0;
				s = f;
				ave = s;
				m_break.Add(i);
				maxvol=0;
			}
		}
		ave = s / (i-start);
	}

/*	This algorithm was described in Jan 17 and removed in Feb 11.
	j=1;
	for(i=0; i<m_break.GetSize(); i++) {
		s = 0;
		ndat=0;
		for(jstart=j; j<m_break[i]; j++) {
			if(abs(1200.*log(m_pitch[j]/m_pitch[j-1])/log(2)) < dlg.m_nSlope) {
				s += m_pitch[j];
				ndat++;
			}
		}
		if(j-jstart < dlg.m_nLen4Note || j-jstart<=1 || ndat==0) {
			m_note.Add(0);
			continue;
		}
		ave = s/ndat;
		m_note.Add(SMPRATE/ave);
	}
	*/

	// This loop executes the conversion to notes and backtracking twice.
	// This is intended to ensure that the conversion to notes will be based on the
	// backtracked segments. (Feb 24)
	for(repeat=0; repeat<2; repeat++) {
		
		// CONVERSION TO NOTES:
		// Find actual segments and their notes. May create segments which don't cover the entire
		// time length, and these will be considered "don't care"s.
		// this algorithm is described in Feb 11.
		CSegment seg;
		float Ex,Ex2; // E[x], E[x^2]
		float Ext,Ext2; // mean of all values of x within 1 sd of E[x].
		float Ed; // average pitch change from one pitch to the next
		float sd;
		float tpitch=0; // total pitch up to current pos
		float spitch; // total pitch up to start of current segment
		m_segment.SetSize(0);
		for(i=0; i<m_break.GetSize(); i++) {
			if(i==0)
				start=0;
			else
				start=m_break[i-1];
			spitch = tpitch;
			Ed=Ex=Ex2=Ext=Ext2=0;
			for(j=start; j<m_break[i]; j++) {
				Ex += m_pitch[j];
				Ex2 += m_pitch[j]*m_pitch[j];
				if(j>start)
					Ed += abs(SMPRATE/m_pitch[j]-SMPRATE/m_pitch[j-1]);
			}
			tpitch += Ex;
			if(m_break[i]-start < dlg.m_nLen4Note) {
				seg.start = DONT_CARE;
				m_segment.Add(seg);
				continue;
			}
			Ex /= (m_break[i]-start);
			Ex2 /= (m_break[i]-start);
			Ed /= (m_break[i]-start-1);
			if(Ed > dlg.m_nSD) {
				// high deviation ==> don't-care segment
				seg.start = DONT_CARE;
				m_segment.Add(seg);
				continue;
			}
			if(dlg.m_bVolDC) {
				if(GetVolume((int)spitch,(int)tpitch) < 0.2*file_ave_vol) {
					// low volume ==> don't-care segment (May 31)
					seg.start = DONT_CARE;
					m_segment.Add(seg);
					continue;
				}
			}
			sd = (float)sqrt(Ex2 - Ex*Ex);
			for(int k=0; k<5; k++) {
				Ext=Ext2=0;
				n=0;
				for(j=start; j<m_break[i]; j++) {
					// samples are included in the averaging if:
					// 1. their pitch is within 2.5 SD of the average
					// 2. their slope is at most 2 times the average slope
					if(abs(m_pitch[j]-Ex)<(2.5-k*0.15)*sd &&
						(j==0 || abs(SMPRATE/m_pitch[j]-SMPRATE/m_pitch[j-1])<Ed*2)) {
							n++;
							Ext += m_pitch[j];
							Ext2 += m_pitch[j]*m_pitch[j];
					}
				}
				Ext /= n;
				Ext2 /= n;
				sd = (float)sqrt(Ext2 - Ext*Ext);
				Ex=Ext;
				if((float)n/(m_break[i]-start-1) < 0.5) {
					// less than 50% of the segment is used for finding the pitch; don't go any lower
					break;
				}
			}
			seg.start = start;
			seg.end = m_break[i];
			seg.note = CNote(SMPRATE/Ext);
			seg.pitch = Ext;
			seg.tstart = (int)spitch;
			seg.tend = (int)tpitch;
			m_segment.Add(seg);
		}

		// BACKTRACKING:
		// (Optionally) move breaks back to compensate for the delay effect first described
		// in Feb 17. Added Feb 24. See journal entry for Feb 24 for more details.
		if(repeat==1) break; // don't do this twice
		if(dlg.m_bBacktrack) {
			float dnext,dprev;
			for(i=0; i<m_break.GetSize()-1; i++) {
				if(m_segment[i].start==DONT_CARE)
					continue; // previous segment is don't care, so don't backtrack into it
				if(m_segment[i+1].start==DONT_CARE)
					continue; // next segment is don't care, so don't enlarge it
				for(j=m_break[i]; j>1; j--) {
					dprev = abs(m_pitch[j] - m_segment[i].pitch);
					dnext = abs(m_pitch[j] - m_segment[i+1].pitch);
					if(dnext>dprev) {
						// we're closer to the previous segment, which means we've backtracked far enough
						break;
					}
					if(i>0 && j<m_break[i-1]+10) {
						// we're too close to the previous segment, stop now before it's too late!
						break;
					}
				}
				m_break.SetAt(i,j);
			}
		}
	} // end of for(repeat).

	// Remove breaks which separate between two don't-care segments. (Feb 25)
	if(dlg.m_bRemove) {
		for(i=0; i<m_break.GetSize()-1; i++) {
			if(m_segment[i].start==DONT_CARE && m_segment[i+1].start==DONT_CARE)
				m_break.SetAt(i,DONT_CARE);
		}
		for(i=0; i<m_break.GetSize()-1; i++) {
			if(m_break[i]==DONT_CARE) {
				m_break.RemoveAt(i);
				i--;
			}
		}
	}
	
	// Remove all don't care segments, because this might confuse future users of m_segment.
	for(i=0; i<m_segment.GetSize(); i++) {
		if(m_segment[i].start==DONT_CARE) {
			m_segment.RemoveAt(i);
			i--;
		}
	}

	UpdateAllViews(NULL);
}
#endif//(0)

float CMuseDoc::GetVolume(int posStart, int posEnd)
// returns the RMS of the segment between posStart and posEnd
{
	float t=0,t2=0;
	int i;
	for(i=posStart; i<posEnd; i++) {
		t += (float)m_data[i];
		t2 += (float)m_data[i]*m_data[i];
	}
	return (float) sqrt(t2/(posEnd-posStart) - (t*t)/(posEnd-posStart)/(posEnd-posStart));
}

void CMuseDoc::OnViewNotes() 
{
	CDlgNotes dlg(this);
	dlg.DoModal();
}

void CMuseDoc::OnUpdateViewNotes(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_segment.GetSize() > 0);
}

void CMuseDoc::OnDatabaseNoteWriter() 
{
	CDlgNoteWriter dlg;
	if(dlg.DoModal()==IDOK) {
		m_database.Add(dlg.m_song);
		SetModifiedFlag();
	}
}

void CMuseDoc::OnDatabaseView() 
{
	CDlgDBView dlg(this);
	dlg.DoModal();
}

void CMuseDoc::AddNote()
{
	OnDatabaseNoteWriter();
}


void CMuseDoc::OnRecordPlayback() 
{
	// if no recording is available, or if we are currently recording, then abort
	if(m_cDataLen==0 || m_bRecording)
		return;

	BYTE* pWave = new BYTE[0x2c+m_cDataLen*2];

	// write header for 16-bit, 8 kHz, mono
	BYTE hdr[0x2c] = {
		0x52, 0x49, 0x46, 0x46, 0x00, 0x00, 0x00, 0x00,
		0x57, 0x41, 0x56, 0x45, 0x66, 0x6D, 0x74, 0x20,
		0x10, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
		0x40, 0x1F, 0x00, 0x00, 0x80, 0x3E, 0x00, 0x00,
		0x02, 0x00, 0x10, 0x00, 0x64, 0x61, 0x74, 0x61, 
		0x20, 0x03, 0x00, 0x00 };

	// set file size in header
	*(LONG*)(hdr+0x04) = (LONG)(m_cDataLen*2 + 0x2c - 8);
	*(LONG*)(hdr+0x28) = (LONG)(m_cDataLen*2);
	
	// copy data into pWave
	memcpy(pWave, hdr, 0x2c);
	memcpy(pWave+0x2c, m_data, m_cDataLen*2);

	// play the sound
	BeginWaitCursor();
	PlaySound((char*)pWave, NULL, SND_MEMORY|SND_SYNC);
	EndWaitCursor();

	// clear memory
	delete [] pWave;
}

void CMuseDoc::OnUpdateRecordPlayback(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_cDataLen>0 && (!m_bRecording) );
}

void CMuseDoc::OnAnalyzeSegment2() 
// alternative segmentation algorithm
{
	// load segmentation parameters
	CSegParam dlg("Segmentation Parameters");
	dlg.Create(NULL,WS_SYSMENU | WS_POPUP | WS_CAPTION | DS_MODALFRAME);
	dlg.SetActivePage(&dlg.p2);
	dlg.SetActivePage(&dlg.p3);
	dlg.DestroyWindow();

	// do actual segmentation
	DoSegmentation(dlg);
}

void CMuseDoc::DoSegmentation(const CSegParam& dlg)
// Called from OnAnalyzeSegment2() and from CDlgBatch::ProcessFile().
{
	int i,j,k,pos;
	float sx,sxx,f,f1,f2,f3,trigstart,trigend;

	if(m_pitch.GetSize() < 2)
		return;

	// CLEAR PREVIOUS SEGMENTATION
	BeginWaitCursor();
	m_break.SetSize(0);
	m_segment.SetSize(0);

	// SMOOTHING:
	// Removes obvious mistakes from m_pitch (Feb 25)
	f = dlg.p3.m_nMSmoothTrig/100.f; // smoothing trigger
	f2 = CNote::Smp2Semitone(m_pitch[0]);
	f3 = CNote::Smp2Semitone(m_pitch[1]);
	for(i=1; i<m_pitch.GetSize()-1; i++) {
		f1 = f2;
		f2 = f3;
		f3 = CNote::Smp2Semitone(m_pitch[i+1]);
		if( (f2-f1>f && f2-f3>f && abs(f1-f3)<f)  ||  (f2-f1<-f && f2-f3<-f && abs(f1-f3)<f) ) {
			m_pitch.SetAt(i,0.5f*(m_pitch[i-1]+m_pitch[i+1]));
			f2 = CNote::Smp2Semitone(m_pitch[i]);
			m_nrep.SetAt(i,-1);
		}
	}

	// INITIAL SEGMENT IDENTIFICATION:
	// Based on the volume only.
	float vmin=1e8,vmaxcurseg=0,curtrigstart,curtrigend,fade,endadj,startadj;
	fade = (100-dlg.p1.m_nIFade)/100.f;
	endadj = dlg.p1.m_nIEndAdj/100.f;
	startadj = dlg.p1.m_nIStartAdj/100.f;
	for(i=0; i<m_volume.GetSize(); i++) {
		if(m_volume[i]<vmin)
			vmin=m_volume[i];
	}
	trigstart = dlg.p1.m_nIStart + vmin;
	trigend =   dlg.p1.m_nIEnd + vmin;
	curtrigstart=trigstart;
	CSegment curseg;
	bool bStarting=true;
	for(pos=0; pos<m_volume.GetSize(); pos++) {
		if(bStarting) {
			// look for starting point
			if(m_volume[pos]<curtrigstart) {
				if(curtrigstart>trigstart)
					curtrigstart*=fade;
				continue;
			}
			for(i=1; i<dlg.p1.m_nIStartLen; i++) {
				if(m_volume[pos]<curtrigstart) {
					i=-1;
					break;
				}
			}
			if(i==-1)
				continue;
			// found it!
			curseg.start=pos;
			if(dlg.p1.m_bINudge) {
				// Perform segment nudge (Aug 10 supplemental)
				while(curseg.start>0 && m_volume[curseg.start-1]<m_volume[curseg.start])
					curseg.start--;
			}
			m_break.Add(curseg.start);
			vmaxcurseg=0;
			bStarting=false;
		} else {
			// look for endpoint
			if(m_volume[pos]>vmaxcurseg)
				vmaxcurseg=m_volume[pos];
			curtrigend = max(trigend, vmaxcurseg*endadj);
			if(m_volume[pos]>curtrigend)
				continue;
			for(i=1; i<=dlg.p1.m_nIEndLen; i++) {
				if(m_volume[pos]>curtrigend) {
					i=-1;
					break;
				}
			}
			if(i==-1)
				continue;
			// found it!
			curseg.end=pos;
			if(dlg.p1.m_bINudge) {
				// Perform segment nudge (Aug 10 supplemental)
				while(curseg.end<m_volume.GetSize()-1 && m_volume[curseg.end+1]<m_volume[curseg.end])
					curseg.end++;
			}
			m_break.Add(curseg.end);
			m_segment.Add(curseg);
			bStarting=true;
			curtrigstart = max(trigstart,vmaxcurseg*startadj);
		}
	}

	// BOUND SHRINKING:
	// Only the central part of each segment are used.
	float bound1,bound2;
	bound1 = (100-dlg.p3.m_nMBoundShrink)/200.f;
	bound2 = 1-bound1;
	for(i=0; i<m_segment.GetSize(); i++) {
		curseg.start = (int)(bound2*m_segment[i].start + bound1*m_segment[i].end);
		curseg.end   = (int)(bound1*m_segment[i].start + bound2*m_segment[i].end);
		m_segment.SetAt(i,curseg);
	}

	// SECONDARY SEGMENTATION:
	// Find the best continuous region within each segment, based on pitch values.
	float pave,psd;
	for(i=0; i<m_segment.GetSize(); i++) {

		/* Old algorithm (see Jul 16)
		// the following is repeated six times, each time shrinking the segment
		// by 10% (for a minimum size equal to 53% of the original), until the segment
		// has a low enough standard deviation.
		for(k=0; k<6; k++) {
			if(m_segment[i].end - m_segment[i].start < 10) {
				// too short; probably noise.
				k=6;
				break;
			}

			// find ave, sd of frequency, in cents
			sx=sxx=0;
			for(j=m_segment[i].start; j<m_segment[i].end; j++) {
				f = 100*CNote::Smp2Semitone(m_pitch[j]);
				sx+=f;
				sxx+=f*f;
			}
			pave=sx/(m_segment[i].end-m_segment[i].start);
			psd = (float)sqrt(sxx/(m_segment[i].end-m_segment[i].start) - pave*pave);

			// determine if this segment is a melodic segment with relatively constant pitch
			if(psd<100) {
				// yes, this is good. we can stop shrinking the segment.
				break;
			}

			// otherwise, shrink the segment and try again.
			f1 = (float)(0.95*m_segment[i].start + 0.05*m_segment[i].end);
			f2 = (float)(0.05*m_segment[i].start + 0.95*m_segment[i].end);
			m_segment[i].start = (int)ceil(f1);
			m_segment[i].end   = (int)f2;
		}

		if(k==6) {
			// could not find low-SD segment. delete it; it's probably noise.
			m_segment.RemoveAt(i);
			i--;
			if(m_segment.GetSize() == 0) {
				AfxMessageBox("There are no valid segments. It is possible that the beginning of the recording was too noisy. You should record a short period of silence before the beginning of the recording, in order to calibrate the system.");
				return;
			}
			continue;
		}*/
		
		// New algorithm (Jul 31)
		// Modified for suboptimal search (Aug 14)
		float ave,sd;
		int bstart=0,bend=0,start,end,step;
		curseg = m_segment[i];
		step = (curseg.end-curseg.start)/dlg.p2.m_nSSuboptLen;
		if(step==0) step=1;
		for(start=curseg.start; start<curseg.end-dlg.p2.m_nSReqLen; start+=step) {
			for(end=start+dlg.p2.m_nSReqLen; end<curseg.end; end+=step) {
				if(end-start <= bend-bstart)
					continue;
				ave = GetAveCents(start,end,&sd);
				if(sd>dlg.p2.m_nSHopelessSD)
					break; // no chance on this value of start; might as well move on
				if(sd<dlg.p2.m_nSReqSD) {
					bend=end;
					bstart=start;
				}
			}
		}
		if(step>1) {
			// make a more accurate search around the region in which we found the
			// best segment
			int gstart1,gstart2,gend1,gend2;
			gstart1 = max(curseg.start,bstart-step);
			gstart2 = min(curseg.end,bstart+step);
			gend1 = max(curseg.start,bend-step);
			gend2 = min(curseg.end,bend+step);
			for(start=gstart1; start<gstart2; start++) {
				for(end=gend1; end<gend2; end++) {
					if(end-start <= bend-bstart)
						continue;
					ave = GetAveCents(start,end,&sd);
					if(sd>dlg.p2.m_nSHopelessSD)
						break;
					if(sd<dlg.p2.m_nSReqSD) {
						bend=end;
						bstart=start;
					}
				}
			}
		}
		if(bend-bstart<dlg.p2.m_nSReqLen) {
			// could not find low-SD segment. delete it; it's probably noise.
			m_segment.RemoveAt(i);
			i--;
			if(m_segment.GetSize() == 0) {
				AfxMessageBox("There are no valid segments. It is possible that the recording volume is too low. Please try recording again, and make sure your microphone is connected and recording settings are set correctly.");
				return;
			}
			continue;
		}

		m_segment[i].start = bstart;
		m_segment[i].end   = bend;
		pave = GetAveCents(bstart,bend,&psd);

		// perform averaging over pitch values within f2 SD.
		// (f2 decreases from 2.5 to 1.6 in 4 iterations)
		for(f2=2.5f; f2>1.5f; f2-=.3f) {
			k=0;
			sx=sxx=0;
			for(j=m_segment[i].start; j<m_segment[i].end; j++) {
				f = 100*CNote::Smp2Semitone(m_pitch[j]);
				if(abs(f-pave) > f2*psd)
					continue;
				k++;
				sx+=f;
				sxx+=f*f;
			}
			pave = sx/k;
			psd = (float) sqrt(sxx/k - pave*pave);
		}

		// write to segment
		m_segment[i].pitch = CNote::Semitone2Smp(pave/100);
		m_segment[i].note  = CNote(8000/m_segment[i].pitch);
	}

	// PHYSICAL LIMITATIONS ADJUSTMENT
	// Removes notes which are more than 1 octave higher or lower than the average note,
	// since these notes are usually impossible to produce by human singers, and are
	// therefore (probably) mistakes in the identification. (Aug 14)
	pave=0;
	float p;
	for(i=0; i<m_segment.GetSize(); i++) {
		pave += m_segment[i].note.DistanceCents();
	}
	pave /= m_segment.GetSize();
	for(i=0; i<m_segment.GetSize(); i++) {
		p = (float)m_segment[i].note.DistanceCents();
		if(p>pave+dlg.p3.m_nMPhysLim || p<pave-dlg.p3.m_nMPhysLim) {
			// impossible! remove this note.
			m_segment.RemoveAt(i);
			i--;
			if(m_segment.GetSize() == 0) {
				AfxMessageBox("There are no valid segments. It is possible that the recording volume is too low. Please try recording again, and make sure your microphone is connected and recording settings are set correctly.");
				return;
			}
		}
	}

	// FIND TIME POSITIONS
	// (Fill in the tstart and tend values in the CSegment structure)
	if(m_segment.GetSize() > 0) {
		f=0; // total time
		bStarting=true;
		pos=0;
		for(i=0; i<m_pitch.GetSize(); i++) {
			f+=m_pitch[i];
			if(bStarting) {
				if(m_segment[pos].start == i) {
					m_segment[pos].tstart = (int)f;
					bStarting=false;
				}
			} else {
				if(m_segment[pos].end == i) {
					m_segment[pos].tend = (int)f;
					bStarting=true;
					pos++;
					if(pos>=m_segment.GetSize())
						break;
				}
			}
		}
	}

	// CONFIDENCE LEVEL CHECK
	CMuseApp* pApp = (CMuseApp*) AfxGetApp();
	// Sufficient number of notes
	if(m_segment.GetSize() < 8)
		pApp->AddWarning(IDS_NOT_ENOUGH_NOTES,6);
	else if(m_segment.GetSize() < 10)
		pApp->AddWarning(IDS_NOT_MANY_NOTES,3);

	// Sufficient segment length
	// Checks that the shortest segment is long enough
	CNumArray<int> na;
	if(m_segment.GetSize()>0) {
		for(i=0; i<m_segment.GetSize(); i++)
			na.Add(m_segment[i].end-m_segment[i].start);
		j = na.Min();
		if(j<15)
			pApp->AddWarning(IDS_MED_SEG_LEN_V_LOW,4);
		else if(j<30)
			pApp->AddWarning(IDS_MED_SEG_LEN_LOW,2);
	}

	EndWaitCursor();
	UpdateAllViews(NULL);
}

float CMuseDoc::GetAvePitch(int start, int end)
// finds the average of the pitch between cycles start and end
{
	float sum=0;
	for(int i=start; i<end; i++)
		sum += m_pitch[i];
	return sum/(end-start);
}

float CMuseDoc::GetAveCents(int start, int end, float* sd /*=0*/)
// finds the average frequency, in cents from A-4
{
	int j;
	float f,sx,sxx,pave;
	sx=sxx=0;
	for(j=start; j<end; j++) {
		f = 100*CNote::Smp2Semitone(m_pitch[j]);
		sx+=f;
		sxx+=f*f;
	}
	pave = sx/(end-start);
	if(sd!=0) {
		*sd = (float) sqrt(sxx/(end-start) - pave*pave);
	}
	return pave;
}

void CMuseDoc::OnSettingsBatch() 
{
	CDlgBatch dlg;
	dlg.DoModal();
}

void CMuseDoc::OnSettingsNoiseSim() 
{
	CDlgNoiseSim dlg(this);
	dlg.DoModal();
}

void CMuseDoc::OnDatabaseImport() 
{
	CFileDialog dlg(TRUE, "sng", NULL, OFN_HIDEREADONLY | OFN_FILEMUSTEXIST,
		"Karioke Studio Song File (*.sng)|*.sng|All Files (*.*)|*.*||");
	CDlgNoteWriter dnw;
	BYTE* data;
	long len;
	int i;
	CDurNote durnote;

	// Get file name
	if(dlg.DoModal() != IDOK)
		return;

	// Load file into memory
	BeginWaitCursor();
	data=0;
	try {
		CFile file(dlg.GetPathName(),CFile::modeRead);
		len = file.GetLength();
		data = new BYTE[len];
		file.Read(data,len);
	}
	catch(CException* e) {
		AfxMessageBox("Error importing file.");
		e->Delete();
		if(data!=0)
			delete[] data;
		return;
	}

	// Verify file format
	if(data[0]!='K' || data[1]!='R' || data[2]!='K') {
		AfxMessageBox("File is incorrect format.");
		delete[] data;
		return;
	}

	// Process file (without using duration information)
	for(i=0xd; i<len; i++) {
		if(data[i]==0x91) {
			i++;
			if(i>=len)
				break;
			durnote = CDurNote((short)(data[i]/12 - 1), short(data[i]%12), 0, 4);
			dnw.m_song.m_durnote.Add(durnote);
		}
	}

	/*// Process file (using duration information)
	i=0xd;
	for(i=0xd; data[i]!=0x91; i++)
		; // null loop

	i--; // data[i] should now be at the start of a midi command
	int wait=0;
	char lyrics[10000];
	char* plyrics = lyrics;
	while(i<len) {
		if(data[i]&0x80) {
			wait += data[i+1];
			wait += 256*int(data[i]&0x7f);
			i+=2;
		} else {
			wait += data[i];
			i++;
		}
		if((data[i]&0xf0) == 0x90) {
			// note on
			if(data[i]==0x91) {
				// vocals, this is important
				durnote = CDurNote((short)(data[i+1]/12 - 2), short(data[i+1]%12), 0, 0);
				wait=0;
			}
			i+=3; // advance to next command
		} else if((data[i]&0xf0) == 0x80) {
			// note off
			if(data[i]==0x81) {
				// vocals, this is important
				durnote.SetDuration(wait/50);
				wait=0;
				dnw.m_song.m_durnote.Add(durnote);
			}
			i+=3; // advance to next command
		} else if(data[i]==0xff && data[i+1]==0x02) {
			// internal karioke signal
			i+=3; // advnace to next command
		} else if(data[i]==0xff && data[i+1]==0x01) {
			// internal karioke signal
			int j;
			i+=2;
			if(data[i]&0x80) {
				j=data[i]&0x7f;
				j+=data[i+1];
			} else {
				j=data[i];
			}
			i++;
			for(; j>0; j--) {
				if(data[i]=='\n')
					*(plyrics++)='\r';
				*(plyrics++) = data[i++];
			}
			*(plyrics++) = '\r';
			*(plyrics++) = '\n';
		} else if((data[i]&0xf0)==0xe0) {
			// i honestly don't know what this signifies
			i+=3;
		} else if((data[i]&0xf0)==0xd0) {
			// or this either
			i+=2;
		} else if((data[i]&0xf0)==0xb0) {
			// or this either
			i+=3;
		} else if((data[i]&0xf0)==0xc0) {
			// channel program change
			i+=2;
		} else if(data[i]==0xff && data[i+1]==0x51) {
			// set tempo
			i+=6;
		} else {
			TRACE("Unknown midi message: %02X\n",(int)data[i]);
			i++;
		}
	}

	*plyrics=0;*/

	delete[] data;
	EndWaitCursor();

	// Display the notes in the NoteWriter dialog box
	dnw.m_song.m_name = dlg.GetPathName();
	dnw.m_song.m_nTempo = 750;
	//dnw.m_song.m_comments = lyrics;
	dnw.GetDataFromSong();
	if(dnw.DoModal()==IDOK) {
		m_database.Add(dnw.m_song);
		SetModifiedFlag();
	}
}
