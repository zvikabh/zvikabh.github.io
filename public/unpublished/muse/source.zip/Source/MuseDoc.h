// MuseDoc.h : interface of the CMuseDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MUSEDOC_H__3D41808F_7FA5_11D2_9F4A_1CF705C10627__INCLUDED_)
#define AFX_MUSEDOC_H__3D41808F_7FA5_11D2_9F4A_1CF705C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define DONT_CARE	-100

#include "SegParam.h"

class CMuseDoc : public CDocument
{
friend class CDlgWizard;
friend class CDlgBatch;
protected: // create from serialization only
	CMuseDoc();
	BOOL IsRecording() { return m_bRecording; };
	DECLARE_DYNCREATE(CMuseDoc)
protected:
	sample* m_data; // recorded data
	UINT m_cDataLen; // recorded data length (in samples)

// Attributes
public:
	void DoSegmentation(const CSegParam& dlg);
	bool DoFileOpenWave(const CString * pPathName);
	struct CSegment { int start; int end; CNote note; float pitch; int tstart, tend; };
	CArray<CSong,CSong&> m_database; // song database
	sample& operator[](UINT nPos);
	UINT DataLen() {return m_cDataLen;}; // in samples
	CArray<float,float> m_pitch; // super-resolution pitch
	CArray<int,int>     m_nrep;  // # of repetitions used until SR pitch was found (should be 1)
								 // determines display color.
								 // 1: black, -1: blue, other: red
	CArray<float,float> m_volume;// (RMS) volume of segment
	CArray<int,int>		m_break; // positions of segmentations
	CArray<CSegment,CSegment&> m_segment; // segments

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMuseDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void OnCloseDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	float GetAveCents(int start, int end, float* sd=0);
	float GetAvePitch(int start, int end);
	void AddNote();
	float GetVolume(int posStart, int posEnd);
	void FindPitch(int posStart, int posEnd, int minPitch, int maxPitch, int stepPitch, float* pAveCorr=NULL, float* pSdCorr=NULL, float* pAvePitch=NULL, float* pSdPitch=NULL);
	BOOL ClearData(bool bNoPrompt=false);
	void LPF(int nsmp, int nFilterLen);
	CWaveIn* m_pwi;
	void OnWaveInNotify();
	virtual ~CMuseDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	CDlgInfo* m_pDlg;
	BOOL m_bRecording;
	//{{AFX_MSG(CMuseDoc)
	afx_msg void OnFileRecord();
	afx_msg void OnUpdateFileRecord(CCmdUI* pCmdUI);
	afx_msg void OnAnalyzeLpf();
	afx_msg void OnUpdateFileSaveRaw(CCmdUI* pCmdUI);
	afx_msg void OnFileSaveRaw();
	afx_msg void OnFileOpenWave();
	afx_msg void OnUpdateAnalyzePitch(CCmdUI* pCmdUI);
	afx_msg void OnAnalyzePitch();
	afx_msg void OnViewNotes();
	afx_msg void OnUpdateViewNotes(CCmdUI* pCmdUI);
	afx_msg void OnDatabaseNoteWriter();
	afx_msg void OnDatabaseView();
	afx_msg void OnRecordPlayback();
	afx_msg void OnUpdateRecordPlayback(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAnalyzeSegment2(CCmdUI* pCmdUI);
	afx_msg void OnAnalyzeSegment2();
	afx_msg void OnSettingsBatch();
	afx_msg void OnSettingsNoiseSim();
	afx_msg void OnDatabaseImport();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MUSEDOC_H__3D41808F_7FA5_11D2_9F4A_1CF705C10627__INCLUDED_)
