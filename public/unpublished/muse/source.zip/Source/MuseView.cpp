// MuseView.cpp : implementation of the CMuseView class
//

#include "stdafx.h"
#include "Muse.h"
#include "MuseDoc.h"
#include "MuseView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define SEP		40

/////////////////////////////////////////////////////////////////////////////
// CMuseView

IMPLEMENT_DYNCREATE(CMuseView, CScrollView)

BEGIN_MESSAGE_MAP(CMuseView, CScrollView)
	//{{AFX_MSG_MAP(CMuseView)
	ON_COMMAND(ID_ANALYZE_ZCF, OnAnalyzeZcf)
	ON_UPDATE_COMMAND_UI(ID_ANALYZE_ZCF, OnUpdateAnalyzeZcf)
	ON_COMMAND(ID_VIEW_SLOW, OnViewSlow)
	ON_UPDATE_COMMAND_UI(ID_VIEW_SLOW, OnUpdateViewSlow)
	ON_UPDATE_COMMAND_UI(ID_VIEW_WAVEFORM, OnUpdateViewWaveform)
	ON_COMMAND(ID_VIEW_WAVEFORM, OnViewWaveform)
	ON_COMMAND(ID_VIEW_PITCH, OnViewPitch)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PITCH, OnUpdateViewPitch)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
    ON_MESSAGE(WM_WAVEIN_NOTIFY_PUSH, OnWaveInNotify)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMuseView construction/destruction

CMuseView::CMuseView()
{
	m_bZCF = 0;
	m_nStep = 1;
	m_nViewType=1;
}

CMuseView::~CMuseView()
{
}

BOOL CMuseView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMuseView drawing

void CMuseView::OnDraw(CDC* pDC)
{
	if(AfxGetApp()->GetProfileInt("Wizard","bWizardMode",1)==1) {
		((CMuseApp*)AfxGetApp())->SetWizardMode(true);
		return;
	}

	switch(m_nViewType) {
	case 1:
		OnDrawWaveform(pDC); break;
	case 2:
		OnDrawPitch(pDC); break;
	default:
		ASSERT(0);
	}
}

void CMuseView::OnDrawWaveform(CDC* pDC)
{
	CMuseDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int nSum,nX;
	int i0,i;
	char smp, psmp;
	CString str;
	CPen red(PS_SOLID,1,RGB(255,0,0));
	CPen* pOld;
	CRect rect;
	GetClientRect(&rect);

	if(pDoc->DataLen() == 0)
		return;

	// draw latest samples on the screen
	pDC->MoveTo(0,128);
	pDC->LineTo(rect.right,128);
	pOld = pDC->SelectObject(&red);
	smp = 0;
	nSum = 0;
	nX = 0;
	i0 = pDoc->DataLen() - (rect.right-rect.left)*4;
	if(i0<0) i0=0;
	for(i=i0; (UINT)i<pDoc->DataLen(); i+=m_nStep) {
		psmp = smp;
		smp = HIBYTE((*pDoc)[i]);
		pDC->SetPixel((i-i0)/4,(int)smp+128,RGB(0,0,0));
		nSum += abs(smp);
		if(m_bZCF) {
			if( (smp>0&&psmp<=0) || (smp<0&&psmp>=0) ) {
				pDC->MoveTo((i-i0)/4,98);
				pDC->LineTo((i-i0)/4,158);
				nX++;
			}
		}
	}
	pDC->SelectObject(pOld);

	str.Format("Volume: %d",(int)((float)nSum/(pDoc->DataLen()-i0)*1000/128.));
	pDC->TextOut(5,300,str);
	if(m_bZCF) {
		str.Format("ZCF: %d Hz",(nX * 44100) / (pDoc->DataLen()-i0));
		pDC->TextOut(5,320,str);
	}
}

void CMuseView::OnDrawPitch(CDC* pDC)
{
	CMuseDoc* pDoc = GetDocument();
	CArray<float,float>& pitch = pDoc->m_pitch;
	int i,y;
	float f;
	CRect rect;

	GetClientRect(&rect);
	pDC->DPtoLP(&rect);

	// draw yellow background lines
	CPen penYellow(PS_SOLID,1,RGB(255,255,0));
	CPen * pPenOld = pDC->SelectObject(&penYellow);
	for(i=(rect.top/20)*20; i<rect.bottom; i+=20) {
		pDC->MoveTo(rect.left, i);
		pDC->LineTo(rect.right, i);
	}

	// draw pitch and volume graphs
	CPen pen(PS_SOLID,1,RGB(0,255,0));
	pDC->SelectObject(&pen);
	pDC->MoveTo(0,int((m_fMaxNote-m_fMinNote)*10 - (pDoc->m_volume[0]/300)));
	for(i=0; i<pitch.GetSize(); i++) {
		f = CNote::Smp2Semitone(pitch[i]);
		COLORREF col;
		switch(pDoc->m_nrep[i]) {
		case 1:		col = RGB(0,0,0); break;
		case -1:	col = RGB(0,0,255); break;
		default:	col = RGB(255,0,0); break;
		}
		y = int((m_fMaxNote-f)*20);
		pDC->SetPixel(i,y,col);
		if(col != RGB(0,0,0)) {
			pDC->SetPixel(i+1,y,col);
			pDC->SetPixel(i,y,col);
			pDC->SetPixel(i+1,y,col);
		}
		pDC->LineTo(i,int((m_fMaxNote-m_fMinNote)*10 - (pDoc->m_volume[i]/300)));
	}

	// draw segment breaks
	pDC->SetTextAlign(TA_RIGHT);
	for(i=0; i<pDoc->m_break.GetSize(); i++) {
		pDC->MoveTo(pDoc->m_break[i],rect.top);
		pDC->LineTo(pDoc->m_break[i],rect.bottom);
	}

	// draw blue pitch line in each segment
	CPen penblue(PS_SOLID,1,RGB(0,0,255));
	pDC->SelectObject(penblue);
	for(i=0; i<pDoc->m_segment.GetSize(); i++) {
		f = CNote::Smp2Semitone(pDoc->m_segment[i].pitch);
		y = int((m_fMaxNote-f)*20);
		pDC->MoveTo(pDoc->m_segment[i].start, y);
		pDC->LineTo(pDoc->m_segment[i].end, y);
	}

	pDC->SelectObject(pPenOld);
}

void CMuseView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	CSize sizeTotal;
	sizeTotal.cx = sizeTotal.cy = 1;
	SetScrollSizes(MM_TEXT, sizeTotal);
}

/////////////////////////////////////////////////////////////////////////////
// CMuseView printing

BOOL CMuseView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMuseView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMuseView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMuseView diagnostics

#ifdef _DEBUG
void CMuseView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CMuseView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CMuseDoc* CMuseView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMuseDoc)));
	return (CMuseDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMuseView message handlers

afx_msg LRESULT CMuseView::OnWaveInNotify(WPARAM /*wParam*/, LPARAM /*lParam*/)
// this message is passed directly on to the document object.
// (it's not sent there because the document doesn't have a message pump)
{
	GetDocument()->OnWaveInNotify();
	return 0;
}


void CMuseView::OnAnalyzeZcf() 
{
	m_bZCF ^= 1;
}

void CMuseView::OnUpdateAnalyzeZcf(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bZCF);
}

void CMuseView::OnViewSlow() 
{
	if(m_nStep==1)
		m_nStep = 4;
	else
		m_nStep = 1;
}

void CMuseView::OnUpdateViewSlow(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_nStep==4);
}

void CMuseView::OnUpdateViewWaveform(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_nViewType==1);
}

void CMuseView::OnUpdateViewPitch(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetDocument()->m_pitch.GetSize()>0);
	pCmdUI->SetCheck(m_nViewType==2);
}

void CMuseView::OnViewWaveform() 
{
	m_nViewType=1;
	CSize sizeTotal;
	sizeTotal.cx = sizeTotal.cy = 1;
	SetScrollSizes(MM_TEXT, sizeTotal);
	InvalidateRect(NULL);
}

void CMuseView::OnViewPitch() 
{
	m_nViewType=2;
	CSize sizeTotal;
	float f;
	m_fMaxNote=-1e6;
	m_fMinNote=1e6;

	sizeTotal.cx = GetDocument()->m_pitch.GetSize();
	if(sizeTotal.cx==0)
		sizeTotal.cx=1;

	for(int i=0; i<GetDocument()->m_pitch.GetSize(); i++) {
		f = CNote::Smp2Semitone(GetDocument()->m_pitch[i]);
		if(f>m_fMaxNote) m_fMaxNote=f;
		if(f<m_fMinNote) m_fMinNote=f;
	}
	sizeTotal.cy=(int)(m_fMaxNote-m_fMinNote+1)*20;
	if(sizeTotal.cy <= 0)
		sizeTotal.cy=1;

	SetScrollSizes(MM_TEXT, sizeTotal);
	InvalidateRect(NULL);
}

void CMuseView::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/) 
{
	switch(m_nViewType) {
	case 1:
		OnViewWaveform();
		break;
	case 2:
		OnViewPitch();
		break;
	default:
		ASSERT(0);
		break;
	}
}
