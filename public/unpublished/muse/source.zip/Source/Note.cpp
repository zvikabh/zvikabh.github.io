// Note.cpp: implementation of the CNote class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Muse.h"
#include "Note.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(CNote,CObject,1)

CNote::CNote(float freq)
// constructs a note with the given frequency
{
	float d = 12*(float)(log(freq/440)/log(2));
		// this is the number of semitones from A4.
		// positive = higher than A4; negative = lower than A4.
		// (from Taylor, C., "Exploring Music", p. 243)
	d += 9.5 + 48;
		// now d is the number of semitones from C0, plus 0.5
		// (so that the truncation will actully be a rounding).
	octave = (char)(int)(d / 12);
	tone   = (char)(int)(d-octave*12.);
	fine   = (char)(int)(((d-octave*12.-tone)*100)-50);
}

CString CNote::Name()
{
	CString str,str2;
	switch(tone) {
	case 0:  str = "C-"; break;
	case 1:  str = "C#"; break;
	case 2:  str = "D-"; break;
	case 3:  str = "D#"; break;
	case 4:  str = "E-"; break;
	case 5:  str = "F-"; break;
	case 6:  str = "F#"; break;
	case 7:  str = "G-"; break;
	case 8:  str = "G#"; break;
	case 9:  str = "A-"; break;
	case 10: str = "A#"; break;
	case 11: str = "B-"; break;
	default: str = "?-"; break;
	}
	str2.Format("%s%d (%d)",str,(int)octave,(int)octave*12+tone);
	return str2;
}

int CNote::Distance() const
// returns the distance, in semitones, from C4
{
	return int(octave-4)*12 + tone;
}

/*static*/ float CNote::Smp2Semitone(float smp)
// converts pitch length in samples to number of semitones relative to A-4
{
	return (float)(12*log((8000/smp)/440)/log(2));
}

/*static*/ float CNote::Semitone2Smp(float semitone)
// converts number of semitones relative to A-4 to pitch length in samples
{
	return 8000.f/440.f/(float)pow(2,semitone/12);
}

void CNote::Serialize(CArchive& ar)
{
	if(ar.IsStoring()) {
		ar << octave << tone << fine;
	} else {
		ar >> octave >> tone >> fine;
	}
}

float CNote::GetFreq() {
	// performs the reverse of CNote::CNote(float freq).
	float d;
	d = (int)octave*12 + tone + fine/100.f;
	d -= 9.5+48;
	// d is now the number of semitones from A4
	d/=12;
	d=(float)exp(d*log(2));
	d*=440;
	return d;
}

void CNote::Transpose(int delta)
// moves the note a given number of semitones up or down
{
	ASSERT(delta<=12 && delta>=-12);
	tone = char(tone + delta);
	while(tone<0) {
		tone+=12;
		octave--;
	}
	while(tone>11) {
		tone-=12;
		octave++;
	}
}

//////////////////////////////////////////////////////////////////////
// CDurNote Class
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(CDurNote,CNote,1)

void CDurNote::Serialize(CArchive& ar)
{
	// the nonstandard calling order is a result of downwards compatibility
	// with previous versions, in which the note and duration were not
	// encapsulated in a single class.
	if(ar.IsStoring()) {
		ar << duration;
		CNote::Serialize(ar);
	} else {
		ar >> duration;
		CNote::Serialize(ar);
	}
}

int CNote::DistanceCents()
// returns the distance, in cents, from C-4
{
	return (int(octave-4)*12 + tone)*100 + fine;
}

void CNote::TransposeCents(int nCents)
// moves the note a given number of cents up or down
{
	if(nCents==0) return;
	if(nCents>0) {
		octave = char(octave + nCents/1200);
		nCents -= (nCents/1200)*1200;
	} else {
		octave = char(octave - (-nCents)/1200);
		nCents += ((-nCents)/1200)*1200;
	}

	Transpose(nCents/100);
	int n = fine + (nCents%100);
	if(n>100) {
		Transpose(1);
		fine = (char)(n-100);
	} else if(n<0) {
		Transpose(-1);
		fine = (char)(n+100);
	} else {
		fine = (char)n;
	}
}
