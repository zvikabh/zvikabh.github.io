// Note.h: interface for the CNote class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NOTE_H__F8271EE7_8E10_11D2_9F4A_CCF705C10627__INCLUDED_)
#define AFX_NOTE_H__F8271EE7_8E10_11D2_9F4A_CCF705C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CNote : public CObject  
{
public:
	void TransposeCents(int nCents);
	int DistanceCents();
	void Transpose(int delta);
	DECLARE_SERIAL(CNote)
	static float Smp2Semitone(float smp);
	static float Semitone2Smp(float semitone);
	int Distance() const;
	void Serialize(CArchive& ar);
	CString Name();
	CNote(float freq);
	float GetFreq();
	CNote() { octave=tone=fine=0; };
	CNote(short _octave, short _tone, short _fine=0)
		{ octave=(char)_octave; tone=(char)_tone; fine=(char)_fine; };
	CNote(const CNote& note) { (*this)=note; };
	CNote& operator=(const CNote& note) 
		{ octave=note.octave; tone=note.tone; fine=note.fine; return *this; };
	char Tone() {return tone;};
	char Octave() {return octave;};
protected:
	char octave; // A-4 is 440 Hz
	char tone;   // 0=C, 1=C#, ... 11=B
	char fine;   // fine tuning, in cents (hundredths of semitones)
};


class CDurNote : public CNote  
// extension of the CNote class which also includes duration, in arbitrary units
{
public:
	CDurNote() {duration=0;};
	DECLARE_SERIAL(CDurNote)
	void Serialize(CArchive& ar);
	CDurNote(const CDurNote& note) : CNote((const CNote&)note) { duration=note.duration; };
	CDurNote(short _octave, short _tone, short _fine, int _duration) :
		CNote(_octave,_tone,_fine) { duration=_duration; };
	CDurNote(float freq, int _duration) : CNote(freq) { duration=_duration; };
	CDurNote(const CNote& note, int _duration) : CNote(note) { duration = _duration; };
	int GetDuration() { return duration; };
	void SetDuration(int dur) { duration = dur; };
protected:
	int duration;
};

#endif // !defined(AFX_NOTE_H__F8271EE7_8E10_11D2_9F4A_CCF705C10627__INCLUDED_)
