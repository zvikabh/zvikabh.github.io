// NumArray.cpp: implementation of the CNumArray class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "muse.h"
#include "NumArray.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

template <class Num>
CNumArray<Num>::CNumArray()
{

}

template <class Num>
CNumArray<Num>::~CNumArray()
{

}

template <class Num>
float CNumArray<Num>::Average()
// throws exception if GetSize()==0.
{
	int i;
	float sum=0;
	for(i=0; i<GetSize(); i++)
		sum += (float)ElementAt(i);
	return sum/GetSize();
}

template <class Num>
Num CNumArray<Num>::Median()
// throws exception if GetSize()==0.
{
	CNumArray<Num> copy;
	for(int i=0; i<GetSize(); i++)
		copy.Add(ElementAt(i));
	qsort(copy.GetData(),GetSize(),sizeof(Num),NumCompareFunc);
	return copy[GetSize()/2];
}

template <class Num>
/*static*/ int CNumArray<Num>::NumCompareFunc(const void* num1, const void* num2)
{
	Num n1 = *(Num*)num1;
	Num n2 = *(Num*)num2;
	if(n1 > n2)
		return 1;
	else if(n1 < n2)
		return -1;
	else 
		return 0;
}

template <class Num>
Num CNumArray<Num>::Min()
{
	Num min;
	int i;
	min = ElementAt(0);
	for(i=1; i<GetSize(); i++)
		if(ElementAt(i)<min)
			min=ElementAt(i);
	return min;
}

template <class Num>
Num CNumArray<Num>::Max()
{
	Num max;
	int i;
	max = ElementAt(0);
	for(i=1; i<GetSize(); i++)
		if(ElementAt(i)>max)
			max=ElementAt(i);
	return max;
}

template class CNumArray<int>; // explicit instantiation
