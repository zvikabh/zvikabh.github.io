// NumArray.h: interface for the CNumArray class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NUMARRAY_H__61928E41_5C75_11D3_9F4A_346B06C10627__INCLUDED_)
#define AFX_NUMARRAY_H__61928E41_5C75_11D3_9F4A_346B06C10627__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

template <class Num>
class CNumArray : public CArray<Num,Num>  
{
public:
	float Average();
	Num Median();
	CNumArray();
	virtual ~CNumArray();
	static int NumCompareFunc(const void* num1, const void* num2);
	Num Min();
	Num Max();
};

#endif // !defined(AFX_NUMARRAY_H__61928E41_5C75_11D3_9F4A_346B06C10627__INCLUDED_)
