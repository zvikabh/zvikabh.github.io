MUSE: MUsic Search Engine
-------------------------

Project started 19.11.98
Project ended   21.09.99
Zvika Ben-Haim
Guided by Gal Ashour
