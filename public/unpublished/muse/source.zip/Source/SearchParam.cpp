// SearchParam.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "SearchParam.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSearchParam1 dialog

IMPLEMENT_DYNCREATE(CSearchParam1, CPropertyPage)

CSearchParam1::CSearchParam1()
	: CPropertyPage(CSearchParam1::IDD)
{
	//{{AFX_DATA_INIT(CSearchParam1)
	m_nSearchMethod = -1;
	//}}AFX_DATA_INIT
}

CSearchParam1::~CSearchParam1()
{
}


void CSearchParam1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchParam1)
	DDX_Radio(pDX, IDC_RADIO1, m_nSearchMethod);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchParam1, CDialog)
	//{{AFX_MSG_MAP(CSearchParam1)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_BN_CLICKED(IDC_RADIO1, OnChange)
	ON_BN_CLICKED(IDC_RADIO2, OnChange)
	ON_BN_CLICKED(IDC_RADIO3, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchParam2 dialog

IMPLEMENT_DYNCREATE(CSearchParam2, CPropertyPage)

CSearchParam2::CSearchParam2()
	: CPropertyPage(CSearchParam2::IDD)
{
	//{{AFX_DATA_INIT(CSearchParam2)
	m_nPNoteDiff = 0;
	m_nPURCost = 0;
	m_nPRUCost = 0;
	m_nPUDCost = 0;
	m_nPInsertRCost = 0;
	m_nPInsertUCost = 0;
	//}}AFX_DATA_INIT
}

CSearchParam2::~CSearchParam2()
{
}


void CSearchParam2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchParam2)
	DDX_Text(pDX, IDC_EDIT1, m_nPNoteDiff);
	DDX_Text(pDX, IDC_EDIT4, m_nPURCost);
	DDX_Text(pDX, IDC_EDIT5, m_nPRUCost);
	DDX_Text(pDX, IDC_EDIT6, m_nPUDCost);
	DDX_Text(pDX, IDC_EDIT8, m_nPInsertRCost);
	DDX_Text(pDX, IDC_EDIT9, m_nPInsertUCost);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchParam2, CDialog)
	//{{AFX_MSG_MAP(CSearchParam2)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_EN_CHANGE(IDC_EDIT1, OnChange)
	ON_EN_CHANGE(IDC_EDIT4, OnChange)
	ON_EN_CHANGE(IDC_EDIT5, OnChange)
	ON_EN_CHANGE(IDC_EDIT6, OnChange)
	ON_EN_CHANGE(IDC_EDIT8, OnChange)
	ON_EN_CHANGE(IDC_EDIT9, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchParam3 dialog

IMPLEMENT_DYNCREATE(CSearchParam3, CPropertyPage)

CSearchParam3::CSearchParam3()
	: CPropertyPage(CSearchParam3::IDD)
{
	//{{AFX_DATA_INIT(CSearchParam3)
	m_bProp = FALSE;
	m_nInsertCost = 0;
	m_nDeleteCost = 0;
	//}}AFX_DATA_INIT
}

CSearchParam3::~CSearchParam3()
{
}


void CSearchParam3::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchParam3)
	DDX_Check(pDX, IDC_CHECK1, m_bProp);
	DDX_Text(pDX, IDC_EDIT1, m_nInsertCost);
	DDX_Text(pDX, IDC_EDIT4, m_nDeleteCost);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchParam3, CDialog)
	//{{AFX_MSG_MAP(CSearchParam3)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_EN_CHANGE(IDC_EDIT1, OnChange)
	ON_EN_CHANGE(IDC_EDIT4, OnChange)
	ON_BN_CLICKED(IDC_CHECK1, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchParam4 property page

IMPLEMENT_DYNCREATE(CSearchParam4, CPropertyPage)

CSearchParam4::CSearchParam4() : CPropertyPage(CSearchParam4::IDD)
{
	//{{AFX_DATA_INIT(CSearchParam4)
	m_fDShort = 0.0f;
	m_fDLong = 0.0f;
	m_fDNear = 0.0f;
	m_fDTotal = 0.0f;
	//}}AFX_DATA_INIT
}

CSearchParam4::~CSearchParam4()
{
}

void CSearchParam4::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchParam4)
	DDX_Text(pDX, IDC_EDIT1, m_fDShort);
	DDX_Text(pDX, IDC_EDIT4, m_fDLong);
	DDX_Text(pDX, IDC_EDIT5, m_fDNear);
	DDX_Text(pDX, IDC_EDIT8, m_fDTotal);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchParam4, CPropertyPage)
	//{{AFX_MSG_MAP(CSearchParam4)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_EN_CHANGE(IDC_EDIT1, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchParam

IMPLEMENT_DYNAMIC(CSearchParam, CPropertySheet)

CSearchParam::CSearchParam(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	AddPage(&p1);
	AddPage(&p2);
	AddPage(&p3);
	AddPage(&p4);
}

CSearchParam::CSearchParam(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&p1);
	AddPage(&p2);
	AddPage(&p3);
	AddPage(&p4);
}

CSearchParam::~CSearchParam()
{
}


BEGIN_MESSAGE_MAP(CSearchParam, CPropertySheet)
	//{{AFX_MSG_MAP(CSearchParam)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchParam message handlers

void CSearchParam1::OnReset() 
{
	m_nSearchMethod = 2;
	UpdateData(false);
}

void CSearchParam2::OnReset() 
{
	m_nPNoteDiff = 50;
	m_nPURCost = 2;
	m_nPRUCost = 2;
	m_nPUDCost = 20;
	m_nPInsertRCost = 1;
	m_nPInsertUCost = 3;
	UpdateData(false);
}

void CSearchParam3::OnReset() 
{
	m_nDeleteCost = 15000;
	m_nInsertCost = 15000;
	m_bProp = true;
	UpdateData(false);
}

void CSearchParam4::OnReset() 
{
	m_fDShort = 0.7f;
	m_fDLong = 1.7f;
	m_fDNear = 1.5f;
	m_fDTotal = 3.0f;
	UpdateData(false);
}

void CSearchParam1::OnChange() 
{
	SetModified();
}

void CSearchParam2::OnChange() 
{
	SetModified();
}

void CSearchParam3::OnChange() 
{
	SetModified();
}

void CSearchParam4::OnChange() 
{
	SetModified();
}

BOOL CSearchParam1::OnApply()
{
	UpdateData(true);
	CWinApp* app = AfxGetApp();
	app->WriteProfileInt("SearchParam","nSearchMode",m_nSearchMethod);
	return true;
}

BOOL CSearchParam2::OnApply()
{
	UpdateData(true);
	CWinApp* app = AfxGetApp();
	app->WriteProfileInt("SearchParam","nPNoteDiff",m_nPNoteDiff);
	app->WriteProfileInt("SearchParam","nPRUCost",m_nPRUCost);
	app->WriteProfileInt("SearchParam","nPURCost",m_nPURCost);
	app->WriteProfileInt("SearchParam","nPUDCost",m_nPUDCost);
	app->WriteProfileInt("SearchParam","nPInsertRCost",m_nPInsertRCost);
	app->WriteProfileInt("SearchParam","nPInsertUCost",m_nPInsertUCost);
	return true;
}

BOOL CSearchParam3::OnApply()
{
	UpdateData(true);
	CWinApp* app = AfxGetApp();
	app->WriteProfileInt("SearchParam","bFProp",m_bProp);
	app->WriteProfileInt("SearchParam","nFInsertCost",m_nInsertCost);
	app->WriteProfileInt("SearchParam","nFDeleteCost",m_nDeleteCost);
	return true;
}

BOOL CSearchParam4::OnApply()
{
	UpdateData(true);
	CMuseApp* app = (CMuseApp*)AfxGetApp();
	app->WriteProfileFloat("SearchParam","fDShort",m_fDShort);
	app->WriteProfileFloat("SearchParam","fDLong", m_fDLong);
	app->WriteProfileFloat("SearchParam","fDNear", m_fDNear);
	app->WriteProfileFloat("SearchParam","fDTotal",m_fDTotal);
	return true;
}

BOOL CSearchParam1::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CWinApp* app = AfxGetApp();
	m_nSearchMethod = app->GetProfileInt("SearchParam","nSearchMode",2);
	UpdateData(false);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CSearchParam2::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CWinApp* app = AfxGetApp();
	m_nPNoteDiff = app->GetProfileInt("SearchParam","nPNoteDiff",50);
	m_nPURCost = app->GetProfileInt("SearchParam","nPURCost",2);
	m_nPRUCost = app->GetProfileInt("SearchParam","nPRUCost",2);
	m_nPUDCost = app->GetProfileInt("SearchParam","nPUDCost",20);
	m_nPInsertRCost = app->GetProfileInt("SearchParam","nPInsertRCost",1);
	m_nPInsertUCost = app->GetProfileInt("SearchParam","nPInsertUCost",3);
	UpdateData(false);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CSearchParam3::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CWinApp* app = AfxGetApp();
	m_bProp = app->GetProfileInt("SearchParam","bFProp",1);
	m_nInsertCost = app->GetProfileInt("SearchParam","nFInsertCost",15000);
	m_nDeleteCost = app->GetProfileInt("SearchParam","nFDeleteCost",15000);
	UpdateData(false);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CSearchParam4::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CMuseApp* app = (CMuseApp*)AfxGetApp();

	m_fDShort = app->GetProfileFloat("SearchParam","fDShort",0.7f);
	m_fDLong  = app->GetProfileFloat("SearchParam","fDLong",1.7f);
	m_fDNear  = app->GetProfileFloat("SearchParam","fDNear",1.5f);
	m_fDTotal = app->GetProfileFloat("SearchParam","fDTotal",3.0f);

	UpdateData(false);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

