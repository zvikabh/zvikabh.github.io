#if !defined(AFX_SEARCHPARAM_H__902E47E1_5369_11D3_9F4A_346B06C10627__INCLUDED_)
#define AFX_SEARCHPARAM_H__902E47E1_5369_11D3_9F4A_346B06C10627__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SearchParam.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSearchParam1 dialog

class CSearchParam1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSearchParam1)
// Construction
public:
	CSearchParam1();   // standard constructor
	~CSearchParam1();
	virtual BOOL OnApply();

// Dialog Data
	//{{AFX_DATA(CSearchParam1)
	enum { IDD = IDD_SEARCHPARAM1 };
	int		m_nSearchMethod;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSearchParam1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSearchParam1)
	afx_msg void OnReset();
	afx_msg void OnChange();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CSearchParam2 dialog

class CSearchParam2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSearchParam2)
// Construction
public:
	CSearchParam2();   // standard constructor
	~CSearchParam2();
	virtual BOOL OnApply();

// Dialog Data
	//{{AFX_DATA(CSearchParam2)
	enum { IDD = IDD_SEARCHPARAM2 };
	int		m_nPNoteDiff;
	int		m_nPURCost;
	int		m_nPRUCost;
	int		m_nPUDCost;
	int		m_nPInsertRCost;
	int		m_nPInsertUCost;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSearchParam2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSearchParam2)
	afx_msg void OnReset();
	afx_msg void OnChange();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CSearchParam3 dialog

class CSearchParam3 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSearchParam3)
// Construction
public:
	CSearchParam3();   // standard constructor
	~CSearchParam3();
	virtual BOOL OnApply();

// Dialog Data
	//{{AFX_DATA(CSearchParam3)
	enum { IDD = IDD_SEARCHPARAM3 };
	BOOL	m_bProp;
	int		m_nInsertCost;
	int		m_nDeleteCost;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSearchParam3)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSearchParam3)
	afx_msg void OnReset();
	afx_msg void OnChange();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CSearchParam4 dialog

class CSearchParam4 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSearchParam4)

// Construction
public:
	CSearchParam4();
	~CSearchParam4();
	virtual BOOL OnApply();

// Dialog Data
	//{{AFX_DATA(CSearchParam4)
	enum { IDD = IDD_SEARCHPARAM4 };
	float	m_fDShort;
	float	m_fDLong;
	float	m_fDNear;
	float	m_fDTotal;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSearchParam4)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSearchParam4)
	afx_msg void OnReset();
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CSearchParam

class CSearchParam : public CPropertySheet
{
	DECLARE_DYNAMIC(CSearchParam)

// Construction
public:
	CSearchParam(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CSearchParam(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:
	CSearchParam1 p1;
	CSearchParam2 p2;
	CSearchParam3 p3;
	CSearchParam4 p4;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSearchParam)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSearchParam();

	// Generated message map functions
protected:
	//{{AFX_MSG(CSearchParam)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEARCHPARAM_H__902E47E1_5369_11D3_9F4A_346B06C10627__INCLUDED_)
