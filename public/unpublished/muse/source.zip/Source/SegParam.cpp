// SegParam.cpp : implementation file
//

#include "stdafx.h"
#include "Muse.h"
#include "SegParam.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSegParam1 property page

IMPLEMENT_DYNCREATE(CSegParam1, CPropertyPage)

CSegParam1::CSegParam1() : CPropertyPage(CSegParam1::IDD)
{
	//{{AFX_DATA_INIT(CSegParam1)
	m_bINudge = FALSE;
	m_nIStart = 0;
	m_nIStartLen = 0;
	m_nIFade = 0;
	m_nIStartAdj = 0;
	m_nIEnd = 0;
	m_nIEndLen = 0;
	m_nIEndAdj = 0;
	//}}AFX_DATA_INIT
}

CSegParam1::~CSegParam1()
{
}

void CSegParam1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSegParam1)
	DDX_Check(pDX, IDC_CHECK3, m_bINudge);
	DDX_Text(pDX, IDC_EDIT1, m_nIStart);
	DDX_Text(pDX, IDC_EDIT2, m_nIStartLen);
	DDX_Text(pDX, IDC_EDIT4, m_nIFade);
	DDX_Text(pDX, IDC_EDIT5, m_nIStartAdj);
	DDX_Text(pDX, IDC_EDIT6, m_nIEnd);
	DDX_Text(pDX, IDC_EDIT8, m_nIEndLen);
	DDX_Text(pDX, IDC_EDIT9, m_nIEndAdj);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSegParam1, CPropertyPage)
	//{{AFX_MSG_MAP(CSegParam1)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_EN_CHANGE(IDC_EDIT1, OnChange)
	ON_EN_CHANGE(IDC_EDIT2, OnChange)
	ON_EN_CHANGE(IDC_EDIT4, OnChange)
	ON_EN_CHANGE(IDC_EDIT5, OnChange)
	ON_EN_CHANGE(IDC_EDIT6, OnChange)
	ON_EN_CHANGE(IDC_EDIT8, OnChange)
	ON_EN_CHANGE(IDC_EDIT9, OnChange)
	ON_BN_CLICKED(IDC_CHECK3, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSegParam1 message handlers
/////////////////////////////////////////////////////////////////////////////
// CSegParam2 property page

IMPLEMENT_DYNCREATE(CSegParam2, CPropertyPage)

CSegParam2::CSegParam2() : CPropertyPage(CSegParam2::IDD)
{
	//{{AFX_DATA_INIT(CSegParam2)
	m_nSSuboptLen = 0;
	m_nSReqLen = 0;
	m_nSReqSD = 0;
	m_nSHopelessSD = 0;
	//}}AFX_DATA_INIT
}

CSegParam2::~CSegParam2()
{
}

void CSegParam2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSegParam2)
	DDX_Text(pDX, IDC_EDIT1, m_nSSuboptLen);
	DDX_Text(pDX, IDC_EDIT2, m_nSReqLen);
	DDX_Text(pDX, IDC_EDIT4, m_nSReqSD);
	DDX_Text(pDX, IDC_EDIT5, m_nSHopelessSD);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSegParam2, CPropertyPage)
	//{{AFX_MSG_MAP(CSegParam2)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_EN_CHANGE(IDC_EDIT1, OnChange)
	ON_EN_CHANGE(IDC_EDIT2, OnChange)
	ON_EN_CHANGE(IDC_EDIT4, OnChange)
	ON_EN_CHANGE(IDC_EDIT5, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSegParam2 message handlers
/////////////////////////////////////////////////////////////////////////////
// CSegParam3 property page

IMPLEMENT_DYNCREATE(CSegParam3, CPropertyPage)

CSegParam3::CSegParam3() : CPropertyPage(CSegParam3::IDD)
{
	//{{AFX_DATA_INIT(CSegParam3)
	m_nMSmoothTrig = 0;
	m_nMBoundShrink = 0;
	m_nMPhysLim = 0;
	//}}AFX_DATA_INIT
}

CSegParam3::~CSegParam3()
{
}

void CSegParam3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSegParam3)
	DDX_Text(pDX, IDC_EDIT1, m_nMSmoothTrig);
	DDX_Text(pDX, IDC_EDIT2, m_nMBoundShrink);
	DDX_Text(pDX, IDC_EDIT4, m_nMPhysLim);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSegParam3, CPropertyPage)
	//{{AFX_MSG_MAP(CSegParam3)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_EN_CHANGE(IDC_EDIT1, OnChange)
	ON_EN_CHANGE(IDC_EDIT2, OnChange)
	ON_EN_CHANGE(IDC_EDIT4, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSegParam3 message handlers

void CSegParam3::OnReset() 
{
	SetModified();
	m_nMSmoothTrig = 400;
	m_nMBoundShrink = 80;
	m_nMPhysLim = 1200;
	UpdateData(false);
}

void CSegParam2::OnReset() 
{
	SetModified();
	m_nSSuboptLen = 100;
	m_nSReqSD = 50;
	m_nSHopelessSD = 150;
	m_nSReqLen = 10;
	UpdateData(false);
}

void CSegParam1::OnReset() 
{
	SetModified();
	m_nIStart = 1000;
	m_nIEnd = 700;
	m_nIFade = 2;
	m_nIStartLen = 10;
	m_bINudge = true;
	m_nIEndAdj = 30;
	m_nIEndLen = 1;
	m_nIStartAdj = 60;
	UpdateData(false);
}

BOOL CSegParam1::OnApply() 
{
	CWinApp* app = AfxGetApp();
	UpdateData(true);
	app->WriteProfileInt("SegParam","nIStart",m_nIStart);
	app->WriteProfileInt("SegParam","nIEnd",m_nIEnd);
	app->WriteProfileInt("SegParam","nIFade",m_nIFade);
	app->WriteProfileInt("SegParam","nIStartLen",m_nIStartLen);
	app->WriteProfileInt("SegParam","bINudge",m_bINudge);
	app->WriteProfileInt("SegParam","nIEndAdj",m_nIEndAdj);
	app->WriteProfileInt("SegParam","nIEndLen",m_nIEndLen);
	app->WriteProfileInt("SegParam","nIStartAdj",m_nIStartAdj);
	return true;
}

BOOL CSegParam2::OnApply() 
{
	CWinApp* app = AfxGetApp();
	UpdateData(true);
	app->WriteProfileInt("SegParam","nSSuboptLen",m_nSSuboptLen);
	app->WriteProfileInt("SegParam","nSReqSD",m_nSReqSD);
	app->WriteProfileInt("SegParam","nSHopelessSD",m_nSHopelessSD);
	app->WriteProfileInt("SegParam","nSReqLen",m_nSReqLen);
	return true;
}

BOOL CSegParam3::OnApply() 
{
	CWinApp* app = AfxGetApp();
	UpdateData(true);
	app->WriteProfileInt("SegParam","nMSmoothTrig",m_nMSmoothTrig);
	app->WriteProfileInt("SegParam","nMBoundShrink",m_nMBoundShrink);
	app->WriteProfileInt("SegParam","nMPhysLim",m_nMPhysLim);
	return true;
}

BOOL CSegParam1::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CWinApp* app = AfxGetApp();
	m_nIStart = app->GetProfileInt("SegParam","nIStart",1000);
	m_nIEnd = app->GetProfileInt("SegParam","nIEnd",700);
	m_nIFade = app->GetProfileInt("SegParam","nIFade",2);
	m_nIStartLen = app->GetProfileInt("SegParam","nIStartLen",10);
	m_bINudge = app->GetProfileInt("SegParam","bINudge",1);
	m_nIEndAdj = app->GetProfileInt("SegParam","nIEndAdj",30);
	m_nIEndLen = app->GetProfileInt("SegParam","nIEndLen",1);
	m_nIStartAdj = app->GetProfileInt("SegParam","nIStartAdj",60);
	UpdateData(false);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CSegParam2::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CWinApp* app = AfxGetApp();
	m_nSSuboptLen = app->GetProfileInt("SegParam","nSSuboptLen",100);
	m_nSReqSD = app->GetProfileInt("SegParam","nSReqSD",50);
	m_nSHopelessSD = app->GetProfileInt("SegParam","nSHopelessSD",150);
	m_nSReqLen = app->GetProfileInt("SegParam","nSReqLen",10);
	UpdateData(false);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CSegParam3::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CWinApp* app = AfxGetApp();
	m_nMSmoothTrig = app->GetProfileInt("SegParam","nMSmoothTrig",400);
	m_nMBoundShrink = app->GetProfileInt("SegParam","nMBoundShrink",80);
	m_nMPhysLim = app->GetProfileInt("SegParam","nMPhysLim",1200);
	UpdateData(false);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSegParam1::OnChange() 
{
	SetModified();
}

void CSegParam2::OnChange() 
{
	SetModified();
}

void CSegParam3::OnChange() 
{
	SetModified();
}

/////////////////////////////////////////////////////////////////////////////
// CSegParam

IMPLEMENT_DYNAMIC(CSegParam, CPropertySheet)

CSegParam::CSegParam(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	AddPage(&p1);
	AddPage(&p2);
	AddPage(&p3);
}

CSegParam::CSegParam(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&p1);
	AddPage(&p2);
	AddPage(&p3);
}

CSegParam::~CSegParam()
{
}


BEGIN_MESSAGE_MAP(CSegParam, CPropertySheet)
	//{{AFX_MSG_MAP(CSegParam)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

