#if !defined(AFX_SEGPARAM_H__185173A1_52F6_11D3_9F4A_346B06C10627__INCLUDED_)
#define AFX_SEGPARAM_H__185173A1_52F6_11D3_9F4A_346B06C10627__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SegParam.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSegParam1 dialog

class CSegParam1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSegParam1)

// Construction
public:
	CSegParam1();
	~CSegParam1();

// Dialog Data
	//{{AFX_DATA(CSegParam1)
	enum { IDD = IDD_SEGPARAM1 };
	BOOL	m_bINudge;
	int		m_nIStart;
	int		m_nIStartLen;
	int		m_nIFade;
	int		m_nIStartAdj;
	int		m_nIEnd;
	int		m_nIEndLen;
	int		m_nIEndAdj;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSegParam1)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSegParam1)
	afx_msg void OnReset();
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CSegParam2 dialog

class CSegParam2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSegParam2)

// Construction
public:
	CSegParam2();
	~CSegParam2();

// Dialog Data
	//{{AFX_DATA(CSegParam2)
	enum { IDD = IDD_SEGPARAM2 };
	int		m_nSSuboptLen;
	int		m_nSReqLen;
	int		m_nSReqSD;
	int		m_nSHopelessSD;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSegParam2)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSegParam2)
	afx_msg void OnReset();
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CSegParam3 dialog

class CSegParam3 : public CPropertyPage
{
	DECLARE_DYNCREATE(CSegParam3)

// Construction
public:
	CSegParam3();
	~CSegParam3();

// Dialog Data
	//{{AFX_DATA(CSegParam3)
	enum { IDD = IDD_SEGPARAM3 };
	int		m_nMSmoothTrig;
	int		m_nMBoundShrink;
	int		m_nMPhysLim;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSegParam3)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSegParam3)
	afx_msg void OnReset();
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CSegParam

class CSegParam : public CPropertySheet
{
	DECLARE_DYNAMIC(CSegParam)

// Construction
public:
	CSegParam(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CSegParam(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:
	CSegParam1 p1;
	CSegParam2 p2;
	CSegParam3 p3;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSegParam)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSegParam();

	// Generated message map functions
protected:
	//{{AFX_MSG(CSegParam)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEGPARAM_H__185173A1_52F6_11D3_9F4A_346B06C10627__INCLUDED_)
