// Song.cpp: implementation of the CSong class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Muse.h"
#include "Note.h"
#include "Song.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSong::CSong()
{
	m_nTempo = 750;
}

CSong::~CSong()
{

}

CSong::CSong(const CSong& song)
{
	CDurNote member;
	int i;
	m_name = song.m_name;
	m_comments = song.m_comments;
	m_nTempo = song.m_nTempo;
	for(i=0; i<song.m_durnote.GetSize(); i++) {
		member = song.m_durnote[i];
		m_durnote.Add(member);
	}
}

IMPLEMENT_SERIAL(CSong, CObject,1)

void CSong::Clear()
{
	m_durnote.RemoveAll();
	m_name = "";
	m_comments = "";
	m_nTempo = 750;
}

void CSong::Serialize(CArchive& ar)
{
	int i,n;
	CDurNote durnote;

	if(ar.IsStoring())
	{
		ar << m_name << m_comments << m_nTempo << m_durnote.GetSize();
		for(i=0; i<m_durnote.GetSize(); i++) {
			m_durnote[i].Serialize(ar);
		}
	}
	else
	{
		ASSERT(m_durnote.GetSize() == 0);
		ar >> m_name >> m_comments >> m_nTempo >> n;
		// n==number of notes in song
		for(i=0; i<n; i++) {
			durnote.Serialize(ar);
			m_durnote.Add(durnote);
		}
	}
}

CSong& CSong::operator =(const CSong & song)
{
	int i;
	CDurNote member;
	Clear();
	m_nTempo = song.m_nTempo;
	m_name = song.m_name;
	m_comments = song.m_comments;
	for(i=0; i<song.m_durnote.GetSize(); i++) {
		member = song.m_durnote[i];
		m_durnote.Add(member);
	}
	return *this;
}

void CSong::Transpose(int nSemitones)
{
	int i;
	for(i=0; i<m_durnote.GetSize(); i++) {
		m_durnote[i].Transpose(nSemitones);
	}
}
