// Song.h: interface for the CSong class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SONG_H__0307EB2C_1F7D_11D3_9F4A_0C8A06C10627__INCLUDED_)
#define AFX_SONG_H__0307EB2C_1F7D_11D3_9F4A_0C8A06C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CSong : public CObject  
{
public:
	void Transpose(int nSemitones);
	CSong& operator=(const CSong& song);
	DECLARE_SERIAL( CSong )
	void Clear();
	void Serialize(CArchive& ar);
	CSong();
	CSong(const CSong& song);
	virtual ~CSong();

	CArray<CDurNote, CDurNote&> m_durnote;
	//CArray<CNote,CNote&> m_note;
	//CArray<int,int> m_duration;
	CString m_name;
	CString m_comments;
	int m_nTempo;
};

#endif // !defined(AFX_SONG_H__0307EB2C_1F7D_11D3_9F4A_0C8A06C10627__INCLUDED_)
