// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__3D418089_7FA5_11D2_9F4A_1CF705C10627__INCLUDED_)
#define AFX_STDAFX_H__3D418089_7FA5_11D2_9F4A_1CF705C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxtempl.h>		// MFC template container classes
#include <afxmt.h>			// MFC multithreaded classes
#include <mmsystem.h>		// Windows Multimedia System
#include <math.h>			// Math functions
#include <memory.h>			// memcpy, etc.
#include <stdlib.h>			// rand, srand, etc.
#include <time.h>			// time() -- required for random seed

#include "Note.h"			// CNote class
#include "Song.h"			// CSong class
#include "WaveIn.h"			// CWaveIn class (multithreaded audio input support)
#include "NumArray.h"		// Numeric array
#include "cdib.h"			// CDib class (from Kruglinski, "Inside Visual C++", 4th ed,

#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

typedef short sample;

#define SMPRATE			8000	// sampling rate
#define FILTER_N		100		// length of low-pass filter
#define PI				3.1415926535

#define abs(x)			( (x)>0 ? (x) : -(x) )


//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__3D418089_7FA5_11D2_9F4A_1CF705C10627__INCLUDED_)
