// WaveIn.cpp: implementation of the CWaveIn class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Muse.h"
#include "WaveIn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

static void MMResult(MMRESULT res);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWaveIn::CWaveIn(UINT uDeviceID, LPWAVEFORMATEX pwfx, UINT uBufSize, HWND hwndNotify/*=NULL*/)
{
	m_uBufSize = uBufSize;
	m_state = Startup;
	m_hwndNotify = hwndNotify;
	if((m_hThread = CreateThread(NULL,0,WaveInThread,(void*)this, 0, &m_dwThreadId)) == NULL)
		MMResult(MMSYSERR_ERROR);
	MMResult(waveInOpen(&m_hwi, uDeviceID, pwfx, m_dwThreadId, (DWORD)(void*)this,
		CALLBACK_THREAD));
}

CWaveIn::~CWaveIn()
{
	WAVEHDR * pwh;
	Stop();
	if(waveInClose(m_hwi) != MMSYSERR_NOERROR) {
	}
	while(!StackIsEmpty()) {
		pwh = StackPop();
		DeleteWaveHdr(pwh);
	}
}

void CWaveIn::Start()
{
	if(m_state == Recording)
		return;
	do
		Sleep(0);
	while(m_state == Startup);
	ASSERT(m_state==Idle);
	AddBuffer();
	AddBuffer();
	MMResult(waveInStart(m_hwi));
	m_state = Recording;
}

void CWaveIn::Stop()
{
	DWORD nExitCode;
	int i=0;

	if(m_state==Idle)
		return;
	m_state = Stopping;
	MMResult(waveInStop(m_hwi));
	MMResult(waveInReset(m_hwi));
	VERIFY(PostThreadMessage(m_dwThreadId, WM_QUIT, 0, 0));
	do {
		Sleep(0);
		GetExitCodeThread((HANDLE)m_hThread, &nExitCode);
		i++;
	} while(nExitCode == STILL_ACTIVE && i<100000);
	if(i>99900) {
		TRACE("Problem with other thread; nExitCode == %d\n",nExitCode);
		AfxThrowUserException();
	}
	m_state = Idle;
}

WAVEHDR* CWaveIn::StackPop()
{
	CSingleLock lock(&m_cs); // ensure safe access to m_stack
	lock.Lock();
	ASSERT(lock.IsLocked());
	if(m_stack.IsEmpty())
		return NULL;
	WAVEHDR* pwh = m_stack.RemoveHead();
	return pwh;
	// caller should call DeleteWaveHdr(pwh) after finishing with pwh!
	// lock is released by CSingleLock destructor
}

DWORD WINAPI WaveInThread(LPVOID param)
{
	CWaveIn* pwi = (CWaveIn*) param;
	MSG msg;

	pwi->m_state = CWaveIn::Idle;

	while(GetMessage(&msg, NULL, 0, 0)) {
		switch(msg.message) {
		case MM_WIM_CLOSE:
			pwi->OnWIMClose(); return 1;
		case MM_WIM_OPEN:
			pwi->OnWIMOpen(); break;
		case MM_WIM_DATA:
			pwi->OnWIMData((LPWAVEHDR) msg.lParam); break;
		default:
			TRACE("Received an unknown message: %d\n",msg.message); break;
		}
	}

	return 0;
}

void CWaveIn::OnWIMClose() 
// this function is run from the recorder thread
{
	// intentionally left blank
}

void CWaveIn::OnWIMOpen()
// this function is run from the recorder thread
{
	// intentionally left blank
}

void CWaveIn::OnWIMData(LPWAVEHDR pwh)
// this function is run from the recorder thread
{
	waveInUnprepareHeader(m_hwi, pwh, sizeof(WAVEHDR));
	if(m_state==Recording)
		AddBuffer();
	CSingleLock lock(&m_cs); // ensure safe access to m_stack
	lock.Lock();
	ASSERT(lock.IsLocked());
	m_stack.AddTail(pwh);
	lock.Unlock();
	if(m_hwndNotify)
		::PostMessage(m_hwndNotify, WM_WAVEIN_NOTIFY_PUSH, (DWORD)(void*)this, 0);
}

void CWaveIn::AddBuffer()
{
	WAVEHDR* wh = new WAVEHDR;
	memset(wh,0,sizeof(WAVEHDR));
	char* buffer = new char[m_uBufSize];
	wh->lpData = buffer;
	wh->dwBufferLength = m_uBufSize;
	MMResult(waveInPrepareHeader(m_hwi, wh, sizeof(WAVEHDR)));
	MMResult(waveInAddBuffer(m_hwi, wh, sizeof(WAVEHDR)));
}

BOOL CWaveIn::StackIsEmpty() {
	CSingleLock lock(&m_cs); // ensure safe access to m_stack
	lock.Lock();
	ASSERT(lock.IsLocked());
	return m_stack.IsEmpty();
	// lock released by CSingleLock's destructor
}

void MMResult(MMRESULT res) {
	if(res==MMSYSERR_NOERROR)
		return;

	char text[MAXERRORLENGTH];
	
	waveInGetErrorText(res, text, MAXERRORLENGTH);
	AfxMessageBox(text);
	AfxThrowUserException();
	return;
}
