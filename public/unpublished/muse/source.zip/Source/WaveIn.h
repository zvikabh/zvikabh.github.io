// WaveIn.h: interface for the CWaveIn class.
//
//////////////////////////////////////////////////////////////////////

#define DeleteWaveHdr( pwh )	{ delete[] pwh->lpData; delete pwh; }

#define WM_WAVEIN_NOTIFY_PUSH		WM_USER + 0x3e

#if !defined(AFX_WAVEIN_H__B08C5F06_82D5_11D2_9F4A_1CF705C10627__INCLUDED_)
#define AFX_WAVEIN_H__B08C5F06_82D5_11D2_9F4A_1CF705C10627__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CWaveIn : public CObject  
{
friend DWORD WINAPI WaveInThread(LPVOID param);
public:
	WAVEHDR* StackPop();
	BOOL StackIsEmpty();
	void Stop();
	void Start();
	CWaveIn(UINT uDeviceID, LPWAVEFORMATEX pwfx, UINT uBufSize, HWND hwndNotify=NULL);
	virtual ~CWaveIn();
	HWAVEIN GetHandle() { return m_hwi; };
	UINT GetBufSize() { return m_uBufSize; };
	enum State { Idle, Recording, Startup, Stopping };
	State GetState() { return m_state; };

protected:
	CCriticalSection m_cs;
	HANDLE m_hThread;
	DWORD m_dwThreadId;
	void AddBuffer();
	void OnWIMOpen();
	void OnWIMData(LPWAVEHDR pwh);
	void OnWIMClose();
	UINT m_uBufSize;
	HWAVEIN m_hwi;
	CTypedPtrList<CPtrList, WAVEHDR*> m_stack; // stack of input buffers
	State m_state;
	HWND m_hwndNotify;
};

#endif // !defined(AFX_WAVEIN_H__B08C5F06_82D5_11D2_9F4A_1CF705C10627__INCLUDED_)
